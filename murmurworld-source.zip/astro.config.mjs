import { defineConfig } from 'astro/config';

// 루트 `/` = 세계 랜딩, `/blog/` = 정보 글, `/calc/` = 계산기(public/calc, 정적 파일 그대로)
export default defineConfig({
  site: 'https://murmurworld.github.io',
  trailingSlash: 'always',
  build: { format: 'directory' },
});
