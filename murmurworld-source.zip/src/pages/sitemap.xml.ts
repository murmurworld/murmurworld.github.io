import type { APIRoute } from 'astro';
import { englishPath, translatedPages } from '../site/locales';

export const GET: APIRoute = ({ site }) => {
  const entries = translatedPages.flatMap((path) => {
    const korean = new URL(path, site);
    const english = new URL(englishPath(path), site);
    return [korean, english].map((url) => `  <url>
    <loc>${url}</loc>
    <xhtml:link rel="alternate" hreflang="ko" href="${korean}" />
    <xhtml:link rel="alternate" hreflang="en" href="${english}" />
  </url>`);
  });
  const calculator = new URL('/calc/', site);
  const xml = ['<?xml version="1.0" encoding="UTF-8"?>', '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">', ...entries, `  <url><loc>${calculator}</loc></url>`, '</urlset>'].join('\n');
  return new Response(xml, { headers: { 'Content-Type': 'application/xml; charset=utf-8' } });
};
