type Point={x:number;y:number};
type Company=Point & {id:string;name:string;short:string;w:number;peers:Set<string>};
type Edge={id:string;from:string;to:string;joint:boolean;kind:string;label:string;caseId:string;source:string};
type Box=Point & {w:number;h:number};
const svgNode=<K extends keyof SVGElementTagNameMap>(tag:K)=>document.createElementNS('http://www.w3.org/2000/svg',tag);
const clamp=(n:number,min:number,max:number)=>Math.min(max,Math.max(min,n));
const pad=22;

function readNetwork(container:Element) {
  const companies=new Map<string,Company>(),edges=new Map<string,Edge>();
  for(const profile of container.querySelectorAll<HTMLElement>('[data-network]')){
    const id=profile.dataset.network!,name=profile.querySelector('[data-network-title]')!.textContent!.trim();
    const short=name.split(/\s+·\s+/)[0].replace(/\s*\([^)]*\)$/,'');
    const text=id.startsWith('ext-')?short:id;
    companies.set(id,{id,name,short,w:clamp(18+[...text].length*7,54,112),x:0,y:0,peers:new Set()});
    for(const row of profile.querySelectorAll<HTMLElement>('[data-edge-id]')){
      const group=row.closest<HTMLElement>('[data-network-group]')!.dataset.networkGroup;
      if(group==='incoming' || edges.has(row.dataset.edgeId!))continue;
      const peer=row.querySelector<HTMLElement>('[data-network-peer]')!.dataset.networkPeer!;
      edges.set(row.dataset.edgeId!,{id:row.dataset.edgeId!,from:id,to:peer,joint:group==='partners',
        caseId:row.dataset.caseId!,kind:row.dataset.kind ?? '',label:row.querySelector('p')!.textContent!.trim(),
        source:row.querySelector<HTMLAnchorElement>('[data-network-source]')!.href});
    }
  }
  for(const e of edges.values()){
    companies.get(e.from)!.peers.add(e.to);companies.get(e.to)!.peers.add(e.from);
  }
  return {companies,edges};
}

function distances(origin:string,companies:Map<string,Company>) {
  const levels=new Map([[origin,0]]),q=[origin];
  for(let i=0;i<q.length;i++)for(const id of companies.get(q[i])!.peers)if(!levels.has(id)){
    levels.set(id,levels.get(q[i])!+1);q.push(id);
  }
  return levels;
}

function bounds(nodes:Company[]):Box {
  const left=Math.min(...nodes.map(n=>n.x-n.w/2))-pad, right=Math.max(...nodes.map(n=>n.x+n.w/2))+pad;
  const top=Math.min(...nodes.map(n=>n.y))-32, bottom=Math.max(...nodes.map(n=>n.y))+32;
  return {x:left,y:top,w:right-left,h:bottom-top};
}

// The full graph has an invariant layout. For an ego network, distribute its
// levels around the chosen company so a leaf does not use only half a phone.
function focusPositions(nodes:Company[],origin:Company,hops:Map<string,number>,aspect:number,global:Map<string,Point>){
  const result=new Map<string,Point>([[origin.id,global.get(origin.id)!]]);
  const unitX=Math.max(82,...nodes.map(n=>n.w+9)),unitY=43;
  const halfCols=Math.max(1,Math.round((Math.sqrt(nodes.length*aspect*unitY/unitX)-1)/2));
  const halfRows=Math.max(1,Math.ceil((nodes.length/(2*halfCols+1)-1)/2));
  const slots:Point[]=[];
  for(let row=-halfRows;row<=halfRows;row++)for(let col=-halfCols;col<=halfCols;col++)
    if(col||row)slots.push({x:col*unitX,y:row*unitY});
  const normalized=(p:Point)=>Math.hypot(p.x/unitX,p.y/unitY);
  slots.sort((a,b)=>normalized(a)-normalized(b) || Math.atan2(a.y,a.x)-Math.atan2(b.y,b.x));
  const base=global.get(origin.id)!;
  for(let depth=1;result.size<nodes.length;depth++){
    const group=nodes.filter(n=>hops.get(n.id)===depth);
    if(!group.length)break;
    const layer=slots.splice(0,group.length);
    for(const n of group.sort((a,b)=>b.peers.size-a.peers.size || a.id.localeCompare(b.id))){
      const parents=Array.from(n.peers).filter(id=>result.has(id) && hops.get(id)===depth-1);
      const own=global.get(n.id)!;
      function cost(p:Point){
        const towards=(own.x-base.x)*(p.x/unitX)+(own.y-base.y)*(p.y/unitY);
        return parents.reduce((total,id)=>{
          const a=result.get(id)!;
          return total+Math.hypot((p.x+base.x-a.x)/unitX,(p.y+base.y-a.y)/unitY);
        },0)-.12*towards/Math.max(1,Math.hypot(own.x-base.x,own.y-base.y));
      }
      const best=layer.reduce((a,b)=>cost(a)<=cost(b)?a:b);
      layer.splice(layer.indexOf(best),1);result.set(n.id,{x:base.x+best.x,y:base.y+best.y});
    }
  }
  return result;
}

// Place each connected component separately. Positions are independent of the
// selected company so a second-hop neighbor stays in place when the camera follows it.
function layout(companies:Map<string,Company>) {
  const used=new Set<string>(),groups:Company[][]=[];
  const ranked=[...companies.values()].sort((a,b)=>b.peers.size-a.peers.size || a.id.localeCompare(b.id));
  for(const seed of ranked){
    if(used.has(seed.id))continue;
    const depth=distances(seed.id,companies),nodes=Array.from(depth.keys(),id=>companies.get(id)!);
    for(const n of nodes)used.add(n.id);
    const rings:Company[][]=[];
    for(const n of nodes)(rings[depth.get(n.id)!]??=[]).push(n);
    let radius=0;
    for(let level=1;level<rings.length;level++){
      const ring=rings[level];
      radius=Math.max(radius+98,ring.length*86/(2*Math.PI));
      for(const [i,n] of ring.entries()){
        const angle=(i/ring.length)*2*Math.PI+(level-1)*.36;
        n.x=Math.cos(angle)*radius;n.y=Math.sin(angle)*radius*.73;
      }
    }
    if(nodes.length>2){
      // Relax connected pairs toward one another, while keeping their label
      // rectangles apart. A fixed iteration count makes the offline layout repeatable.
      for(let iteration=0;iteration<105;iteration++) {
        const strength=Math.max(.05,1-iteration/105);
        for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++){
          const a=nodes[i],b=nodes[j];
          const dx=b.x-a.x || .02,dy=b.y-a.y || .02;
          const minX=(a.w+b.w)/2+18,minY=48;
          if(Math.abs(dx)<minX && Math.abs(dy)<minY) {
            if((minX-Math.abs(dx))/minX < (minY-Math.abs(dy))/minY) {
              const shift=Math.sign(dx)*(minX-Math.abs(dx))*.5;a.x-=shift;b.x+=shift;
            } else {const shift=Math.sign(dy)*(minY-Math.abs(dy))*.5;a.y-=shift;b.y+=shift;}
          } else if(a.peers.has(b.id)) {
            const distance=Math.hypot(dx,dy);
            if(distance>135){const k=(distance-135)/distance*.038*strength;a.x+=dx*k;a.y+=dy*k;b.x-=dx*k;b.y-=dy*k;}
          }
        }
      }
    }
    groups.push(nodes);
  }
  const pieces=groups.map(nodes=>({nodes,box:bounds(nodes)})).sort((a,b)=>b.box.h-a.box.h || b.box.w-a.box.w);
  const area=pieces.reduce((s,p)=>s+p.box.w*p.box.h,0),width=Math.max(...pieces.map(p=>p.box.w),Math.sqrt(area*1.77));
  let x=0,y=0,rowH=0;
  for(const p of pieces){
    if(x && x+p.box.w>width){x=0;y+=rowH+12;rowH=0;}
    for(const n of p.nodes){n.x+=x-p.box.x;n.y+=y-p.box.y;}
    x+=p.box.w+12;rowH=Math.max(rowH,p.box.h);
  }
}

export function mountNetworkAtlas(root:HTMLElement){
  const region=root.closest('[data-relationships]') ?? root.parentElement!;
  const {companies,edges}=readNetwork(region);
  if(!companies.size || !edges.size)return;
  layout(companies);
  const global=new Map([...companies.values()].map(n=>[n.id,{x:n.x,y:n.y}]));
  const en=root.dataset.lang==='en';
  const svg=root.querySelector<SVGSVGElement>('[data-network-surface]')!;
  const nodeLayer=root.querySelector<SVGGElement>('[data-atlas-nodes]')!,edgeLayer=root.querySelector<SVGGElement>('[data-atlas-edges]')!;
  const depth=root.querySelector<HTMLSelectElement>('[data-network-depth]')!,overview=root.querySelector<HTMLButtonElement>('[data-network-overview]')!;
  const summary=root.querySelector<HTMLElement>('[data-atlas-count]')!,evidence=root.querySelector<HTMLElement>('[data-atlas-evidence]')!;
  const base=(en?'/en':'')+'/stocks/';
  const href=(id:string)=>base+'?'+(id.startsWith('ext-')?'peer':'company')+'='+encodeURIComponent(id);
  const nodeEls=new Map<string,SVGAElement>(),edgeEls=new Map<string,SVGAElement>();
  for(const n of companies.values()){
    const a=svgNode('a'),rect=svgNode('rect'),name=svgNode('text'),brand=svgNode('text'),title=svgNode('title');
    a.setAttribute('href',href(n.id)+'#relationships');a.dataset.networkNode=n.id;a.dataset.networkPeer=n.id;a.dataset.networkStay='';
    a.setAttribute('aria-label',n.name);title.textContent=n.name;
    a.setAttribute('transform',`translate(${n.x} ${n.y})`);
    rect.setAttribute('x',String(-n.w/2));rect.setAttribute('width',String(n.w));rect.setAttribute('y','-16');rect.setAttribute('height','32');rect.setAttribute('rx','9');
    const external=n.id.startsWith('ext-');
    const shorten=(s:string,max:number)=>s.length>max?s.slice(0,max-1)+'…':s;
    name.textContent=external?shorten(n.short,15):n.id;name.setAttribute('y',external?'4':'-1');
    if(!external){brand.textContent=shorten(n.short,Math.max(10,Math.floor(n.w/5)));brand.setAttribute('class','brand');brand.setAttribute('y','10');}
    a.append(title,rect,name,brand);nodeLayer.append(a);nodeEls.set(n.id,a);
  }
  const pairs=new Map<string,Edge[]>();
  for(const e of edges.values()){
    const k=[e.from,e.to].sort().join('|'),list=pairs.get(k)??[];list.push(e);pairs.set(k,list);
  }
  const edgePainters=new Map<string,(obstacles:Company[])=>void>();
  for(const pair of pairs.values())for(const [i,e] of pair.entries()){
    const a=svgNode('a'),wire=svgNode('path'),hit=svgNode('path'),title=svgNode('title');
    const stage=!e.joint && ['design','showcase','production','agreement'].includes(e.kind);
    Object.assign(a.dataset,{atlasEdge:e.id,from:e.from,to:e.to,joint:String(e.joint),kind:e.kind,networkCase:e.caseId,networkStay:''});
    if(stage)a.dataset.stage='';
    const n=companies.get(e.from)!,p=companies.get(e.to)!;
    edgePainters.set(e.id,obstacles=>{
      const dx=p.x-n.x,dy=p.y-n.y,len=Math.hypot(dx,dy)||1;
      const bend=(i-(pair.length-1)/2)*22*(e.from<e.to?1:-1);
      let best:Point={x:0,y:0},score=Infinity;
      for(const lift of [0,46,-46,90,-90]){
        const c={x:(n.x+p.x)/2-dy/len*(bend+lift),y:(n.y+p.y)/2+dx/len*(bend+lift)};
        let collisions=0;
        for(const other of obstacles)if(other!==n && other!==p){
          for(let k=1;k<10;k++){
            const t=k/10,u=1-t,x=u*u*n.x+2*t*u*c.x+t*t*p.x,y=u*u*n.y+2*t*u*c.y+t*t*p.y;
            if(Math.abs(x-other.x)<other.w/2+4 && Math.abs(y-other.y)<20){collisions++;break;}
          }
        }
        if(collisions<score){best=c;score=collisions;}
        if(!score)break;
      }
      const end=(v:Company)=>{
        const dx=best.x-v.x,dy=best.y-v.y,t=Math.min((v.w/2+2)/Math.max(.01,Math.abs(dx)),18/Math.max(.01,Math.abs(dy)),.9);
        return [v.x+dx*t,v.y+dy*t].join(' ');
      };
      const d='M'+end(n)+' Q'+best.x+' '+best.y+' '+end(p);
      wire.setAttribute('d',d);hit.setAttribute('d',d);
    });
    wire.setAttribute('class','wire');if(!e.joint && !stage)wire.setAttribute('marker-end',`url(#atlas-arrow-${root.dataset.lang})`);
    hit.setAttribute('class','hit');
    title.textContent=n.name+(e.joint?' ↔ ':stage?' · ':' → ')+p.name+' · '+e.label;a.setAttribute('aria-label',title.textContent);
    a.append(title,wire,hit);edgeLayer.append(a);edgeEls.set(e.id,a);
  }
  let center='',active='',selected='',scope:Company[]=[],visibleEdges:Edge[]=[];
  let view:Point={x:0,y:0},scale=1,fitScale=1,frame=0,focusId='',edgeFocus='',initialized=false;
  const fullBounds=bounds([...companies.values()]);
  const zoomIn=root.querySelector<HTMLButtonElement>('[data-atlas-zoom=in]')!,zoomOut=root.querySelector<HTMLButtonElement>('[data-atlas-zoom=out]')!;
  function paint(){
    const w=svg.clientWidth/scale,h=svg.clientHeight/scale;
    if(!w || !h)return;
    view.x=clamp(view.x,fullBounds.x-w*.28,fullBounds.x+fullBounds.w+w*.28);
    view.y=clamp(view.y,fullBounds.y-h*.28,fullBounds.y+fullBounds.h+h*.28);
    svg.setAttribute('viewBox',[view.x-w/2,view.y-h/2,w,h].join(' '));
    svg.toggleAttribute('data-can-pan',scale>fitScale*1.03);
    zoomIn.disabled=scale>=3.3;zoomOut.disabled=scale<=Math.min(.13,fitScale)*1.01;
  }
  function fit(animate=false){
    if(!scope.length || !svg.clientWidth)return;
    const b=bounds(scope),n=companies.get(center);
    const target=n?{x:n.x,y:n.y}:{x:b.x+b.w/2,y:b.y+b.h/2};
    const w=2*Math.max(target.x-b.x,b.x+b.w-target.x)+22,h=2*Math.max(target.y-b.y,b.y+b.h-target.y)+24;
    fitScale=Math.min((svg.clientWidth-12)/w,(svg.clientHeight-24)/h,1.9);
    const start=performance.now(),from=view,oldScale=scale;
    cancelAnimationFrame(frame);
    function step(time:number){
      const progress=animate && !matchMedia('(prefers-reduced-motion: reduce)').matches ? Math.min(1,(time-start)/195) : 1;
      const k=1-(1-progress)**3;
      view={x:from.x+(target.x-from.x)*k,y:from.y+(target.y-from.y)*k};scale=oldScale+(fitScale-oldScale)*k;paint();
      if(progress<1)frame=requestAnimationFrame(step);
    }
    step(start);
  }
  function refresh(force=false){
    const url=new URL(location.href),chosen=url.searchParams.get('company') || url.searchParams.get('peer') || '';
    const next=companies.has(chosen)?chosen:'',changed=next!==active;
    if(changed || !initialized){center=next;active=next;}
    const edgeId=url.searchParams.get('relation') || '';
    const redraw=changed || force || !initialized;
    selected=edgeId;root.dataset.center=center;root.dataset.mode=center?'focus':'all';
    overview.disabled=!center;depth.disabled=!active;
    const hops=center?distances(center,companies):new Map<string,number>();
    const limit=depth.value==='all'?Infinity:Number(depth.value);
    if(redraw){
      const focused=document.activeElement?.closest<SVGAElement>('[data-network-node]')?.dataset.networkNode;
      scope=Array.from(companies.values()).filter(n=>!center || (hops.get(n.id) ?? Infinity)<Infinity && hops.get(n.id)!<=limit);
      const positions=center?focusPositions(scope,companies.get(center)!,hops,svg.clientWidth/svg.clientHeight,global):global;
      for(const n of scope){
        Object.assign(n,positions.get(n.id)!);
        nodeEls.get(n.id)!.setAttribute('transform',`translate(${n.x} ${n.y})`);
      }
      const shown=new Set(scope.map(n=>n.id));
      focusId=center || (shown.has(focusId)?focusId:scope.reduce((a,b)=>a.peers.size>=b.peers.size?a:b).id);
      for(const [id,el] of nodeEls){
        el.style.display=shown.has(id)?'':'none';el.dataset.hop=String(hops.get(id) ?? -1);
        el.setAttribute('tabindex',id===focusId?'0':'-1');
        if(id===center)el.setAttribute('aria-current','true');else el.removeAttribute('aria-current');
      }
      visibleEdges=[...edges.values()].filter(e=>shown.has(e.from)&&shown.has(e.to));
      for(const e of visibleEdges)edgePainters.get(e.id)!(center?scope:[]);
      const visible=new Set(visibleEdges.map(e=>e.id));
      if(!visible.has(edgeFocus))edgeFocus=visibleEdges.find(e=>e.from===center||e.to===center)?.id ?? visibleEdges[0]?.id ?? '';
      for(const [id,el] of edgeEls){el.style.display=visible.has(id)?'':'none';el.setAttribute('tabindex',id===edgeFocus?'0':'-1');}
      if(focused && !shown.has(focused))nodeEls.get(focusId)?.focus({preventScroll:true});
      const name=center?companies.get(center)!.name+(en?' · ':' 중심 · '):'';
      summary.textContent=name+(en?`${scope.length} companies · ${visibleEdges.length} disclosed links`:`기업 ${scope.length}곳 · 확인한 관계 ${visibleEdges.length}건`);
      fit(initialized);initialized=true;
    }
    for(const e of visibleEdges){
      const el=edgeEls.get(e.id)!,endpoint=e.to===active?e.to:e.from;
      el.setAttribute('href',href(endpoint)+'&case='+encodeURIComponent(e.caseId)+'&relation='+encodeURIComponent(e.id)+'#case-'+e.caseId);
      if(selected===e.id)el.setAttribute('aria-current','true');else el.removeAttribute('aria-current');
    }
    const e=edges.get(selected);
    evidence.hidden=!e || !visibleEdges.includes(e);
    if(e && !evidence.hidden){
      evidence.querySelector('strong')!.textContent=companies.get(e.from)!.name+(e.joint?' ↔ ':edgeEls.get(e.id)!.hasAttribute('data-stage')?' · ':' → ')+companies.get(e.to)!.name;
      evidence.querySelector('span')!.textContent=e.label;evidence.querySelector<HTMLAnchorElement>('[data-atlas-primary]')!.href=e.source;
      const more=evidence.querySelector<HTMLAnchorElement>('[data-atlas-case]')!;more.dataset.networkCase=e.caseId;
      more.href=edgeEls.get(e.id)!.getAttribute('href')!;
    }
  }
  root.hidden=false;
  overview.addEventListener('click',()=>{center='';refresh(true);});
  depth.addEventListener('change',()=>{center=active;refresh(true);});
  root.querySelector('[data-atlas-zoom=fit]')!.addEventListener('click',()=>fit(true));
  const zoomAt=(factor:number,x?:number,y?:number)=>{
    cancelAnimationFrame(frame);
    const rect=svg.getBoundingClientRect(),old=scale;
    scale=clamp(scale*factor,Math.min(.13,fitScale),3.3);
    if(x!==undefined && y!==undefined){
      view={x:view.x+(x-rect.left-rect.width/2)*(1/old-1/scale),y:view.y+(y-rect.top-rect.height/2)*(1/old-1/scale)};
    }
    paint();
  };
  zoomIn.addEventListener('click',()=>zoomAt(1.45));zoomOut.addEventListener('click',()=>zoomAt(1/1.45));
  svg.addEventListener('wheel',e=>{
    if(!e.deltaY || !e.cancelable)return;
    if(!svg.contains(document.activeElement) && !e.ctrlKey && !e.metaKey)return;
    const factor=Math.exp(-clamp(e.deltaY*(e.deltaMode?14:1)*.0026,-.6,.6));
    if((factor<1 && zoomOut.disabled)||(factor>1 && zoomIn.disabled))return;
    e.preventDefault();zoomAt(factor,e.clientX,e.clientY);
  },{passive:false});
  let drag:{id:number;start:Point;view:Point}|undefined,dragged=false;
  svg.addEventListener('dragstart',e=>e.preventDefault());
  svg.addEventListener('pointerdown',e=>{
    if(e.button!==0 || e.ctrlKey || e.altKey || e.shiftKey || e.metaKey || drag)return;
    cancelAnimationFrame(frame);dragged=false;drag={id:e.pointerId,start:{x:e.clientX,y:e.clientY},view:{...view}};
    if(e.pointerType==='mouse')((e.target as Element).closest<SVGElement>('a') ?? svg).focus({preventScroll:true});
    (e.target as Element).setPointerCapture(e.pointerId);
  });
  svg.addEventListener('pointermove',e=>{
    if(e.pointerId!==drag?.id || !drag)return;
    const dx=e.clientX-drag.start.x,dy=e.clientY-drag.start.y;
    if(!dragged && Math.hypot(dx,dy)<6)return;
    dragged=true;svg.dataset.dragging='';view={x:drag.view.x-dx/scale,y:drag.view.y-dy/scale};paint();
  });
  const end=(e:PointerEvent)=>{if(e.pointerId===drag?.id){drag=undefined;svg.removeAttribute('data-dragging');}};
  svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);svg.addEventListener('lostpointercapture',end);
  svg.addEventListener('click',e=>{
    if(dragged && e.detail){e.preventDefault();e.stopPropagation();return;}
    const node=(e.target as Element).closest<SVGAElement>('[data-network-node]')?.dataset.networkNode;
    if(node===active && !center){center=active;refresh(true);}
  },true);
  svg.addEventListener('keydown',e=>{
    if(e.ctrlKey||e.metaKey||e.altKey||e.shiftKey)return;
    if(e.key==='+'||e.key==='=')zoomAt(1.45);
    else if(e.key==='-')zoomAt(1/1.45);
    else if(e.key==='Home')fit(true);
    else if(e.key.startsWith('Arrow')){
      const edge=(e.target as Element).closest<SVGAElement>('[data-atlas-edge]');
      if(edge && visibleEdges.length){
        const i=visibleEdges.findIndex(v=>v.id===edge.dataset.atlasEdge);
        const step=(e.key==='ArrowLeft'||e.key==='ArrowUp')?-1:1;
        edgeEls.get(edgeFocus)?.setAttribute('tabindex','-1');
        edgeFocus=visibleEdges[(i+step+visibleEdges.length)%visibleEdges.length].id;
        const next=edgeEls.get(edgeFocus)!;next.setAttribute('tabindex','0');next.focus({preventScroll:true});e.preventDefault();return;
      }
      const el=(e.target as Element).closest<SVGAElement>('[data-network-node]'),n=companies.get(el?.dataset.networkNode ?? focusId)!;
      const dx=e.key==='ArrowRight'?1:e.key==='ArrowLeft'?-1:0,dy=e.key==='ArrowDown'?1:e.key==='ArrowUp'?-1:0;
      const score=(p:Company)=>{
        const x=p.x-n.x,y=p.y-n.y,forward=x*dx+y*dy;
        return forward>1?Math.hypot(x,y)+2*Math.abs(x*dy-y*dx):Infinity;
      };
      const next=scope.filter(p=>Number.isFinite(score(p))).sort((a,b)=>score(a)-score(b))[0];
      if(next){
        nodeEls.get(focusId)?.setAttribute('tabindex','-1');focusId=next.id;
        const link=nodeEls.get(next.id)!;link.setAttribute('tabindex','0');link.focus({preventScroll:true});
        if(Math.abs(next.x-view.x)>svg.clientWidth*.43/scale || Math.abs(next.y-view.y)>svg.clientHeight*.4/scale){cancelAnimationFrame(frame);view={x:next.x,y:next.y};paint();}
      }
    }else return;
    e.preventDefault();
  });
  document.addEventListener('location-map:relations',()=>refresh());
  window.addEventListener('popstate',()=>refresh());
  let w=0,h=0;
  new ResizeObserver(()=>{
    if(svg.clientWidth!==w||svg.clientHeight!==h){w=svg.clientWidth;h=svg.clientHeight;refresh(true);fit();}
  }).observe(svg);
  refresh(true);
}
