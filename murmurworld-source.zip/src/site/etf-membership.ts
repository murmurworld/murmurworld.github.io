import reports from './etf-holdings.json';
import { marketGroups } from './markets';
import type { HoldingPosition } from './etf-rank-label';

const guides: Record<string, string> = {
  VOO: 'index-etf/voo', QQQM: 'index-etf/qqqm', SCHD: 'dividend-etf/schd',
};
const listed = new Set(marketGroups.filter(group => group.section === 'companies')
  .flatMap(group => group.items.map(item => item.ticker)));

// These aliases identify securities of the SAME issuer. A public parent does not
// confer ETF membership on a subsidiary (e.g. Citibank or Sempra Infrastructure).
const aliases: Record<string, string> = {
  GOOG: 'GOOGL',
  SKHY: '000660', HXSCL: '000660', HYXS: '000660', HYNSE: '000660',
  SMSN: '005930', KB: '105560', SHG: '055550',
  JBHT: 'ext-j-b-hunt', CF: 'ext-cf-industries', MAS: 'ext-masco',
};

export function issuerForHolding(rawTicker: string): string | undefined {
  const ticker = rawTicker.trim().toUpperCase();
  if (/^BRK[./ -]?[AB]$/.test(ticker)) return 'BRK.B';
  const localCode = /^(?:KRX:|KS)?(\d{6})(?:\.KS| KS)?$/.exec(ticker)?.[1];
  const symbol = localCode ?? ticker;
  return listed.has(symbol) ? symbol : aliases[symbol];
}

export const reviewedEtfIssuers = [...new Set([...listed, ...Object.values(aliases)])];
type MembershipRows = Record<string, HoldingPosition[]>;

// Astro runs this only at build time. The client gets ranks for the companies
// in this explorer, not every security in the three full portfolios.
export const companyEtfMembership = reports.filter(report => guides[report.ticker]).map(report => {
  const members: MembershipRows = {};
  [...report.holdings].sort((a,b)=>b.weight-a.weight).forEach((row, index) => {
    const id = issuerForHolding(row.ticker);
    if (id) (members[id] ??= []).push([index + 1, row.ticker, row.weight]);
  });
  return { ticker:report.ticker, path:guides[report.ticker], asOf:report.asOf, complete:report.coverage?.complete === true, members };
});

if (Object.keys(guides).some(ticker => !reports.some(report => report.ticker === ticker && report.asOf && report.holdings.length))) {
  throw new Error('Missing dated VOO, QQQM or SCHD holdings for the company membership panels');
}
