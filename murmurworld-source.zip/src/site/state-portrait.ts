type Portrait = { card: HTMLElement; story: HTMLDetailsElement; preferredOpen?: boolean };

export function mountStatePortrait(guide: HTMLElement) {
  const map = guide.closest<HTMLElement>('[data-market-us-map]');
  if (!map || guide.dataset.portraitMounted) return;
  guide.dataset.portraitMounted = 'true';
  const lang = guide.dataset.stateLanguage === 'en' ? 'en' : 'ko';
  const body = guide.querySelector<HTMLElement>('[data-portrait-body]')!;
  const feedback = guide.querySelector<HTMLElement>('[data-portrait-feedback]')!;
  const message = guide.querySelector<HTMLElement>('[data-portrait-message]')!;
  const retry = guide.querySelector<HTMLButtonElement>('[data-portrait-retry]')!;
  const cache = new Map<string, Portrait>();
  const pending = new Map<string, Promise<Portrait>>();
  let selected = 'US';
  let company = '';
  let revision = 0;

  guide.addEventListener('click', event => {
    const target = event.target instanceof Element ? event.target : null;
    const atlas = target?.closest<HTMLElement>('[data-place-atlas]');
    if (!target || !atlas) return;
    const jump = target.closest<HTMLElement>('[data-place-jump]');
    if (jump) {
      const {lat,lon,label} = jump.dataset;
      map.querySelector('[data-location-map]')?.dispatchEvent(new CustomEvent('location-map:visit-place', {
        detail:{state:atlas.dataset.placeState,lat:Number(lat),lon:Number(lon),label,kind:jump.dataset.areaKind},
      }));
      return;
    }
    const control = target.closest('[data-place-mode],[data-place-pick]');
    if (!control) return;
    event.preventDefault();
    let pick = control.getAttribute('data-place-pick');
    const mode = control.getAttribute('data-place-mode');
    if (mode) {
      atlas.querySelectorAll('[data-place-surface]').forEach(surface =>
        surface.toggleAttribute('hidden', surface.getAttribute('data-place-surface') !== mode));
      atlas.querySelectorAll('button[data-place-mode]').forEach(button =>
        button.setAttribute('aria-pressed',String(button.getAttribute('data-place-mode')===mode)));
      pick = atlas.querySelector('.place-labels:not([hidden]) [data-place-pick]')?.getAttribute('data-place-pick') ?? null;
    }
    if (pick === null) return;
    atlas.querySelectorAll('[data-place-pick]').forEach(item => {
      const active = item.getAttribute('data-place-pick') === pick;
      item.toggleAttribute('data-selected',active);
      if (item.tagName === 'BUTTON') item.setAttribute('aria-pressed',String(active));
    });
    atlas.querySelectorAll('[data-place-note]').forEach(note =>
      note.toggleAttribute('hidden',note.getAttribute('data-place-note') !== pick));
  });

  function read(state: string): Promise<Portrait> {
    const existing = pending.get(state);
    if (existing) return existing;
    const request = (async () => {
      const response = await fetch(`/data/state-portraits/${lang}/${state.toLowerCase()}/`, {
        credentials: 'same-origin',
      });
      if (!response.ok) throw Error('State guide unavailable');
      const template = document.createElement('template');
      template.innerHTML = await response.text();
      const cards = template.content.querySelectorAll<HTMLElement>('article[data-portrait]');
      const card = cards[0];
      const story = card?.querySelector<HTMLDetailsElement>('[data-place-story]');
      const summary = story?.querySelector('summary');
      if (cards.length !== 1 || card.dataset.portrait !== state || card.dataset.portraitLanguage !== lang
          || !story || !summary) throw Error('Unexpected state guide');
      const portrait: Portrait = { card, story };
      // Mouse, touch and keyboard activation of a native summary all fire click before toggling.
      summary.addEventListener('click', () => { portrait.preferredOpen = !story.open; });
      cache.set(state, portrait);
      return portrait;
    })().finally(() => pending.delete(state));
    pending.set(state, request);
    return request;
  }

  function display(portrait: Portrait) {
    const { card, story } = portrait;
    const retryHadFocus = document.activeElement === message;
    story.open = portrait.preferredOpen ?? !company;
    if (card.parentElement !== body) body.replaceChildren(card);
    // Keep images inside an inert template even for downloaded guides until the selection still matches.
    const photo = card.querySelector<HTMLTemplateElement>('template[data-state-photo]');
    if (photo) photo.replaceWith(photo.content);
    guide.removeAttribute('aria-busy');
    feedback.hidden = true;
    if (retryHadFocus) {
      const heading = card.querySelector<HTMLElement>('h3');
      if (heading) { heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
    }
  }

  function show(state: string, ticker: string, force = false) {
    if (!/^[A-Z]{2}$/.test(state)) state = 'US';
    const changed = selected !== state;
    company = ticker;
    selected = state;
    guide.hidden = state === 'US';
    if (guide.hidden) {
      ++revision;
      body.replaceChildren();
      feedback.hidden = true;
      guide.removeAttribute('aria-busy');
      return;
    }
    const known = cache.get(state);
    if (known) {
      if (changed) ++revision;
      display(known);
      return;
    }
    if (!changed && !force) return;
    const requestId = ++revision;
    body.replaceChildren();
    feedback.hidden = false;
    retry.hidden = true;
    message.textContent = lang === 'en' ? 'Loading the state guide…' : '주 정보를 불러오는 중이에요.';
    guide.setAttribute('aria-busy', 'true');
    read(state).then(portrait => {
      if (revision === requestId && selected === state) display(portrait);
    }).catch(() => {
      if (revision !== requestId || selected !== state) return;
      guide.removeAttribute('aria-busy');
      message.textContent = lang === 'en' ? 'The state guide could not be loaded.' : '주 정보를 불러오지 못했어요.';
      retry.hidden = false;
    });
  }

  retry.addEventListener('click', () => {
    if (document.activeElement === retry) {
      message.tabIndex = -1;
      message.focus({ preventScroll: true });
    }
    show(selected, company, true);
  });
  map.addEventListener('market-location-view', event => {
    const view = (event as CustomEvent<{state:string; company:string}>).detail;
    show(view.state, view.company);
  });
  show(map.dataset.locationState || 'US', map.dataset.locationCompany || '', true);
}
