import { coordinates, projectedFrame, type Inset } from './map-geography';
import { decodeStreetTile, svgNode, tilePosition, type RenderedTile, type TileID } from './street-tile';

type Box={x:number;y:number;w:number;h:number};
type View={box:Box;inset:Inset;px:number;ids:TileID[];z:number};
type Source={template:string;max:number};
const origin='https://tiles.openfreemap.org';
const key=(id:TileID,inset:Inset)=>[inset,id.z,id.x,id.y].join('/');
const fetchOptions={credentials:'omit',referrerPolicy:'no-referrer'} as const;
function viewTiles(box:Box,inset:Inset,px:number,max:number):View {
  const middle=coordinates({x:box.x+box.w/2,y:box.y+box.h/2,inset});
  const mpp=1/(px*projectedFrame(inset).scale);
  let z=Math.min(max,Math.max(0,Math.round(Math.log2(40075017*Math.cos(middle.latitude*Math.PI/180)/(mpp*440)))));
  // In Alaska, longitudes can wrap at the date line. Index each sample near the centre.
  for(;;z--) {
    const n=2**z, centre=tilePosition(middle.longitude,middle.latitude,z);
    const samples=[0,.5,1].flatMap(dx=>[0,.5,1].map(dy=>{
      const geo=coordinates({x:box.x+dx*box.w,y:box.y+dy*box.h,inset});
      const t=tilePosition(geo.longitude,geo.latitude,z);
      return {x:t.x+Math.round((centre.x-t.x)/n)*n,y:t.y};
    }));
    const left=Math.floor(Math.min(...samples.map(p=>p.x))),right=Math.floor(Math.max(...samples.map(p=>p.x)));
    const top=Math.max(0,Math.floor(Math.min(...samples.map(p=>p.y)))),bottom=Math.min(n-1,Math.floor(Math.max(...samples.map(p=>p.y))));
    if((right-left+1)*(bottom-top+1)>32 && z>0)continue;
    const ids:TileID[]=[];
    for(let x=left;x<=right;x++)for(let y=top;y<=bottom;y++)ids.push({z,x:(x%n+n)%n,y});
    ids.sort((a,b)=>Math.hypot(a.x+.5-centre.x,a.y+.5-centre.y)-Math.hypot(b.x+.5-centre.x,b.y+.5-centre.y));
    return {box,inset,px,ids,z};
  }
}

export function mountStreetLayer(root:HTMLElement, svg:SVGSVGElement) {
  const group=svg.querySelector<SVGGElement>('[data-street-layer]')!, names=svgNode('g');
  const status=root.querySelector<HTMLElement>('[data-street-status]')!,retry=root.querySelector<HTMLButtonElement>('[data-street-retry]')!;
  const en=root.dataset.lang==='en';
  let source:Source|undefined, metadata:Promise<void>|undefined, current:View|undefined;
  let timer=0,frame=0,oldInset:Inset|undefined;
  const cache=new Map<string,RenderedTile>(), pending=new Map<string,AbortController>(), failed=new Map<string,number>();
  let metadataFailed=false;
  names.setAttribute('data-street-names','');group.append(names);
  function message(text:string, canRetry=false) {
    status.parentElement!.hidden=!text;retry.hidden=!canRetry;
    if(status.textContent!==text)status.textContent=text;
  }
  function scheduleDraw() { if(!frame)frame=requestAnimationFrame(()=>{frame=0;paint();}); }
  function paint() {
    const view=current;if(!view)return;
    const visible=view.ids.map(id=>cache.get(key(id,view.inset))).filter((t):t is RenderedTile=>!!t);
    if(oldInset!==view.inset || visible.length===view.ids.length) {
      const needed=new Set(visible.map(t=>t.group));
      for(const child of Array.from(group.children))if(child!==names && !needed.has(child as SVGGElement))child.remove();
    }
    // Already drawn vectors stay registered to the atlas during the next level's fetch.
    oldInset=view.inset;
    for(const tile of visible)if(tile.group.parentNode!==group)group.insertBefore(tile.group,names);
    svg.toggleAttribute('data-street-drawn',group.children.length>1);
    const {px,box}=view,W=box.w*px,H=box.h*px;
    const occupied:{x:number;y:number;w:number;h:number}[]=[{x:W-132,y:0,w:132,h:37},{x:0,y:H-26,w:115,h:26}];
    const seen=new Set<string>(), next=document.createDocumentFragment();
    for(const label of visible.flatMap(t=>t.labels).sort((a,b)=>a.priority-b.priority)) {
      const street=label.kind==='street',size=street?10.7:label.kind==='water'?11:12;
      const w=Math.min(270,[...label.text].reduce((n,c)=>n+(c.charCodeAt(0)>255?1:.57),0)*size)+6;
      if(seen.has(label.text) || street && label.span*px<w*.85)continue;
      const x=(label.x-box.x)*px,y=(label.y-box.y)*px,angle=label.angle*Math.PI/180;
      const width=w*Math.abs(Math.cos(angle))+15*Math.abs(Math.sin(angle)),height=15*Math.abs(Math.cos(angle))+w*Math.abs(Math.sin(angle));
      const b={x:x-width/2,y:y-height/2,w:width,h:height};
      if(b.x<4 || b.y<4 || b.x+b.w>W-4 || b.y+b.h>H-4 || occupied.some(a=>a.x<b.x+b.w+3 && a.x+a.w+3>b.x && a.y<b.y+b.h+3 && a.y+a.h+3>b.y))continue;
      const t=svgNode('text');t.dataset.labelKind=label.kind;t.textContent=label.text;
      t.setAttribute('transform','translate('+label.x+' '+label.y+') scale('+1/px+') rotate('+label.angle.toFixed(1)+')');
      t.setAttribute('font-size',String(size));next.append(t);occupied.push(b);seen.add(label.text);
      if(seen.size>(W<540?25:64))break;
    }
    names.replaceChildren(next);
    const missing=view.ids.some(id=>failed.has(key(id,view.inset)));
    if(missing || metadataFailed)message(en?'Some street data could not load.':'일부 도로 정보를 불러오지 못했어요.',true);
    else if(visible.length<view.ids.length && !visible.length)message(en?'Loading streets…':'도로 정보를 불러오는 중…');
    else message('');
  }
  async function readSource() {
    const controller=new AbortController(), timeout=window.setTimeout(()=>controller.abort(),10000);
    try {
      const r=await fetch(origin+'/planet',{...fetchOptions,signal:controller.signal});
      if(!r.ok)throw Error();
      const data=await r.json(),template=data.tiles?.[0];
      if(typeof template!=='string' || new URL(template).origin!==origin || !['{z}','{x}','{y}'].every(s=>template.includes(s)))throw Error();
      source={template,max:Math.max(0,Math.min(16,Number(data.maxzoom ?? 14)))};metadataFailed=false;
      if(current){current=viewTiles(current.box,current.inset,current.px,source.max);load();}
    }catch{metadataFailed=true;scheduleDraw();}
    finally{clearTimeout(timeout);metadata=undefined;}
  }
  async function fetchTile(id:TileID,inset:Inset,token:string,controller:AbortController) {
    const timeout=window.setTimeout(()=>controller.abort(),12000);
    try {
      const url=source!.template.replace('{z}',String(id.z)).replace('{x}',String(id.x)).replace('{y}',String(id.y));
      const r=await fetch(url,{...fetchOptions,signal:controller.signal});
      if(!r.ok)throw Error();
      const bytes=await r.arrayBuffer();
      if(pending.get(token)!==controller)return;
      cache.set(token,decodeStreetTile(bytes,id,inset,en));failed.delete(token);
      while(cache.size>56) {
        const oldest=Array.from(cache.entries()).find(([,item])=>item.group.parentNode!==group);
        if(!oldest)break;
        cache.delete(oldest[0]);
      }
    }catch{if(pending.get(token)===controller)failed.set(token,Date.now());}
    finally{
      clearTimeout(timeout);
      if(pending.get(token)===controller){pending.delete(token);scheduleDraw();if(current)load();}
    }
  }
  function load() {
    const view=current;if(!view)return;
    if(!source){if(!metadata && !metadataFailed)metadata=readSource();return;}
    for(const id of view.ids) {
      if(pending.size>=4)break;
      const token=key(id,view.inset);if(cache.has(token) || pending.has(token) || Date.now()-(failed.get(token) ?? 0)<60000)continue;
      const controller=new AbortController();pending.set(token,controller);void fetchTile(id,view.inset,token,controller);
    }
  }
  function update(box:Box,inset:Inset,enabled:boolean) {
    const px=svg.getScreenCTM()?.a ?? 0;
    if(!enabled || !(px>0)) {
      if(!current)return;
      current=undefined;clearTimeout(timer);
      for(const task of pending.values())task.abort();
      pending.clear();names.replaceChildren();group.replaceChildren(names);svg.removeAttribute('data-street-drawn');svg.removeAttribute('data-street-detail');message('');return;
    }
    current=viewTiles(box,inset,px,source?.max ?? 14);
    svg.dataset.streetDetail=current.z<9?'region':current.z<13?'town':'street';
    const wanted=new Set(current.ids.map(id=>key(id,inset)));
    for(const [token,task] of pending)if(!wanted.has(token)){pending.delete(token);task.abort();}
    // Only retain nearby coverage while loading. After a long jump a previous
    // city's tiles must not count as a street map for the new location.
    for(const child of Array.from(group.querySelectorAll<SVGGElement>(':scope > [data-street-tile]'))) {
      const [z,x,y]=child.dataset.streetTile!.split('/').map(Number), ratio=2**(current.z-z);
      const overlaps=Math.abs(current.z-z)<=2 && current.ids.some(id=>
        x*ratio<id.x+1 && (x+1)*ratio>id.x && y*ratio<id.y+1 && (y+1)*ratio>id.y);
      if(oldInset!==inset || !overlaps)child.remove();
    }
    scheduleDraw();clearTimeout(timer);timer=window.setTimeout(load,100);
  }
  retry.addEventListener('click',()=>{failed.clear();metadataFailed=false;svg.focus({preventScroll:true});load();scheduleDraw();});
  return update;
}
