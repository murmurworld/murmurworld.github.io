import { siteKind } from './location-roles';
import { projectLocation } from './map-geography';

type Point = {x:number; y:number};
type Box = Point & {w:number; h:number};
type Site = Point & {ticker:string; city:string; state:string; hq:boolean; kind:string; name?:string};
type Edge = {id:string; peer:string; label:string; kind:string; direction:'in'|'out'|'joint'};
type Selection = {company:string; edges:Edge[]; selected:string};
const ns='http://www.w3.org/2000/svg';
const node=<K extends keyof SVGElementTagNameMap>(tag:K)=>document.createElementNS(ns,tag);
const inset=(state:string)=>state==='AK' || state==='HI' ? state : 'mainland';
const overlaps=(a:Box,b:Box)=>a.x < b.x+b.w && b.x < a.x+a.w && a.y < b.y+b.h && b.y < a.y+a.h;

// Prefer a documented headquarters. If several other sites remain equally
// plausible, keep that relationship in the list without choosing a city for it.
function representative<T extends Site>(all:T[], state=''):T|undefined {
  const local=all.filter(p=>p.state===state), pool=local.length?local:all;
  for(const tier of [pool.filter(p=>p.hq), pool.filter(p=>['regional','subsidiary','second','ops'].includes(p.kind)), pool]) {
    if(!tier.length)continue;
    if(tier.every(p=>p.x===tier[0].x && p.y===tier[0].y))return tier[0];
    return undefined;
  }
}

function graphic(edge:Edge,number:number) {
  const link=node('a'), title=node('title'), hit=node('path'), halo=node('path'), line=node('path');
  const start=node('circle'),end=node('circle'), arrow=node('path'),tag=node('g'),disk=node('circle'),text=node('text');
  const badge=node('a'),leader=node('path'),finger=node('circle'),cityName=node('text');
  cityName.dataset.geoExternalName='';
  Object.assign(link.dataset,{geoRelation:edge.id,peer:edge.peer,direction:edge.direction,geoNumber:String(number),kind:edge.kind});
  Object.assign(badge.dataset,{geoRelationBadge:edge.id,direction:edge.direction,kind:edge.kind});
  badge.setAttribute('href','#relationships');badge.setAttribute('aria-hidden','true');badge.setAttribute('tabindex','-1');
  link.setAttribute('href','#relationships'); link.setAttribute('role','button');
  hit.dataset.geoRelationHit=''; halo.dataset.geoLineHalo=''; line.dataset.geoLine='';
  start.dataset.geoEnd='';end.dataset.geoEnd='';arrow.dataset.geoChevron='';
  arrow.setAttribute('d','M-5 -4.5 L5 0 L-5 4.5 Z');
  tag.dataset.geoRelationNumber='';disk.setAttribute('r','9.1');text.setAttribute('y','3.8');text.textContent=String(number);
  leader.dataset.geoLeader='';finger.setAttribute('r','14');finger.dataset.geoFinger='';
  tag.append(finger,disk,text);link.append(title,halo,line,start,end,arrow,hit,cityName);badge.append(leader,tag);
  return {link,title,hit,halo,line,start,end,arrow,tag,badge,leader,cityName,edge,number};
}

// A cubic also provides a small loop for companies which share a city.
function curve(a:Point,b:Point,px:number,lane:number,compact:boolean) {
  const dx=b.x-a.x,dy=b.y-a.y,length=Math.hypot(dx,dy);
  const bend=(compact && length*px<125 ? Math.max(30/px, length*.25) : Math.min(length*.18,34/px))+lane*(compact?33:20)/px;
  const lift=Math.max(23,32+lane*12)/px;
  const c=length<.01 ? {x:a.x-lift,y:a.y-1.7*lift} : {x:a.x+dx/3-dy/length*bend,y:a.y+dy/3+dx/length*bend};
  const d=length<.01 ? {x:a.x+lift,y:a.y-1.7*lift} : {x:a.x+2*dx/3-dy/length*bend,y:a.y+2*dy/3+dx/length*bend};
  return {
    path:`M${a.x},${a.y} C${c.x},${c.y} ${d.x},${d.y} ${b.x},${b.y}`,
    bounds:{x:Math.min(a.x,b.x,c.x,d.x),y:Math.min(a.y,b.y,c.y,d.y),
      w:Math.max(a.x,b.x,c.x,d.x)-Math.min(a.x,b.x,c.x,d.x),h:Math.max(a.y,b.y,c.y,d.y)-Math.min(a.y,b.y,c.y,d.y)},
    at(t:number):Point{
      const u=1-t;
      return {x:u**3*a.x+3*u*u*t*c.x+3*u*t*t*d.x+t**3*b.x,y:u**3*a.y+3*u*u*t*c.y+3*u*t*t*d.y+t**3*b.y};
    }
  };
}

export function mountMapRelations<T extends Site>(root:HTMLElement,sites:T[],allLocations:ReadonlyArray<readonly [string,string,...string[]]>,repaint:()=>void) {
  const layer=root.querySelector<SVGGElement>('[data-geo-relations]')!;
  const badges=root.querySelector<SVGGElement>('[data-geo-relation-badges]')!;
  const key=root.querySelector<HTMLElement>('[data-geo-relation-key]')!;
  const count=key.querySelector<HTMLElement>('[data-geo-relation-count]')!;
  const owner=root.closest<HTMLElement>('[data-market-us-map]')!;
  const en=root.dataset.lang==='en';
  const sitesByTicker=new Map<string,Site[]>();
  for(const site of sites) {
    const rows=sitesByTicker.get(site.ticker) ?? [];
    rows.push(site);sitesByTicker.set(site.ticker,rows);
  }
  const extra=JSON.parse(root.querySelector('[data-geo-counterparties]')!.textContent!) as
    {ticker:string;name:string;city:string;state:string;lat:number;lon:number}[];
  for(const s of extra)sitesByTicker.set(s.ticker,[{...projectLocation(s.lon,s.lat,''),...s,hq:true,kind:'hq'}]);
  let selection:Selection={company:'',edges:[],selected:''};
  let shapes:ReturnType<typeof graphic>[]=[];
  let active='',state='',explicit:T|undefined;
  let origin:Site|undefined, anchors=new Map<string,Site>();
  const focusCompany=()=>active || (selection.company.startsWith('ext-') && sitesByTicker.has(selection.company)?selection.company:'');
  function locate() {
    const focused=focusCompany(),current=selection.company===focused && !!focused;
    const companySites=sitesByTicker.get(focused) ?? [];
    const localRecord=state && allLocations.some(([region,ticker])=>region===state && ticker===focused);
    const candidates=localRecord ? companySites.filter(p=>p.state===state) : companySites;
    origin=current ? explicit ?? representative(candidates,state) : undefined;
    anchors=new Map();
    if(origin)for(const edge of selection.edges) {
      if(anchors.has(edge.peer))continue;
      const peer=representative(sitesByTicker.get(edge.peer) ?? []);
      // Do not join the relocated Alaska or Hawaii insets across projection frames.
      if(peer && inset(peer.state)===inset(origin.state))anchors.set(edge.peer,peer);
    }
  }
  function label(site:Site) {
    const role=siteKind({role:site.hq?'hq':'facility',kind:site.kind},en?'en':'ko');
    return (site.name ?? site.ticker)+' · '+site.city+', '+site.state+' ('+role+')';
  }
  function receive(event:Event) {
    const data=(event as CustomEvent<Selection>).detail;
    if(!data || !Array.isArray(data.edges))return;
    const previous=new Map(shapes.map(item=>[item.edge.id,item]));
    selection=data;
    shapes=data.edges.map((edge,i)=>{
      const old=previous.get(edge.id);
      if(old && old.number===i+1 && old.edge.peer===edge.peer && old.edge.direction===edge.direction) {
        previous.delete(edge.id);old.edge=edge;return old;
      }
      const item=graphic(edge,i+1);layer.append(item.link);badges.append(item.badge);return item;
    });
    for(const old of previous.values()){old.link.remove();old.badge.remove();}
    locate();repaint();
  }
  owner.addEventListener('location-map:relations',receive);
  function click(element:Element) {
    const link=element.closest<SVGAElement>('[data-geo-relation],[data-geo-relation-badge]');
    if(!link || !root.contains(link))return false;
    const id=link.dataset.geoRelation ?? link.dataset.geoRelationBadge!;
    root.dispatchEvent(new CustomEvent('location-map:relation-select',{bubbles:true,
      detail:{company:focusCompany(),id:id===selection.selected?'':id}}));
    return true;
  }
  function draw(box:Box,px:number,area:string,cityScale:boolean,occupied:Box[]) {
    const focused=focusCompany(),current=!!focused && selection.company===focused, drawn=shapes.filter(({edge})=>anchors.has(edge.peer)).length;
    key.hidden=!current || !shapes.length;
    if(!key.hidden) {
      const chosen=selection.edges.find(edge=>edge.id===selection.selected);
      const summary=cityScale ? (en?'Company links appear at regional scale.':'기업 관계선은 광역 배율에서 보여요.') :
        chosen && !anchors.has(chosen.peer) ? (en?'This connection has no pair of mapped U.S. cities.':'선택한 관계는 양쪽 미국 거점 도시를 지도에서 특정할 수 없어요.') :
        en?`Mapped relationships: ${drawn} of ${shapes.length}`:`미국 거점을 연결한 관계 ${drawn}/${shapes.length}건`;
      if(count.textContent!==summary)count.textContent=summary;
    }
    const lanes=new Map<string,number>();
    const labeled=new Set<string>();
    // Resolve duplicate pairs in network order before prioritizing the selected badge.
    const tracks=shapes.map(shape=>{
      const endpoint=anchors.get(shape.edge.peer), place=endpoint?.x+'|'+endpoint?.y;
      const i=lanes.get(place) ?? 0; lanes.set(place,i+1);
      return {shape,endpoint,lane:i%2 ? (i+1)/2 : -i/2};
    }).sort((a,b)=>Number(b.shape.edge.id===selection.selected)-Number(a.shape.edge.id===selection.selected));
    for(const {shape:s,endpoint:peer,lane} of tracks) {
      const eligible=current && !cityScale && origin && peer && (area==='overview' || area===inset(origin.state));
      const compact=box.w*px<540;
      const r=eligible ? curve(origin!,peer!,px,lane,compact) : undefined;
      const show=!!r && overlaps({...r.bounds,w:Math.max(r.bounds.w,1/px),h:Math.max(r.bounds.h,1/px)},box);
      s.link.style.display=show?'':'none';s.link.setAttribute('tabindex',show?'0':'-1');
      const selected=s.edge.id===selection.selected;
      s.link.setAttribute('aria-pressed',String(selected));
      s.badge.style.display='none';s.badge.toggleAttribute('data-selected',selected);
      if(!show || !r || !origin || !peer)continue;
      const dir=s.edge.direction,stage=['design','showcase','production','agreement'].includes(s.edge.kind);
      const caption=s.number+'. '+label(dir==='in'?peer:origin)+(dir==='joint'?' ↔ ':stage?' · ':' → ')+label(dir==='in'?origin:peer)+' · '+s.edge.label;
      const ext=peer.name ? peer : origin.name ? origin : undefined;
      s.cityName.style.display='none';
      if(ext && !labeled.has(ext.ticker)){
        const name=ext.name+' · '+ext.city,w=name.length*6.4/px,h=16/px;
        for(const [dx,dy] of [[7/px,-6/px],[7/px,16/px],[-w-7/px,-6/px],[-w-7/px,16/px]]){
          const b={x:ext.x+dx,y:ext.y+dy-h,w,h};
          if(b.x<box.x || b.y<box.y || b.x+b.w>box.x+box.w || b.y+b.h>box.y+box.h || occupied.some(a=>overlaps(a,b)))continue;
          s.cityName.textContent=name;s.cityName.style.display='';
          s.cityName.setAttribute('transform',`translate(${b.x} ${ext.y+dy}) scale(${1/px})`);occupied.push(b);labeled.add(ext.ticker);break;
        }
      }
      if(s.title.textContent!==caption){s.title.textContent=caption;s.link.setAttribute('aria-label',caption);}
      for(const path of [s.line,s.halo,s.hit])path.setAttribute('d',r.path);
      for(const [dot,p] of [[s.start,origin],[s.end,peer]] as const){
        dot.setAttribute('cx',String(p.x));dot.setAttribute('cy',String(p.y));dot.setAttribute('r',String(2.7/px));
      }
      s.arrow.style.display=dir==='joint' || stage?'none':'';
      if(dir!=='joint' && !stage){
        const t=dir==='in'?.25:.75,p=r.at(t),q=r.at(t+(dir==='in'?-.01:.01));
        const deg=Math.atan2(q.y-p.y,q.x-p.x)*180/Math.PI;
        s.arrow.setAttribute('transform',`translate(${p.x} ${p.y}) scale(${1/px}) rotate(${deg})`);
      }
      // Near Silicon Valley, several cities and multiple disclosures may fit in
      // one fingertip. Give each number its own hit target and, if necessary,
      // a short leader to the curve. Keep badges above all lines.
      const rad=(compact?15:12)/px;
      position:for(const offset of [0,20,36,52,70,92,116]){
        for(const t of [.54,.38,.69,.22,.84,.12,.92]){
          const point=r.at(t);
          if(point.x<box.x || point.x>box.x+box.w || point.y<box.y || point.y>box.y+box.h)continue;
          for(let angle=0;angle<(offset?8:1);angle++){
            const theta=(angle+.4)*Math.PI/4,x=point.x+Math.cos(theta)*offset/px,y=point.y+Math.sin(theta)*offset/px;
            const b={x:x-rad,y:y-rad,w:rad*2,h:rad*2};
            if(b.x<box.x || b.y<box.y || b.x+b.w>box.x+box.w || b.y+b.h>box.y+box.h || occupied.some(a=>overlaps(a,b)))continue;
            s.badge.style.display='';s.tag.setAttribute('transform',`translate(${x} ${y}) scale(${1/px})`);
            s.leader.setAttribute('d',offset?`M${point.x} ${point.y}L${x} ${y}`:'');
            occupied.push(b);break position;
          }
        }
      }
      if(selected && layer.lastElementChild!==s.link && !s.link.matches(':focus'))layer.append(s.link);
    }
  }
  return {click,draw,isAnchor:(p:T)=>p===origin || anchors.get(p.ticker)===p,
    isPriority:(p:T)=>p===origin || (anchors.get(p.ticker)===p && selection.edges.some(e=>e.id===selection.selected && e.peer===p.ticker)),
    setCompany(company:string,region:string,picked?:T){
      active=company;state=region;explicit=picked?.ticker===company && picked.state===region?picked:undefined;locate();
    },
    request:()=>root.dispatchEvent(new CustomEvent('location-map:relations-request',{bubbles:true}))};
}
