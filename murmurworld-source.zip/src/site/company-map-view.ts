type MapSelection = { state?: string; company?: string; sector?: string; focus?: boolean; national?: boolean };
type XY = { x: number; y: number };
type Box = XY & { w: number; h: number };
type SiteRow = [state: string, ticker: string, sector: string, city: string];
type Pin = { link: SVGAElement; state: string; ticker: string; sector: string; city: string; hq: boolean; x: number; y: number };
const full = { w: 885, h: 542 };
const maxZoom = 12;
const featured = ['NVDA','TSLA','MSFT','JPM','TSM','KO','WMT','MU','LLY','PLTR','BRK.B','NEM','AAPL','AMZN','XOM','TXN','005930','ORCL','INTC','GE','AMD','LRCX'];
const showcase = ['CA|NVDA','TX|TSLA','WA|MSFT','NY|JPM','AZ|TSM','GA|KO','NE|BRK.B','AR|WMT','ID|MU','IN|LLY','FL|PLTR','CO|NEM'];
const rank = (ticker: string) => {
  const i = featured.indexOf(ticker);
  return i < 0 ? featured.length : i;
};
const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
const intersects = (a: Box, b: Box, gap: number) => a.x < b.x + b.w + gap && b.x < a.x + a.w + gap
  && a.y < b.y + b.h + gap && b.y < a.y + a.h + gap;

export function mountCompanyMap(root: HTMLElement) {
  if (root.dataset.geoReady) return;
  root.dataset.geoReady = 'true';
  const svg = root.querySelector<SVGSVGElement>('[data-geo-surface]')!;
  const stateLinks = [...svg.querySelectorAll<SVGAElement>('[data-geo-state]')];
  const abbreviations = [...svg.querySelectorAll<SVGTextElement>('[data-state-abbr]')];
  const dots = [...svg.querySelectorAll<SVGCircleElement>('[data-city]')];
  const cityLabels = new Map([...svg.querySelectorAll<SVGTextElement>('[data-city-label]')].map(el=>[el.dataset.cityLabel!,el]));
  const pins: Pin[] = [...svg.querySelectorAll<SVGAElement>('[data-geo-pin]')].map(link => ({
    link, state:link.dataset.pinState!, ticker:link.dataset.geoPin!, sector:link.dataset.sector!, city:link.dataset.cityName!,
    hq:link.dataset.role === 'hq', x:Number(link.dataset.x), y:Number(link.dataset.y),
  }));
  const rows: SiteRow[] = JSON.parse(root.querySelector('[data-geo-rows]')!.textContent!);
  const controls = root.querySelector<HTMLElement>('.geo-controls')!;
  const zoomIn = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="in"]')!;
  const zoomOut = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="out"]')!;
  const reset = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="reset"]')!;
  const scaleLabel = root.querySelector<HTMLElement>('[data-geo-scale]')!;
  const en = root.dataset.lang === 'en';
  let selected = '', company = '', sector = '';
  let zoom = 1, center: XY = { x:full.w/2, y:full.h/2 };
  let box: Box = { x:0, y:0, ...full };
  const cityKey = (p: Pin) => p.state + '|' + p.city;
  let currentCities = new Set<string>();
  const widthFor = (ticker: string) => Math.max(32, 12 + ticker.length * 7);
  function surfacePoint(clientX: number, clientY: number): XY {
    const matrix = svg.getScreenCTM();
    if (!matrix) return center;
    return new DOMPoint(clientX,clientY).matrixTransform(matrix.inverse());
  }
  function setRect(rect: SVGRectElement, w: number, h: number) {
    rect.setAttribute('x', String(-w/2)); rect.setAttribute('width', String(w));
    rect.setAttribute('y', String(-h/2)); rect.setAttribute('height', String(h));
  }
  // Pack clickable labels in screen pixels. The point at the end of the leader stays at the Census city reference.
  function drawMarkers(px: number) {
    const occupied: Box[] = [];
    const matrix = svg.getScreenCTM();
    if (!matrix) return;
    const controlBounds = controls.getBoundingClientRect();
    const topLeft = surfacePoint(controlBounds.left, controlBounds.top);
    const bottomRight = surfacePoint(controlBounds.right, controlBounds.bottom);
    occupied.push({x:topLeft.x, y:topLeft.y, w:bottomRight.x-topLeft.x, h:bottomRight.y-topLeft.y});
    const compact = svg.getBoundingClientRect().width < 500;
    const national = zoom < 1.7;
    const stateView = Boolean(!national && selected);
    // Alaska and Hawaii are insets on the national map. A mainland close-up must not place them in the Gulf or Mexico.
    const inset = (code: string) => code==='AK' || code==='HI';
    const omitInset = (code: string) => stateView && (inset(selected) ? code!==selected : inset(code));
    for (const link of stateLinks) link.toggleAttribute('data-suppressed',omitInset(link.dataset.geoState!));
    const limit = company ? 15 : national ? compact ? 5 : 9 : compact && zoom<3 ? 6 : compact ? 10 : 20;
    let drawn = 0;
    const seenStates = new Set<string>();
    const seenSymbols = new Set<string>();
    const sampleRank = (p: Pin) => { const i=showcase.indexOf(p.state+'|'+p.ticker); return i<0?showcase.length:i; };
    const ordered = pins.filter(p => (!stateView || p.state===selected) && currentCities.has(cityKey(p)) && (!company || company === p.ticker) && (!sector || p.sector === sector))
      .sort((a,b) => (national&&!company ? sampleRank(a)-sampleRank(b) : 0)
        || rank(a.ticker)-rank(b.ticker)
        || Number(b.hq)-Number(a.hq) || a.ticker.localeCompare(b.ticker));
    for (const label of cityLabels.values()) label.setAttribute('data-suppressed','');
    if (stateView) {
      // Preserve a few city names before laying out ticker badges, especially when several companies share a city.
      const density=new Map<string,number>();
      for (const p of ordered) density.set(cityKey(p),(density.get(cityKey(p)) ?? 0)+1);
      const names=[...density.keys()].sort((a,b)=>density.get(b)!-density.get(a)!);
      let count=0;
      for (const key of names) {
        if (count>=(compact?3:6)) break;
        const city=ordered.find(p=>cityKey(p)===key)!;
        const label=cityLabels.get(key)!;
        const w=city.city.length*6.25/px, h=12/px;
        for (const [dx,dy] of [[4,13],[4,-5],[-w*px-4,13],[-w*px-4,-5],[4,24],[-w*px-4,24]]) {
          const x=city.x+dx/px,y=city.y+dy/px;
          const bounds={x,y:y-h,w,h};
          if (bounds.x<box.x || bounds.x+w>box.x+box.w || bounds.y<box.y || bounds.y+h>box.y+box.h
            || occupied.some(other=>intersects(bounds,other,1.5/px))) continue;
          label.setAttribute('transform','translate('+x+' '+y+') scale('+(1/px)+')');
          label.removeAttribute('data-suppressed'); occupied.push(bounds); count++; break;
        }
      }
    }
    for (const p of pins) {
      p.link.toggleAttribute('data-pin-hidden',true); p.link.setAttribute('tabindex','-1');
    }
    for (const p of ordered) {
      if (drawn >= limit) break;
      if (national && !company && (seenStates.has(p.state) || seenSymbols.has(p.ticker) || (rank(p.ticker) === featured.length && !sector))) continue;
      if (stateView && !company && compact && zoom<3 && seenSymbols.has(p.ticker)) continue;
      if (p.x < box.x || p.y < box.y || p.x > box.x+box.w || p.y > box.y+box.h) continue;
      const w = widthFor(p.ticker)/px, h = 19/px, gap = 3/px;
      const dx = w/2+6/px, dy = h/2+5/px;
      const places = [[dx,-dy],[-dx,-dy],[dx,dy],[-dx,dy],[0,-dy*2],[0,dy*2]];
      if (!national) {
        for (const side of [1,-1]) {
          for (const row of [0,-1,1,-2,2,-3,3]) places.push([side*(dx+23/px),row*(h+6/px)]);
          for (const row of [-1,0,1,-2,2]) places.push([side*(dx+54/px),row*(h+6/px)]);
        }
      }
      for (const [offsetX,offsetY] of places) {
        const x=p.x+offsetX, y=p.y+offsetY;
        const candidate={x:x-w/2,y:y-h/2,w,h};
        if (candidate.x < box.x+gap || candidate.x+w > box.x+box.w-gap || candidate.y < box.y+gap || candidate.y+h > box.y+box.h-gap
          || occupied.some(other => intersects(candidate,other,gap))) continue;
        p.link.removeAttribute('data-pin-hidden'); p.link.setAttribute('tabindex','0');
        p.link.toggleAttribute('data-selected',p.ticker === company);
        const badge=p.link.querySelector('g')!, leader=p.link.querySelector('line')!;
        badge.setAttribute('transform','translate('+x+' '+y+') scale('+(1/px)+')');
        const endX=clamp(p.x,candidate.x,candidate.x+w), endY=clamp(p.y,candidate.y,candidate.y+h);
        leader.setAttribute('x1',String(p.x)); leader.setAttribute('y1',String(p.y));
        leader.setAttribute('x2',String(endX)); leader.setAttribute('y2',String(endY));
        setRect(badge.querySelector('.geo-pill')!,w*px,h*px);
        setRect(badge.querySelector('.geo-hit')!,w*px+3,Math.max(h*px,24));
        occupied.push(candidate); seenStates.add(p.state); seenSymbols.add(p.ticker); drawn++; break;
      }
    }
    const larger = new Set(['TX','CA','WA','OR','AZ','CO','MT','WY','NM','ND','SD','KS','NE','OK','IA','MN','MO','AR','LA','WI','MI','IL','IN','OH','KY','TN','GA','FL','PA','NY','ME','AK','HI','NV','ID','UT','AL','MS','NC','SC','VA','MA','MD']);
    const labels = [...abbreviations].sort((a,b) => Number(b.dataset.stateAbbr===selected)-Number(a.dataset.stateAbbr===selected));
    for (const label of labels) {
      const code=label.dataset.stateAbbr!, x=Number(label.getAttribute('x')), y=Number(label.getAttribute('y'));
      label.removeAttribute('dx'); label.removeAttribute('dy');
      const small=label.hasAttribute('data-small');
      const size = national && compact ? 8 : 10;
      const bounds={x:x-size/px,y:y-size/(2*px),w:2*size/px,h:size/px};
      if (stateView && code===selected && occupied.some(other => intersects(bounds,other,1/px))) {
        const shape=stateLinks.find(link=>link.dataset.geoState===code)?.querySelector('path');
        for (const [dx,dy] of [[-16,0],[0,-16],[-25,-10],[-36,0],[-45,0],[-28,-20],[12,-22]]) {
          const candidate={...bounds,x:bounds.x+dx/px,y:bounds.y+dy/px};
          if (shape?.isPointInFill(new DOMPoint(x+dx/px,y+dy/px)) && !occupied.some(other=>intersects(other,candidate,1/px))) {
            Object.assign(bounds,candidate); label.setAttribute('dx',String(dx/px)); label.setAttribute('dy',String(dy/px)); break;
          }
        }
      }
      const outside = x < box.x || x > box.x+box.w || y < box.y || y > box.y+box.h;
      const skip = omitInset(code) || outside || (national && (small || compact && !larger.has(code))) || (small && zoom < 2.7)
        || occupied.some(other => intersects(bounds,other,1/px));
      label.toggleAttribute('data-suppressed',skip);
      if (!skip) {
        label.style.visibility='visible'; label.style.fontSize=size/px+'px'; occupied.push(bounds);
      }
    }
    for (const dot of dots) {
      dot.setAttribute('r',String((company ? 2.8 : national && compact ? 1.35 : 2)/px));
      dot.toggleAttribute('data-suppressed',!currentCities.has(dot.dataset.city!) || stateView && dot.dataset.city!.split('|')[0]!==selected);
    }
  }

  function redraw() {
    const w=full.w/zoom, h=full.h/zoom;
    center={x:clamp(center.x,w/2,full.w-w/2), y:clamp(center.y,h/2,full.h-h/2)};
    box={x:center.x-w/2,y:center.y-h/2,w,h};
    svg.setAttribute('viewBox',[box.x,box.y,w,h].join(' '));
    svg.toggleAttribute('data-zoomed',zoom>1.001);
    zoomIn.disabled=zoom >= maxZoom-.001; zoomOut.disabled=zoom<=1.001;
    reset.disabled=zoom<=1.001;
    scaleLabel.textContent=Number(zoom.toFixed(1))+'×'; scaleLabel.hidden=false;
    if (svg.getBoundingClientRect().width) drawMarkers(svg.getScreenCTM()?.a || 1);
  }
  function changeZoom(target: number, anchor = center) {
    const next=clamp(target,1,maxZoom), factor=zoom/next;
    center={x:anchor.x+(center.x-anchor.x)*factor,y:anchor.y+(center.y-anchor.y)*factor};
    zoom=next; redraw();
  }
  function update(info: MapSelection) {
    selected=info.state ?? ''; company=info.company ?? ''; sector=info.sector ?? '';
    const matching=rows.filter(([,ticker,industry])=>(!company || ticker===company) && (!sector || industry===sector));
    currentCities=new Set(matching.map(([code,,,city])=>code+'|'+city));
    const counts=new Map<string,Set<string>>();
    for (const [state,ticker] of matching) {
      if (!counts.has(state)) counts.set(state,new Set());
      counts.get(state)!.add(ticker);
    }
    for (const link of stateLinks) {
      const code=link.dataset.geoState!, n=counts.get(code)?.size ?? 0;
      const description=link.dataset.name+' · '+(en ? n+(n===1?' company':' companies') : '기업 '+n+'곳');
      const density=n===0?0:n===1?1:n<5?2:3;
      link.dataset.density=String(density);
      link.toggleAttribute('data-selected',code===selected);
      link.setAttribute('aria-label',description); link.querySelector('title')!.textContent=description;
      if (code===selected) link.setAttribute('aria-current','location'); else link.removeAttribute('aria-current');
      const text=abbreviations.find(a=>a.dataset.stateAbbr===code);
      text?.toggleAttribute('data-pale',density===3);
    }
    root.querySelector<HTMLElement>('[data-geo-keys="filtered"]')!.hidden=!(company || sector);
    const region=stateLinks.find(l=>l.dataset.geoState===selected);
    if (info.national) {
      zoom=1; center={x:full.w/2,y:full.h/2};
    } else if (info.focus && region) {
      const shape=region.querySelector('path')!.getBBox();
      if (shape.width && shape.height) {
        zoom=clamp(Math.min(full.w/(shape.width*1.36),full.h/(shape.height*1.36)),1,maxZoom);
        center={x:shape.x+shape.width/2,y:shape.y+shape.height/2};
      }
    } else if (info.focus && !selected) zoom=1;
    redraw();
  }

  function choose(event: MouseEvent) {
    const target=event.target as Element;
    const link=target.closest<SVGAElement>('[data-geo-state],[data-geo-pin]');
    if (!link || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    if (suppressClick) return;
    const detail = link.dataset.geoPin
      ? {state:link.dataset.pinState!,company:link.dataset.geoPin}
      : {state:link.dataset.geoState!};
    root.dispatchEvent(new CustomEvent('location-map:select',{bubbles:true,detail}));
  }
  let suppressClick=false;
  const pointers=new Map<number,XY>();
  let start: XY | null=null;
  let dragCenter: XY=center;
  let pinchZoom=zoom, pinchDistance=0, pinchAnchor: XY=center, pinchMid: XY=center;
  const mid = (a: XY,b: XY) => ({x:(a.x+b.x)/2,y:(a.y+b.y)/2});
  const dist = (a: XY,b: XY) => Math.hypot(a.x-b.x,a.y-b.y);
  svg.addEventListener('pointerdown',event=>{
    if (event.button!==0) return;
    pointers.set(event.pointerId,{x:event.clientX,y:event.clientY});
    if (pointers.size===1) {
      suppressClick=false; start=pointers.get(event.pointerId)!; dragCenter={...center};
    } else if (pointers.size===2) {
      const [a,b]=[...pointers.values()]; pinchMid=mid(a,b); pinchAnchor=surfacePoint(pinchMid.x,pinchMid.y);
      pinchZoom=zoom; pinchDistance=dist(a,b); dragCenter={...center}; suppressClick=true;
    }
  });
  svg.addEventListener('pointermove', event=>{
    if (!pointers.has(event.pointerId)) return;
    const curr={x:event.clientX,y:event.clientY}; pointers.set(event.pointerId,curr);
    if (pointers.size===2 && pinchDistance) {
      const [a,b]=[...pointers.values()]; const now=mid(a,b);
      zoom=clamp(pinchZoom*dist(a,b)/pinchDistance,1,maxZoom);
      const ratio=pinchZoom/zoom;
      const px=(svg.getScreenCTM()?.a || 1)*zoom/(full.w/box.w);
      center={x:pinchAnchor.x+(dragCenter.x-pinchAnchor.x)*ratio-(now.x-pinchMid.x)/px,
        y:pinchAnchor.y+(dragCenter.y-pinchAnchor.y)*ratio-(now.y-pinchMid.y)/px};
    } else if (pointers.size===1 && start && zoom>1.001) {
      if (!suppressClick && dist(curr,start)<5) return;
      const px=svg.getScreenCTM()?.a || 1;
      center={x:dragCenter.x-(curr.x-start.x)/px,y:dragCenter.y-(curr.y-start.y)/px};
    } else return;
    event.preventDefault(); svg.setPointerCapture(event.pointerId); suppressClick=true;
    svg.setAttribute('data-dragging',''); redraw();
  });
  function endPointer(event: PointerEvent) {
    pointers.delete(event.pointerId); svg.removeAttribute('data-dragging');
    start=pointers.size===1 ? [...pointers.values()][0] : null;
    dragCenter={...center}; pinchDistance=0;
  }
  svg.addEventListener('pointerup',endPointer); svg.addEventListener('pointercancel',endPointer);
  svg.addEventListener('pointerleave',event=>{if (!svg.hasPointerCapture(event.pointerId) && pointers.has(event.pointerId)) endPointer(event);});
  svg.addEventListener('click',choose);
  svg.addEventListener('wheel',event=>{
    if (!(event.ctrlKey || event.metaKey)) return;
    event.preventDefault(); changeZoom(zoom*Math.exp(-clamp(event.deltaY,-160,160)*.008),surfacePoint(event.clientX,event.clientY));
  },{passive:false});
  svg.addEventListener('keydown',event=>{
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    suppressClick=false;
    switch(event.key) {
      case '+': case '=': changeZoom(zoom*1.5); break;
      case '-': case '_': changeZoom(zoom/1.5); break;
      case 'Home': changeZoom(1); break;
      case 'ArrowLeft': case 'ArrowRight': case 'ArrowUp': case 'ArrowDown':
        if (zoom<=1) return;
        center.x+=(event.key==='ArrowRight'?1:event.key==='ArrowLeft'?-1:0)*box.w*.18;
        center.y+=(event.key==='ArrowDown'?1:event.key==='ArrowUp'?-1:0)*box.h*.18; redraw(); break;
      default: return;
    }
    event.preventDefault();
  });
  controls.hidden=false;
  zoomIn.addEventListener('click',()=>changeZoom(zoom*1.5));
  zoomOut.addEventListener('click',()=>changeZoom(zoom/1.5));
  reset.addEventListener('click',()=>changeZoom(1));
  root.addEventListener('location-map:update',event=>update((event as CustomEvent<MapSelection>).detail));
  const owner=root.closest<HTMLElement>('[data-market-us-map]');
  update({state:owner?.dataset.mapState,company:owner?.dataset.mapCompany,sector:owner?.dataset.mapSector,
          focus:owner?.dataset.mapCamera === 'state',national:owner?.dataset.mapCamera === 'national'});
  new ResizeObserver(redraw).observe(svg);
}
