type XY = { x: number; y: number };
export type MapScene = { zoom: number; center: XY; region: string; inset: string; company: string; sector: string };
type MapSelection = { state?: string; company?: string; sector?: string; focus?: boolean; national?: boolean; scene?: MapScene };
const scenes = new WeakMap<HTMLElement, () => MapScene>();
export function readCompanyMapScene(root: HTMLElement) { return scenes.get(root)?.(); }
type Box = XY & { w: number; h: number };
type SiteRow = [state: string, ticker: string, sector: string, city: string];
type Pin = { link: SVGAElement; mark: SVGImageElement | null; state: string; ticker: string; sector: string; city: string; hq: boolean; x: number; y: number };
const full = { w: 1025, h: 1025*542/885 };
const overview = { x: 442.5, y: 250 };
const extent = { west:-420, east:1305, north:-310, south:850 };
const maxZoom = 12;
const detailZoom = 1.7;
const isInset = (code: string) => code==='AK' || code==='HI';
const featured = ['NVDA','TSLA','MSFT','JPM','TSM','KO','WMT','MU','LLY','PLTR','BRK.B','NEM','AAPL','AMZN','XOM','TXN','005930','ORCL','INTC','GE','AMD','LRCX'];
const showcase = ['CA|NVDA','TX|TSLA','WA|MSFT','NY|JPM','AZ|TSM','GA|KO','NE|BRK.B','AR|WMT','ID|MU','IN|LLY','FL|PLTR','CO|NEM'];
const rank = (ticker: string) => {
  const i = featured.indexOf(ticker);
  return i < 0 ? featured.length : i;
};
const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));
const intersects = (a: Box, b: Box, gap: number) => a.x < b.x + b.w + gap && b.x < a.x + a.w + gap
  && a.y < b.y + b.h + gap && b.y < a.y + a.h + gap;

export function mountCompanyMap(root: HTMLElement) {
  if (root.dataset.geoReady) return;
  root.dataset.geoReady = 'true';
  const svg = root.querySelector<SVGSVGElement>('[data-geo-surface]')!;
  const stateLinks = [...svg.querySelectorAll<SVGAElement>('[data-geo-state]')];
  const stateBounds = new Map<SVGAElement,DOMRect>();
  let visibleStates: SVGAElement[] = [];
  let stateTab: SVGAElement | undefined;
  const abbreviations = [...svg.querySelectorAll<SVGTextElement>('[data-state-abbr]')];
  const dots = [...svg.querySelectorAll<SVGCircleElement>('[data-city]')];
  const cityLabels = new Map([...svg.querySelectorAll<SVGTextElement>('[data-city-label]')].map(el=>[el.dataset.cityLabel!,el]));
  const pins: Pin[] = [...svg.querySelectorAll<SVGAElement>('[data-geo-pin]')].map(link => ({
    link, mark:link.querySelector<SVGImageElement>('[data-pin-mark]'), state:link.dataset.pinState!, ticker:link.dataset.geoPin!, sector:link.dataset.sector!, city:link.dataset.cityName!,
    hq:link.dataset.role === 'hq', x:Number(link.dataset.x), y:Number(link.dataset.y),
  }));
  const rows: SiteRow[] = JSON.parse(root.querySelector('[data-geo-rows]')!.textContent!);
  const controls = root.querySelector<HTMLElement>('.geo-controls')!;
  const zoomIn = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="in"]')!;
  const zoomOut = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="out"]')!;
  const reset = controls.querySelector<HTMLButtonElement>('[data-geo-zoom="reset"]')!;
  const scaleLabel = root.querySelector<HTMLElement>('[data-geo-scale]')!;
  const en = root.dataset.lang === 'en';
  const zoomLabel = zoomIn.getAttribute('aria-label')!, zoomTitle = zoomIn.title;
  const geographyLabel = en ? 'Open the street map' : '도로 지도 열기';
  let selected = '', company = '', sector = '', activeCompany = '';
  let pickedSite: Pin | undefined;
  let cameraRegion = '';
  let detailInset = '';
  let zoom = 1, center: XY = {...overview};
  scenes.set(root, () => ({zoom, center:{...center}, region:cameraRegion, inset:detailInset, company, sector}));
  let box: Box = { x:0, y:0, ...full };
  const cityKey = (p: Pin) => p.state + '|' + p.city;
  let currentCities = new Set<string>();
  const widthFor = (p: Pin) => Math.max(32, 12 + p.ticker.length * 7) + (p.mark ? 17 : 0);
  function surfacePoint(clientX: number, clientY: number): XY {
    const matrix = svg.getScreenCTM();
    if (!matrix) return center;
    return new DOMPoint(clientX,clientY).matrixTransform(matrix.inverse());
  }
  function setRect(rect: SVGRectElement, w: number, h: number) {
    rect.setAttribute('x', String(-w/2)); rect.setAttribute('width', String(w));
    rect.setAttribute('y', String(-h/2)); rect.setAttribute('height', String(h));
  }
  function setStateTab(link?: SVGAElement) {
    if (link===stateTab) return;
    stateTab?.setAttribute('tabindex','-1');
    stateTab=link;
    stateTab?.setAttribute('tabindex','0');
  }
  function updateStateTabs(focused?: SVGAElement) {
    visibleStates=stateLinks.filter(link=>{
      if (link.hasAttribute('data-suppressed')) return false;
      const bounds=stateBounds.get(link) ?? link.querySelector('path')!.getBBox();
      if (!bounds.width || !bounds.height) return false;
      stateBounds.set(link,bounds);
      return bounds.x < box.x+box.w && bounds.x+bounds.width > box.x &&
        bounds.y < box.y+box.h && bounds.y+bounds.height > box.y;
    });
    if (!stateTab || !visibleStates.includes(stateTab)) {
      setStateTab(visibleStates.find(link=>link.dataset.geoState===selected) ?? visibleStates[0]);
    }
    if (focused && !visibleStates.includes(focused)) (stateTab ?? svg).focus({preventScroll:true});
  }
  // Pack clickable labels in screen pixels. The point at the end of the leader stays at the Census city reference.
  function drawMarkers(px: number) {
    const occupied: Box[] = [];
    const matrix = svg.getScreenCTM();
    if (!matrix) return;
    const controlBounds = controls.getBoundingClientRect();
    const topLeft = surfacePoint(controlBounds.left, controlBounds.top);
    const bottomRight = surfacePoint(controlBounds.right, controlBounds.bottom);
    occupied.push({x:topLeft.x, y:topLeft.y, w:bottomRight.x-topLeft.x, h:bottomRight.y-topLeft.y});
    const compact = svg.getBoundingClientRect().width < 500;
    const national = zoom < detailZoom;
    const stateView = Boolean(!national && cameraRegion);
    // Alaska and Hawaii are insets on the national map. A mainland close-up must not place them in the Gulf or Mexico.
    const area=svg.dataset.mapArea;
    const omitInset = (code: string) => area!=='overview' && (area==='AK' || area==='HI' ? code!==area : isInset(code));
    const focusedState=stateLinks.find(link=>link===document.activeElement);
    for (const link of stateLinks) link.toggleAttribute('data-suppressed',omitInset(link.dataset.geoState!));
    updateStateTabs(focusedState);
    const limit = company ? 15 : national ? compact ? 6 : 12 : compact ? 12 : 22;
    let drawn = 0;
    const seenStates = new Set<string>();
    const seenSymbols = new Set<string>();
    const sampleRank = (p: Pin) => { const i=showcase.indexOf(p.state+'|'+p.ticker); return i<0?showcase.length:i; };
    const ordered = pins.filter(p => !omitInset(p.state) && (!stateView || p.state===cameraRegion) && currentCities.has(cityKey(p)) && (!company || company === p.ticker) && (!sector || p.sector === sector)
      && p.x >= box.x && p.x <= box.x+box.w && p.y >= box.y && p.y <= box.y+box.h)
      .sort((a,b) => (national&&!company ? sampleRank(a)-sampleRank(b) : 0)
        || rank(a.ticker)-rank(b.ticker)
        || Number(b.hq)-Number(a.hq) || a.ticker.localeCompare(b.ticker));
    for (const label of cityLabels.values()) label.setAttribute('data-suppressed','');
    if (stateView || zoom >= 2.2) {
      // Preserve a few city names before laying out ticker badges, especially when several companies share a city.
      const density=new Map<string,number>();
      for (const p of ordered) density.set(cityKey(p),(density.get(cityKey(p)) ?? 0)+1);
      const names=[...density.keys()].sort((a,b)=>density.get(b)!-density.get(a)!);
      let count=0;
      for (const key of names) {
        if (count>=(compact?3:6)) break;
        const city=ordered.find(p=>cityKey(p)===key)!;
        const label=cityLabels.get(key)!;
        const w=city.city.length*6.25/px, h=12/px;
        for (const [dx,dy] of [[4,13],[4,-5],[-w*px-4,13],[-w*px-4,-5],[4,24],[-w*px-4,24]]) {
          const x=city.x+dx/px,y=city.y+dy/px;
          const bounds={x,y:y-h,w,h};
          if (bounds.x<box.x || bounds.x+w>box.x+box.w || bounds.y<box.y || bounds.y+h>box.y+box.h
            || occupied.some(other=>intersects(bounds,other,1.5/px))) continue;
          label.setAttribute('transform','translate('+x+' '+y+') scale('+(1/px)+')');
          label.removeAttribute('data-suppressed'); occupied.push(bounds); count++; break;
        }
      }
    }
    const visible = new Set<Pin>();
    for (const p of ordered) {
      if (drawn >= limit) break;
      if (national && !company && (seenStates.has(p.state) || seenSymbols.has(p.ticker) || (rank(p.ticker) === featured.length && !sector))) continue;
      if (stateView && !company && compact && zoom<3 && seenSymbols.has(p.ticker)) continue;
      const width = widthFor(p);
      const w = width/px, h = 20/px, gap = 4/px;
      const dx = w/2+6/px, dy = h/2+5/px;
      const places = [[dx,-dy],[-dx,-dy],[dx,dy],[-dx,dy],[0,-dy*2],[0,dy*2]];
      if (!national) {
        for (const side of [1,-1]) {
          for (const row of [0,-1,1,-2,2,-3,3]) places.push([side*(dx+23/px),row*(h+6/px)]);
          for (const row of [-1,0,1,-2,2]) places.push([side*(dx+54/px),row*(h+6/px)]);
        }
      }
      for (const [offsetX,offsetY] of places) {
        const x=p.x+offsetX, y=p.y+offsetY;
        const candidate={x:x-w/2,y:y-h/2,w,h};
        if (candidate.x < box.x+gap || candidate.x+w > box.x+box.w-gap || candidate.y < box.y+gap || candidate.y+h > box.y+box.h-gap
          || occupied.some(other => intersects(candidate,other,gap))) continue;
        visible.add(p);
        const badge=p.link.querySelector('g')!, leader=p.link.querySelector('line')!;
        badge.setAttribute('transform','translate('+x+' '+y+') scale('+(1/px)+')');
        badge.querySelector('text')!.setAttribute('x', p.mark ? '8' : '0');
        if (p.mark) {
          if (!p.mark.hasAttribute('href') && p.mark.dataset.src) p.mark.setAttribute('href',p.mark.dataset.src);
          p.mark.setAttribute('x', String(-width/2 + 4));
          p.mark.setAttribute('y', '-7');
          p.mark.setAttribute('width', '14');
          p.mark.setAttribute('height', '14');
        }
        const endX=clamp(p.x,candidate.x,candidate.x+w), endY=clamp(p.y,candidate.y,candidate.y+h);
        leader.setAttribute('x1',String(p.x)); leader.setAttribute('y1',String(p.y));
        leader.setAttribute('x2',String(endX)); leader.setAttribute('y2',String(endY));
        setRect(badge.querySelector('.geo-pill')!,w*px,h*px);
        setRect(badge.querySelector('.geo-hit')!,w*px+3,Math.max(h*px,24));
        occupied.push(candidate); seenStates.add(p.state); seenSymbols.add(p.ticker); drawn++; break;
      }
    }
    // Temporarily hiding every link during layout would blur the active keyboard pin.
    for (const p of pins) {
      const shown = visible.has(p);
      p.link.toggleAttribute('data-pin-hidden', !shown);
      p.link.setAttribute('tabindex', shown ? '0' : '-1');
      const active = shown && p.ticker === activeCompany && p.state === selected;
      p.link.toggleAttribute('data-selected', active);
      if (active) p.link.setAttribute('aria-current', 'true'); else p.link.removeAttribute('aria-current');
    }
    const larger = new Set(['TX','CA','WA','OR','AZ','CO','MT','WY','NM','ND','SD','KS','NE','OK','IA','MN','MO','AR','LA','WI','MI','IL','IN','OH','KY','TN','GA','FL','PA','NY','ME','AK','HI','NV','ID','UT','AL','MS','NC','SC','VA','MA','MD']);
    const labels = [...abbreviations].sort((a,b) => Number(b.dataset.stateAbbr===selected)-Number(a.dataset.stateAbbr===selected));
    for (const label of labels) {
      const code=label.dataset.stateAbbr!, x=Number(label.getAttribute('x')), y=Number(label.getAttribute('y'));
      label.removeAttribute('dx'); label.removeAttribute('dy');
      const small=label.hasAttribute('data-small');
      const size = national && compact ? 8 : 10;
      const bounds={x:x-size/px,y:y-size/(2*px),w:2*size/px,h:size/px};
      if (stateView && code===selected && occupied.some(other => intersects(bounds,other,1/px))) {
        const shape=stateLinks.find(link=>link.dataset.geoState===code)?.querySelector('path');
        for (const [dx,dy] of [[-16,0],[0,-16],[-25,-10],[-36,0],[-45,0],[-28,-20],[12,-22]]) {
          const candidate={...bounds,x:bounds.x+dx/px,y:bounds.y+dy/px};
          if (shape?.isPointInFill(new DOMPoint(x+dx/px,y+dy/px)) && !occupied.some(other=>intersects(other,candidate,1/px))) {
            Object.assign(bounds,candidate); label.setAttribute('dx',String(dx/px)); label.setAttribute('dy',String(dy/px)); break;
          }
        }
      }
      const outside = x < box.x || x > box.x+box.w || y < box.y || y > box.y+box.h;
      const skip = omitInset(code) || outside || (national && (small || compact && !larger.has(code))) || (small && zoom < 2.7)
        || occupied.some(other => intersects(bounds,other,1/px));
      label.toggleAttribute('data-suppressed',skip);
      if (!skip) {
        label.style.visibility='visible'; label.style.fontSize=size/px+'px'; occupied.push(bounds);
      }
    }
    for (const dot of dots) {
      dot.setAttribute('r',String((company ? 2.8 : national && compact ? 1.35 : 2)/px));
      const code=dot.dataset.city!.split('|')[0];
      dot.toggleAttribute('data-suppressed',omitInset(code) || !currentCities.has(dot.dataset.city!) || stateView && code!==cameraRegion);
    }
  }

  let markerFrame = 0;
  function paintMarkers() {
    markerFrame = 0;
    if (svg.getBoundingClientRect().width) drawMarkers(svg.getScreenCTM()?.a || 1);
  }
  function redraw(continuous = false) {
    const w=full.w/zoom, h=full.h/zoom;
    center={x:clamp(center.x,extent.west+w/2,extent.east-w/2), y:clamp(center.y,extent.north+h/2,extent.south-h/2)};
    box={x:center.x-w/2,y:center.y-h/2,w,h};
    svg.setAttribute('viewBox',[box.x,box.y,w,h].join(' '));
    svg.style.setProperty('--map-zoom',String(zoom));
    svg.toggleAttribute('data-zoomed',zoom>1.001);
    const nearOverview=Math.abs(center.x-overview.x)<full.w*.20 && Math.abs(center.y-overview.y)<full.h*.20;
    svg.dataset.mapArea=zoom<detailZoom && nearOverview ? 'overview' : zoom>=detailZoom && detailInset ? detailInset : 'mainland';
    zoomIn.setAttribute('aria-label',zoom===maxZoom ? geographyLabel : zoomLabel);
    zoomIn.title=zoom===maxZoom ? geographyLabel : zoomTitle;
    zoomOut.disabled=zoom<=1.001;
    reset.disabled=zoom===1 && Math.hypot(center.x-overview.x,center.y-overview.y)<.25;
    scaleLabel.textContent=Number(zoom.toFixed(1))+'×'; scaleLabel.hidden=false;
    if (continuous) {
      if (!markerFrame) markerFrame=requestAnimationFrame(paintMarkers);
    } else {
      cancelAnimationFrame(markerFrame);
      paintMarkers();
    }
  }
  function insetAt(anchor: XY) {
    const point = new DOMPoint(anchor.x,anchor.y);
    let offshore = '';
    for (const link of stateLinks) {
      const code=link.dataset.geoState!;
      if (isInset(code) && svg.dataset.mapArea!=='overview' && svg.dataset.mapArea!==code) continue;
      const path=link.querySelector('path')!;
      if (path.isPointInFill(point)) return isInset(code) ? code : '';
      if (isInset(code)) {
        const bounds=path.getBBox();
        if (point.x>=bounds.x && point.x<=bounds.x+bounds.width && point.y>=bounds.y && point.y<=bounds.y+bounds.height) offshore=code;
      }
    }
    return offshore; // Includes the water between the Hawaiian islands inside their inset.
  }
  // Keep the same point on the land under the same pixel, even as a pinch midpoint moves.
  function moveCamera(target: number, land: XY, underPointer: XY, continuous = false) {
    const next=clamp(target,1,maxZoom), ratio=zoom/next;
    if (zoom<detailZoom && next>=detailZoom) detailInset=insetAt(land);
    center={x:land.x+(center.x-underPointer.x)*ratio,y:land.y+(center.y-underPointer.y)*ratio};
    zoom=next;
    if (next===1) cameraRegion='';
    redraw(continuous);
  }
  function changeZoom(target: number, anchor = center) {
    moveCamera(target,anchor,anchor);
  }
  function resetCamera() {
    zoom=1; center={...overview}; cameraRegion=''; detailInset='';
  }
  function openGeography(point: XY) {
    const inset = zoom<detailZoom ? insetAt(point) : detailInset;
    root.dispatchEvent(new CustomEvent('location-map:geography',{bubbles:true, detail:{x:point.x,y:point.y,inset}}));
  }
  root.addEventListener('location-map:request-geography', () => {
    const selectedSite=(p:Pin) => p.ticker===activeCompany && p.state===selected && !p.link.hasAttribute('data-pin-hidden');
    const pin=pickedSite && selectedSite(pickedSite) ? pickedSite : pins.find(selectedSite);
    openGeography(pin ?? center);
  });
  function zoomInStep() {
    if (zoom===maxZoom) openGeography(center);
    else changeZoom(zoom*1.5);
  }
  function update(info: MapSelection) {
    selected=info.state==='US' ? '' : info.state ?? ''; activeCompany=info.company ?? '';
    // A map inspection changes the article and highlighted pin, not the map's filtered data.
    company=info.scene?.company ?? activeCompany; sector=info.scene?.sector ?? info.sector ?? '';
    const matching=rows.filter(([,ticker,industry])=>(!company || ticker===company) && (!sector || industry===sector));
    currentCities=new Set(matching.map(([code,,,city])=>code+'|'+city));
    const counts=new Map<string,Set<string>>();
    for (const [state,ticker] of matching) {
      if (!counts.has(state)) counts.set(state,new Set());
      counts.get(state)!.add(ticker);
    }
    for (const link of stateLinks) {
      const code=link.dataset.geoState!, n=counts.get(code)?.size ?? 0;
      const description=link.dataset.name+' · '+(en ? n+(n===1?' company':' companies') : '기업 '+n+'곳');
      const density=n===0?0:n===1?1:n<5?2:3;
      link.dataset.density=String(density);
      link.toggleAttribute('data-selected',code===selected);
      link.setAttribute('aria-label',description); link.querySelector('title')!.textContent=description;
      if (code===selected) link.setAttribute('aria-current','location'); else link.removeAttribute('aria-current');
      const text=abbreviations.find(a=>a.dataset.stateAbbr===code);
      text?.toggleAttribute('data-pale',density===3);
    }
    root.querySelector<HTMLElement>('[data-geo-keys="filtered"]')!.hidden=!(company || sector);
    const region=stateLinks.find(l=>l.dataset.geoState===selected);
    if (info.scene) {
      const scene=info.scene;
      zoom=scene.zoom; center={...scene.center}; cameraRegion=scene.region; detailInset=scene.inset;
    } else if (info.national) {
      resetCamera();
    } else if (info.focus && region) {
      // A previously hidden inset (or mainland state) has no SVG bounds until it is shown.
      region.removeAttribute('data-suppressed');
      const shape=region.querySelector('path')!.getBBox();
      if (shape.width && shape.height) {
        cameraRegion=selected;
        detailInset=isInset(selected) ? selected : '';
        zoom=clamp(Math.min(full.w/(shape.width*1.36),full.h/(shape.height*1.36)),1,maxZoom);
        center={x:shape.x+shape.width/2,y:shape.y+shape.height/2};
      }
    } else if (info.focus && !selected) resetCamera();
    redraw();
  }

  function choose(event: MouseEvent) {
    const target=event.target as Element;
    const link=target.closest<SVGAElement>('[data-geo-state],[data-geo-pin]');
    if (!link) return;
    if (suppressClick && event.detail!==0) { event.preventDefault(); return; }
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    pickedSite = link.hasAttribute('data-geo-pin') ? pins.find(p=>p.link===link) : undefined;
    const detail = link.dataset.geoPin
      ? {state:link.dataset.pinState!,company:link.dataset.geoPin}
      : {state:link.dataset.geoState!};
    root.dispatchEvent(new CustomEvent('location-map:select',{bubbles:true,detail}));
  }
  let suppressClick=false;
  let mouseId: number | null=null;
  let press: XY | null=null, grip: XY=center;
  function beginPan(x:number,y:number) {
    press={x,y};
    grip=surfacePoint(x,y);
  }
  function panTo(x:number,y:number) {
    if (!press || (!suppressClick && Math.hypot(x-press.x,y-press.y)<5)) return false;
    suppressClick=true;
    cameraRegion='';
    svg.setAttribute('data-dragging','');
    moveCamera(zoom,grip,surfacePoint(x,y),true);
    return true;
  }
  // SVG links are draggable by default. Keep clicks on their original target, and a drag on the map.
  svg.addEventListener('dragstart',event=>event.preventDefault());
  svg.addEventListener('selectstart',event=>event.preventDefault());
  svg.addEventListener('pointerdown',event=>{
    if (event.pointerType==='touch' || event.button!==0 || mouseId!==null || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    // Cancel the native text-selection gesture before a drag can cross the edge of the SVG.
    event.preventDefault();
    const target=(event.target as Element).closest<SVGElement>('a');
    (target ?? svg).focus({preventScroll:true});
    suppressClick=false; mouseId=event.pointerId;
    beginPan(event.clientX,event.clientY);
    (event.target as Element).setPointerCapture(event.pointerId);
  });
  svg.addEventListener('pointermove',event=>{
    if (event.pointerId===mouseId && panTo(event.clientX,event.clientY)) event.preventDefault();
  });
  function endPointer(event: PointerEvent) {
    if (event.pointerId!==mouseId) return;
    mouseId=null; press=null; svg.removeAttribute('data-dragging');
  }
  svg.addEventListener('pointerup',endPointer); svg.addEventListener('pointercancel',endPointer);
  svg.addEventListener('lostpointercapture',endPointer);

  let pinchStartZoom=1, pinchDistance=0, pinchOpened=false;
  function touchPair(a:Touch,b:Touch) {
    return {x:(a.clientX+b.clientX)/2,y:(a.clientY+b.clientY)/2,distance:Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY)};
  }
  const mapTouches = (event: TouchEvent) => Array.from(event.touches).filter(t=>svg.contains(t.target as Node));
  function beginTouch(event: TouchEvent) {
    const touches=mapTouches(event);
    pinchDistance=0;
    if (touches.length>=2) {
      const pair=touchPair(touches[0],touches[1]);
      grip=surfacePoint(pair.x,pair.y);
      pinchStartZoom=zoom; pinchDistance=pair.distance; pinchOpened=false; suppressClick=true;
      if (event.cancelable) event.preventDefault();
    } else if (touches.length===1) {
      beginPan(touches[0].clientX,touches[0].clientY);
    } else {
      press=null; svg.removeAttribute('data-dragging');
    }
  }
  svg.addEventListener('touchstart',event=>{
    if (event.touches.length===1) suppressClick=false;
    beginTouch(event);
  },{passive:false});
  svg.addEventListener('touchmove',event=>{
    const touches=mapTouches(event);
    if (touches.length>=2 && pinchDistance>0) {
      const pair=touchPair(touches[0],touches[1]);
      if (pinchStartZoom===maxZoom && pair.distance>pinchDistance*1.15) {
        if (!pinchOpened) openGeography(surfacePoint(pair.x,pair.y));
        pinchOpened=true;
        if (event.cancelable) event.preventDefault();
        return;
      }
      cameraRegion='';
      moveCamera(pinchStartZoom*pair.distance/pinchDistance,grip,surfacePoint(pair.x,pair.y),true);
    } else {
      if (touches.length!==1 || !press) return;
      const {clientX:x,clientY:y}=touches[0];
      // At overview, a vertical one-finger swipe should scroll the article normally.
      if (zoom===1 && !suppressClick && Math.abs(y-press.y)>=Math.abs(x-press.x)) return;
      if (!panTo(x,y)) return;
    }
    if (event.cancelable) event.preventDefault();
  },{passive:false});
  svg.addEventListener('touchend',beginTouch,{passive:false});
  svg.addEventListener('touchcancel',beginTouch,{passive:false});
  svg.addEventListener('click',choose);
  let lastWheel = -Infinity;
  svg.addEventListener('wheel',event=>{
    if (!event.deltaY || !event.cancelable) return;
    const unit=event.deltaMode===1 ? 16 : event.deltaMode===2 ? svg.clientHeight : 1;
    const sensitivity=event.ctrlKey || event.metaKey ? .01 : .0027;
    const next=clamp(zoom*Math.exp(-clamp(event.deltaY*unit*sensitivity,-.6,.6)),1,maxZoom);
    if (next===zoom) {
      // At either limit a fresh ordinary scroll can continue down or up the page.
      if (zoom===maxZoom && event.deltaY<0) {
        event.preventDefault();
        if (event.timeStamp-lastWheel>200) openGeography(surfacePoint(event.clientX,event.clientY));
        lastWheel=event.timeStamp;
        return;
      }
      if (event.ctrlKey || event.metaKey || event.timeStamp-lastWheel<180) {
        event.preventDefault(); lastWheel=event.timeStamp;
      }
      return;
    }
    event.preventDefault();
    lastWheel=event.timeStamp; cameraRegion='';
    const anchor=surfacePoint(event.clientX,event.clientY);
    moveCamera(next,anchor,anchor,true);
  },{passive:false});
  svg.addEventListener('focusin',event=>{
    const link=(event.target as Element).closest<SVGAElement>('[data-geo-state]');
    if (link) setStateTab(link);
  });
  svg.addEventListener('keydown',event=>{
    if (event.altKey || event.ctrlKey || event.metaKey) return;
    suppressClick=false;
    const state=(event.target as Element).closest<SVGAElement>('[data-geo-state]');
    if (state && visibleStates.length) {
      const i=visibleStates.indexOf(state), last=visibleStates.length-1;
      const target=event.key==='Home' ? 0 : event.key==='End' ? last
        : event.key==='ArrowLeft' || event.key==='ArrowUp' ? (i+last)%visibleStates.length
        : event.key==='ArrowRight' || event.key==='ArrowDown' ? (i+1)%visibleStates.length : -1;
      if (target>=0) {
        event.preventDefault();
        visibleStates[target].focus({preventScroll:true});
        return;
      }
    }
    switch(event.key) {
      case '+': case '=': if (!event.repeat || zoom<maxZoom) zoomInStep(); break;
      case '-': case '_': changeZoom(zoom/1.5); break;
      case 'Home': resetCamera(); redraw(); break;
      case 'ArrowLeft': case 'ArrowRight': case 'ArrowUp': case 'ArrowDown':
        cameraRegion='';
        center.x+=(event.key==='ArrowRight'?1:event.key==='ArrowLeft'?-1:0)*box.w*.18;
        center.y+=(event.key==='ArrowDown'?1:event.key==='ArrowUp'?-1:0)*box.h*.18; redraw(); break;
      default: return;
    }
    event.preventDefault();
  });
  controls.hidden=false;
  zoomIn.addEventListener('click',zoomInStep);
  zoomOut.addEventListener('click',()=>changeZoom(zoom/1.5));
  reset.addEventListener('click',()=>{ resetCamera(); redraw(); });
  root.addEventListener('location-map:update',event=>update((event as CustomEvent<MapSelection>).detail));
  const owner=root.closest<HTMLElement>('[data-market-us-map]');
  update({state:owner?.dataset.mapState,company:owner?.dataset.mapCompany,sector:owner?.dataset.mapSector,
          focus:owner?.dataset.mapCamera === 'state',national:owner?.dataset.mapCamera === 'national'});
  new ResizeObserver(()=>redraw()).observe(svg);
}
