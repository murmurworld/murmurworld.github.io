const superUserRates = { low: 736.2, high: 601.3 };

export function billForMonth(usage, month, voltage, tariff) {
  if (!Object.hasOwn(superUserRates, voltage) || !Number.isFinite(usage) || usage < 0 ||
    !Number.isInteger(month) || month < 1 || month > 12) {
    throw new RangeError('Invalid household bill inputs');
  }

  const contract = tariff.contracts[voltage];
  const kwh = Math.round(usage);
  const summer = month === 7 || month === 8;
  const winter = month === 12 || month <= 2;
  const [first, second] = tariff.seasons[summer ? 'summer' : 'normal'].bounds;
  const [rate1, rate2, rate3] = contract.rate.map((rate) => Math.round(rate * 10));
  const excess = summer || winter ? Math.max(0, kwh - 1000) : 0;
  const tier = kwh <= first ? 1 : kwh <= second ? 2 : 3;
  const base = contract.base[tier - 1];
  const energy = Math.floor((
    Math.min(kwh, first) * rate1 +
    Math.max(0, Math.min(kwh, second) - first) * rate2 +
    Math.max(0, kwh - second - excess) * rate3 +
    excess * Math.round(superUserRates[voltage] * 10)
  ) / 10);
  const climate = Math.floor(kwh * tariff.surcharge_per_kwh.climate);
  const fuel = Math.floor(kwh * tariff.surcharge_per_kwh.fuel_adj);
  const subtotal = base + energy + climate + fuel;
  const vat = Math.round(subtotal * tariff.vat_rate);
  const fund = Math.floor(subtotal * Math.round(tariff.fund_rate * 1000) / 10000) * 10;
  const total = Math.floor((subtotal + vat + fund) / 10) * 10;
  return { kwh, tier, base, energy, climate, fuel, vat, fund, total };
}
