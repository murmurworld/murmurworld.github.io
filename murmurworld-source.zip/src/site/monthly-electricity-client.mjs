import {
  applianceLimits, createApplianceRows, estimateUsage, householdSelected, isDryerLocked,
  selectApplianceKind, setHouseholdAppliances,
} from './monthly-electricity.mjs';
import { billForMonth } from './electricity-tariff.mjs';

const english = {
  monthValue: 'Monthly value', type: 'type', power: 'Power', energy: 'Energy', perUse: 'Energy per use',
  hours: 'hours per day', minutes: 'minutes per day', weekly: 'uses per week', daily: 'uses per day',
  day: 'Day', week: 'Week', times: '×', h: 'h', min: 'min',
  removed: 'Remove', customKind: 'Entered manually', dryerLocked: 'Included in washer-dryer',
  missingArea: 'Enter your home size.', used: 'Estimated', measured: 'From your bill',
  invalidActual: 'Enter a whole number from 0 to 10,000.',
  invalidName: 'Enter an appliance name.', invalidWatts: 'Enter a wattage from 1 to 20,000 W.',
  invalidHours: 'Enter a time from 0 to 24 hours.',
  added: (name) => `Adding ${name}`,
  excluded: (name) => `Removing ${name}`,
  edited: (name) => `Adjusting ${name}`,
  switched: (name) => `Changing the type for ${name}`,
  household: 'the five Murmurworld appliances', reset: 'Appliances and values restored to their defaults.',
  unchanged: (action) => `${action} leaves the bill unchanged.`,
  difference: (action, amount, increase) => `${action} ${increase ? 'adds' : 'saves'} ${amount} per month.`,
  newTier: (tier) => ` You are now in tier ${tier}.`,
  tierBelow: (tier, next, left) => `Tier ${tier}. ${left} kWh left before ${next} kWh.`,
  tierAt: (tier, next) => `Tier ${tier} ends at ${next} kWh. The next kWh moves up a tier.`,
  tierAbove: (next) => `Tier 3. Use above ${next} kWh is charged at the highest rate.`,
};

const korean = {
  monthValue: '한 달 값', type: '종류', power: '소비전력', energy: '한 달 사용량', perUse: '한 번 사용량',
  hours: '하루 사용 시간', minutes: '하루 사용 시간(분)', weekly: '주간 사용 횟수', daily: '하루 사용 횟수',
  day: '하루', week: '주', times: '회', h: '시간', min: '분',
  removed: '목록에서 빼기', customKind: '직접 넣음', dryerLocked: '세탁건조기에 포함',
  missingArea: '집 크기를 입력해 주세요.', used: '예상', measured: '고지서',
  invalidActual: '0에서 10,000 사이의 정수를 넣어 주세요.',
  invalidName: '넣을 가전의 이름을 적어 주세요.', invalidWatts: '소비전력은 1W에서 20,000W 사이로 넣어 주세요.',
  invalidHours: '하루 사용 시간은 0에서 24 사이로 넣어 주세요.',
  added: (name) => `${name} 추가`,
  excluded: (name) => `${name} 제외`,
  edited: (name) => `${name} 숫자 변경`,
  switched: (name) => `${name} 종류 변경`,
  household: '머머월드 신혼 가전 5종', reset: '가전과 숫자를 처음 값으로 돌려놨어요.',
  unchanged: (action) => `${action} 후에도 요금은 그대로예요.`,
  difference: (action, amount, increase) => `${action}으로 한 달 요금이 ${amount} ${increase ? '늘어요' : '줄어요'}.`,
  newTier: (tier) => ` 누진 ${tier}단계로 바뀌어요.`,
  tierBelow: (tier, next, left) => `누진 ${tier}단계예요. ${next}kWh까지 ${left}kWh 남았어요.`,
  tierAt: (tier, next) => `누진 ${tier}단계의 끝인 ${next}kWh예요. 1kWh 더 쓰면 다음 단계로 올라가요.`,
  tierAbove: (next) => `누진 3단계예요. ${next}kWh를 넘은 만큼은 가장 비싼 값으로 계산해요.`,
};

export const electricityLabels = (lang) => lang === 'en' ? english : korean;
export const electricityMonth = () => Number(new Intl.DateTimeFormat('en-US', { month: 'numeric', timeZone: 'Asia/Seoul' }).format(new Date()));
export const monthlyUsageText = (value, lang) => new Intl.NumberFormat(lang === 'en' ? 'en-US' : 'ko-KR', {
  minimumFractionDigits: 1,
  maximumFractionDigits: 1,
}).format(value);

export function amountParts(values, lang) {
  const format = new Intl.NumberFormat(lang === 'en' ? 'en-US' : 'ko-KR');
  const minimum = Math.min(...values);
  const maximum = Math.max(...values);
  const currency = (value) => lang === 'en' ? `₩${format.format(value)}` : `${format.format(value)}원`;
  if (minimum === maximum) return [currency(minimum)];
  return lang === 'en' ? [currency(minimum), `–${currency(maximum)}`] : [format.format(minimum), `~${currency(maximum)}`];
}

export function applianceFields(mode, lang) {
  const labels = electricityLabels(lang);
  const byTime = mode === 'hours' || mode === 'minutes';
  const power = byTime ? labels.power : mode === 'month' ? labels.energy : labels.perUse;
  const unit = byTime ? 'W' : 'kWh';
  const usage = mode === 'month' ? null : {
    before: mode === 'weekly' ? labels.week : labels.day,
    after: mode === 'hours' ? labels.h : mode === 'minutes' ? labels.min : mode === 'daily' && lang === 'ko' ? '번' : labels.times,
    label: labels[mode],
  };
  return { power, unit, usage };
}

export function monthlyReading(rows, catalog, settings, tariff) {
  const usage = estimateUsage(rows, catalog, settings);
  const billingKwh = usage.billingKwh ?? usage.kwh;
  const low = billForMonth(billingKwh, settings.month, 'low', tariff);
  const high = billForMonth(billingKwh, settings.month, 'high', tariff);
  return { ...usage, low, high };
}

export function tierDetails(reading, month, tariff, labels) {
  const [first, second] = tariff.seasons[month === 7 || month === 8 ? 'summer' : 'normal'].bounds;
  const maximum = second + (second - first) / 2;
  const { kwh, tier } = reading.low;
  const limit = tier === 1 ? first : second;
  const text = tier === 3 ? labels.tierAbove(second)
    : kwh === limit ? labels.tierAt(tier, limit)
      : labels.tierBelow(tier, limit, limit - kwh);
  return { first, second, maximum, kwh, text };
}

function validEntry(input) {
  return input.value !== '' && input.validity.valid && Number.isFinite(input.valueAsNumber);
}

export function mountMonthlyElectricity(root) {
  const get = (name, scope = root) => scope.querySelector(`[data-${name}]`);
  const { catalog, tariff, lang } = JSON.parse(get('monthly-config').textContent);
  const labels = electricityLabels(lang);
  const query = (name) => root.querySelector(`[name="${name}"]`);
  const home = query('home');
  const month = query('month');
  const voltage = query('voltage');
  const area = query('area');
  const actual = query('actualKwh');
  const table = get('appliance-table');
  const household = get('monthly-household');
  const reset = get('monthly-reset');
  const mini = get('monthly-mini');
  const result = get('monthly-result');
  const customGroup = get('appliance-custom-group');
  const addForm = get('monthly-custom-form');
  const error = get('monthly-custom-error');
  const addControls = {
    name: query('customName'),
    preset: query('customPreset'),
    power: query('customPower'),
    usage: query('customUsage'),
    button: get('monthly-add'),
  };
  const definitions = new Map(catalog.rows.map((definition) => [definition.id, definition]));
  const presets = new Map(catalog.customPresets.map((preset) => [preset.id, preset]));
  const views = new Map();

  function registerView(row) {
    const inputs = {
      power: get('row-power', row),
      usage: get('row-usage', row),
    };
    views.set(row.dataset.appliance, {
      row, inputs, name: get('row-name', row), check: get('row-check', row), kind: get('row-kind', row),
      kindNote: get('row-kind-note', row), powerUnit: get('row-power-unit', row), useText: get('row-month-value', row),
      useFields: get('row-use-fields', row), useBefore: get('row-use-before', row), useAfter: get('row-use-after', row),
      total: get('row-total', row), remove: get('row-remove', row),
    });
  }
  table.querySelectorAll('[data-appliance]').forEach(registerView);

  month.value = String(electricityMonth());
  const state = { rows: createApplianceRows(catalog, { home: '24', month: Number(month.value) }), custom: [], acManual: false };
  let customSequence = 0;
  let editStart;

  function settings() {
    return {
      home: home.value,
      area: validEntry(area) ? area.valueAsNumber : undefined,
      month: Number(month.value),
      actualKwh: validEntry(actual) ? actual.valueAsNumber : undefined,
      custom: state.custom,
    };
  }

  function currentReading() {
    const options = settings();
    if (options.home === 'custom' && options.area === undefined && options.actualKwh === undefined) return null;
    return monthlyReading(state.rows, catalog, options, tariff);
  }

  function availableBills(reading) {
    return voltage.value === 'unknown' ? [reading.low, reading.high] : [reading[voltage.value]];
  }

  function difference(action, before, after) {
    if (!before || !after || before.measured || after.measured) return '';
    const oldBills = availableBills(before);
    const changes = availableBills(after).map((bill, index) => bill.total - oldBills[index].total);
    const direction = changes.find((value) => value !== 0);
    if (direction === undefined) return labels.unchanged(action);
    const amount = amountParts(changes.map(Math.abs), lang).join('');
    const tier = before.low.tier !== after.low.tier ? labels.newTier(after.low.tier) : '';
    return `${labels.difference(action, amount, direction > 0)}${tier}`;
  }

  function setValue(input, value, refresh) {
    if (!refresh && document.activeElement === input) return;
    if (!Number.isFinite(value)) return;
    const text = String(value);
    if (input.value !== text) input.value = text;
  }

  function displayRow(id, model, entry, readOnly, maximum, refresh) {
    const view = views.get(id);
    const definition = definitions.get(id);
    const kind = definition?.kinds.find(({ id }) => id === model.kindId);
    const mode = kind?.mode ?? 'hours';
    const name = definition?.label[lang] ?? model.name;
    const locked = id === 'dryer' && isDryerLocked(state.rows);
    const enabled = model.enabled !== false && !locked;
    const valid = entry?.valid !== false;
    const fields = applianceFields(mode, lang);
    view.row.dataset.enabled = String(enabled);
    view.row.dataset.locked = String(locked);
    view.row.style.setProperty('--appliance-bar', enabled && valid && maximum ? String((entry?.kwh ?? 0) / maximum) : '0');
    view.name.textContent = name;
    view.name.title = name;
    view.check.checked = enabled;
    view.check.disabled = readOnly || locked;
    view.total.textContent = locked || !valid ? '—' : `${enabled ? '' : '+'}${monthlyUsageText(entry?.kwh ?? 0, lang)}`;
    if (view.kind) {
      view.kind.value = model.kindId;
      view.kind.title = kind?.label[lang] ?? '';
      view.kind.disabled = readOnly || !enabled;
      view.kind.hidden = locked;
    }
    view.kindNote.hidden = Boolean(view.kind) && !locked;
    view.kindNote.textContent = locked ? labels.dryerLocked : kind?.label[lang] ?? labels.customKind;
    view.kindNote.title = view.kindNote.textContent;
    view.powerUnit.textContent = fields.unit;
    view.useText.hidden = fields.usage !== null;
    view.useFields.hidden = fields.usage === null;
    view.useBefore.textContent = fields.usage?.before ?? '';
    view.useAfter.textContent = fields.usage?.after ?? '';
    for (const field of ['power', 'usage']) {
      const input = view.inputs[field];
      const maximum = applianceLimits[mode][field];
      const label = field === 'power' ? fields.power : fields.usage?.label;
      input.disabled = readOnly || !enabled || maximum === null;
      input.max = maximum ?? '';
      input.setAttribute('aria-label', `${name} ${label ?? ''}`.trim());
      if (field === 'power' && !definition) input.min = '1';
      if (maximum === null) input.value = '';
      else setValue(input, model[field], refresh);
      const invalid = maximum !== null && enabled && !validEntry(input);
      input.setAttribute('aria-invalid', String(invalid));
    }
    if (view.remove) {
      view.remove.disabled = readOnly;
      view.remove.setAttribute('aria-label', lang === 'en' ? `${labels.removed} ${name}` : `${name} ${labels.removed}`);
    }
  }

  function showResult(reading, message) {
    const amount = get('monthly-amount');
    const liveMessage = get('monthly-change');
    get('monthly-result-details').hidden = reading === null;
    if (!reading) {
      amount.textContent = labels.missingArea;
      mini.setAttribute('data-empty', '');
      liveMessage.hidden = true;
      return;
    }
    const parts = amountParts(availableBills(reading).map(({ total }) => total), lang);
    amount.replaceChildren(...parts.map((text) => Object.assign(document.createElement('span'), { textContent: text })));
    const use = `${monthlyUsageText(reading.kwh, lang)} kWh`;
    get('monthly-usage').textContent = `${reading.measured ? labels.measured : labels.used} ${use}`;
    get('monthly-voltage').hidden = voltage.value !== 'unknown';
    get('monthly-low').textContent = amountParts([reading.low.total], lang)[0];
    get('monthly-high').textContent = amountParts([reading.high.total], lang)[0];
    const tier = tierDetails(reading, Number(month.value), tariff, labels);
    const bar = get('monthly-tier-bar');
    bar.style.setProperty('--tier-columns', `${tier.first}fr ${tier.second - tier.first}fr ${tier.maximum - tier.second}fr`);
    bar.style.setProperty('--tier-marker', `${Math.min(tier.kwh, tier.maximum) / tier.maximum * 100}%`);
    const bounds = get('monthly-tier-scale').children;
    [tier.first, tier.second].forEach((bound, index) => {
      bounds[index].textContent = `${bound} kWh`;
      bounds[index].style.left = `${bound / tier.maximum * 100}%`;
    });
    get('monthly-tier-text').textContent = tier.text;
    liveMessage.textContent = message;
    liveMessage.hidden = message === '';
    get('monthly-mini-amount').textContent = parts.join('');
    get('monthly-mini-usage').textContent = use;
    mini.removeAttribute('data-empty');
  }

  function repaint(message = '', refresh = false) {
    const reading = currentReading();
    showResult(reading, message);
    const measured = reading?.measured ?? false;
    const readOnly = measured || reading === null;
    const subdivisions = measured || reading === null ? estimateUsage(state.rows, catalog, { custom: state.custom }) : reading;
    const maximum = Math.max(0, ...Object.values(subdivisions.items).map(({ kwh }) => kwh));
    const rows = { ...state.rows, ...Object.fromEntries(state.custom.map((item) => [item.id, item])) };
    for (const [id, item] of Object.entries(rows)) displayRow(id, item, subdivisions.items[id], readOnly, maximum, refresh);
    root.querySelectorAll('[data-group-total]').forEach((total) => {
      total.textContent = monthlyUsageText(subdivisions.groupKwh[total.dataset.groupTotal] ?? 0, lang);
    });
    customGroup.hidden = state.custom.length === 0;
    table.dataset.inactive = String(readOnly);
    get('monthly-paused').hidden = !measured;
    household.disabled = reset.disabled = readOnly;
    household.setAttribute('aria-pressed', String(householdSelected(state.rows)));
    Object.values(addControls).forEach((control) => { control.disabled = readOnly; });
  }

  function restore() {
    const selected = settings();
    if (selected.home === 'custom' && selected.area === undefined) return;
    state.rows = createApplianceRows(catalog, selected);
    state.acManual = false;
    editStart = undefined;
  }

  function findRow(target) {
    const id = target.closest('[data-appliance]')?.dataset.appliance;
    if (!id) return {};
    return { id, model: definitions.has(id) ? state.rows[id] : state.custom.find((item) => item.id === id) };
  }

  function showCustomError(message, input) {
    Object.values(addControls).forEach((control) => control.removeAttribute('aria-invalid'));
    error.textContent = message;
    error.hidden = !message;
    if (input) {
      input.setAttribute('aria-invalid', 'true');
      input.focus();
    }
  }

  get('monthly-settings').addEventListener('submit', (event) => event.preventDefault());
  home.addEventListener('change', () => {
    get('monthly-area').hidden = home.value !== 'custom';
    restore();
    repaint('', true);
  });
  area.addEventListener('input', () => {
    area.setAttribute('aria-invalid', String(!validEntry(area)));
    restore();
    repaint('', true);
  });
  month.addEventListener('change', () => {
    if (!state.acManual) state.rows.ac.enabled = [7, 8].includes(Number(month.value));
    repaint();
  });
  voltage.addEventListener('change', () => repaint());
  actual.addEventListener('input', () => {
    const invalid = (actual.value !== '' || actual.validity.badInput) && !validEntry(actual);
    actual.setAttribute('aria-invalid', String(invalid));
    const feedback = get('monthly-actual-error');
    feedback.textContent = invalid ? labels.invalidActual : '';
    feedback.hidden = !invalid;
    repaint();
  });
  reset.addEventListener('click', () => {
    restore();
    repaint(labels.reset, true);
  });
  household.addEventListener('click', () => {
    const before = currentReading();
    const enabled = !householdSelected(state.rows);
    state.rows = setHouseholdAppliances(state.rows, catalog, settings(), enabled);
    repaint(difference(enabled ? labels.added(labels.household) : labels.excluded(labels.household), before, currentReading()), true);
  });
  table.addEventListener('change', ({ target }) => {
    if (target === addControls.preset) {
      const selected = presets.get(target.value);
      if (selected) {
        addControls.name.value = selected.label[lang];
        addControls.power.value = selected.power;
        addControls.usage.value = selected.usage;
        showCustomError('');
      }
      return;
    }
    const { id, model } = findRow(target);
    if (!model || !(target.hasAttribute('data-row-kind') || target.hasAttribute('data-row-check'))) return;
    const before = currentReading();
    const definition = definitions.get(id);
    const name = definition?.label[lang] ?? model.name;
    let action;
    if (target.hasAttribute('data-row-kind')) {
      state.rows[id] = selectApplianceKind(model, definition, target.value);
      action = labels.switched(name);
    } else {
      model.enabled = target.checked;
      if (id === 'ac') state.acManual = true;
      action = target.checked ? labels.added(name) : labels.excluded(name);
    }
    repaint(difference(action, before, currentReading()), true);
  });

  table.addEventListener('focusin', ({ target }) => {
    if (target.hasAttribute('data-row-power') || target.hasAttribute('data-row-usage')) editStart = currentReading();
  });
  table.addEventListener('input', ({ target }) => {
    const { id, model } = findRow(target);
    if (!model || !(target.hasAttribute('data-row-power') || target.hasAttribute('data-row-usage'))) return;
    const before = editStart ?? currentReading();
    const valid = validEntry(target);
    model[target.hasAttribute('data-row-power') ? 'power' : 'usage'] = valid ? target.valueAsNumber : NaN;
    const name = definitions.get(id)?.label[lang] ?? model.name;
    repaint(valid ? difference(labels.edited(name), before, currentReading()) : '');
  });
  table.addEventListener('click', ({ target }) => {
    if (!target.closest('[data-row-remove]')) return;
    const { id, model } = findRow(target);
    if (!model) return;
    const before = currentReading();
    state.custom = state.custom.filter((item) => item.id !== id);
    views.get(id).row.remove();
    views.delete(id);
    repaint(difference(labels.excluded(model.name), before, currentReading()));
    addControls.name.focus();
  });
  addForm.addEventListener('submit', (event) => {
    event.preventDefault();
    if (addControls.button.disabled) return;
    const name = addControls.name.value.trim();
    if (!name) return showCustomError(labels.invalidName, addControls.name);
    if (!validEntry(addControls.power)) return showCustomError(labels.invalidWatts, addControls.power);
    if (!validEntry(addControls.usage)) return showCustomError(labels.invalidHours, addControls.usage);
    const before = currentReading();
    const id = `custom-${++customSequence}`;
    state.custom.push({ id, name, power: addControls.power.valueAsNumber, usage: addControls.usage.valueAsNumber, enabled: true });
    const row = get('monthly-custom-template').content.querySelector('tr').cloneNode(true);
    row.dataset.appliance = id;
    get('row-check', row).id = `estimate-${id}`;
    get('row-name', row).htmlFor = `estimate-${id}`;
    customGroup.append(row);
    registerView(row);
    addForm.reset();
    showCustomError('');
    repaint(difference(labels.added(name), before, currentReading()), true);
    addControls.name.focus();
  });

  if ('IntersectionObserver' in window) {
    new IntersectionObserver(([entry]) => {
      mini.toggleAttribute('data-visible', !entry.isIntersecting && entry.boundingClientRect.bottom <= 0);
    }).observe(result);
  }
  repaint('', true);
}
