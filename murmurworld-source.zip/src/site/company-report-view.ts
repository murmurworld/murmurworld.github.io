import glossary from './company-report-english.json';

type Term = {id?:string;name:string;plain:string;like?:string;where?:string};
type Period = {label:string;labelEn?:string;start?:string|null;end?:string|null};
type Row = {key:string;ko:string;en:string;kind:string;level:number;values:(number|null)[]};
type Table = {id:string;titleKo:string;titleEn:string;unitKo:string;unitEn:string;measure:string;periods:Period[];rows:Row[];
  compositionKeys:string[];compositionPeriods:string[];total:(number|null)[]|null;comparableFrom?:string|null;notes:string[];notesEn?:string[];
  source:{label:string;labelEn?:string;url:string;filed?:string|null;periodEnd?:string|null}};
type Report = {ticker:string;easy:{line:string;products:Term[];terms:Term[]};annual:Table[];interim:Table[]};
const colors=['#276d86','#ca633a','#63793e','#826aa5','#bc8041','#377c70','#82605c','#5d7096'];
function element<K extends keyof HTMLElementTagNameMap>(tag:K,content?:string,cls?:string){
  const el=document.createElement(tag);
  if(content) el.textContent=content;
  if(cls) el.className=cls;
  return el;
}
const known=(v:unknown):v is number=>typeof v==='number' && Number.isFinite(v);
const dayMs=86400000;
function comparablePeriods(a:Period,b:Period,years:number,annual:boolean,tableId:string){
  if(years<1 || !a.end || !b.end)return false;
  // Fiscal calendars ending on a weekday can shift by up to one week between years.
  const daysApart=(Date.parse(b.end)-Date.parse(a.end))/dayMs;
  if(!Number.isFinite(daysApart)||Math.abs(daysApart-years*365.2425)>8)return false;
  const span=(p:Period)=>p.start&&p.end?(Date.parse(p.end)-Date.parse(p.start))/dayMs+1:null;
  const before=span(a),after=span(b);
  if(annual){
    // Segment footnotes can give only fiscal year ends. Reject known stub or extended years.
    return [before,after].every(n=>n===null || (n>=357&&n<=373));
  }
  if(before!==null&&after!==null)return Math.abs(before-after)<=8;
  const labeledMonths=(p:Period)=>Number(/(\d+)\s*(?:개월|months?)/i.exec(p.label)?.[1]||0);
  const months=labeledMonths(a);
  if(months>0 && months===labeledMonths(b))return true;
  return tableId.endsWith('-quarter') && [before,after].every(n=>n===null || (n>=80&&n<=101));
}
function reportsPanel(report:Report,en:boolean,detail:HTMLElement){
  const block=document.createDocumentFragment();
  const say=(ko:string,english:string)=>en?english:ko;
  const num=new Intl.NumberFormat(en?'en-US':'ko-KR',{maximumFractionDigits:3});
  const pct=new Intl.NumberFormat(en?'en-US':'ko-KR',{maximumFractionDigits:1,minimumFractionDigits:1});
  const change=(v:number)=> (v>0?'+':'')+pct.format(v)+'%';
  const terms=glossary as Record<string,Term>;
  function cards(entries:Term[]){
    const list=element('div',undefined,'report-products');
    for(const entry of entries){
      const item=element('div',undefined,'product-gloss');
      item.append(element('strong',entry.name),element('p',entry.plain));
      if(entry.like) item.append(element('p',entry.like));
      if(entry.where) item.append(element('p',entry.where));
      list.append(item);
    }
    return list;
  }
  block.append(element('h4',say('무엇을 팔아 돈을 벌까?','How does it earn money?')));
  const line=en?detail.dataset.business:report.easy.line || detail.dataset.business;
  if(line) block.append(element('p',line));
  const easy=en?JSON.parse(detail.dataset.reportSimple||'[]') as Term[]:report.easy.products;
  if(easy.length) block.append(cards(easy));
  const words=en ? report.easy.terms.map(t=>terms[t.id!]).filter(Boolean) : report.easy.terms;
  if(words.length){
    const wordsPanel=element('details');
    wordsPanel.append(element('summary',say('용어 풀이','Glossary')+' ('+words.length+')'),cards(words));
    block.append(wordsPanel);
  }
  function periodName(p:Period) {
    if(en&&p.labelEn) return p.labelEn;
    if(!en || !/[가-힣]/.test(p.label)) return p.label;
    return p.start&&p.end?p.start+' – '+p.end : (p.end||p.label.replace(/종료\s*(\d+)개월/,'($1 months)'));
  }
  function mountTable(t:Table,annual:boolean){
    const region=element('section');
    if(!t.periods.length || !t.rows.length) return region;
    const title=en?t.titleEn:t.titleKo, unit=en?t.unitEn:t.unitKo;
    const last=t.periods.length-1, end=t.periods[last], total=t.total?.[last];
    region.append(element('h4',title),element('p',unit+' · '+periodName(end),'report-meta'));
    const components=(t.compositionKeys || []).map(k=>t.rows.find(r=>r.key===k)).filter((r):r is Row=>Boolean(r));
    const mixTotal=components.reduce((sum,r)=>sum+(r.values[last]||0),0);
    if(components.length>1&&mixTotal>0&&t.compositionPeriods?.includes(end.label)&&components.every(r=>known(r.values[last])&&r.values[last]!>=0)){
      const bar=element('div',undefined,'mix-bar'),legend=element('ul',undefined,'mix-legend');
      bar.setAttribute('aria-hidden','true');
      for(const [i,r] of components.entries()){
        const share=100*r.values[last]!/mixTotal, color=colors[i%colors.length];
        const strip=element('span');strip.style.width=share+'%';strip.style.background=color;bar.append(strip);
        const key=element('li'),dot=element('i');dot.style.background=color;
        key.append(dot,document.createTextNode(' '+(en?r.en:r.ko)+' '+pct.format(share)+'%'));legend.append(key);
      }
      region.append(bar,legend,element('p',say('막대는 중복되지 않는 구성 항목끼리의 비율입니다. 표의 비중은 공시 합계 기준입니다.','The bar shows the mix of non-overlapping components. Table shares use the reported total.'),'report-note'));
    }
    const scroller=element('div',undefined,'business-table'), table=element('table');
    scroller.tabIndex=0;scroller.setAttribute('role','region');scroller.setAttribute('aria-label',title);
    const head=table.createTHead().insertRow();
    const addHeader=(label:string)=>{const th=element('th',label);th.scope='col';head.append(th);};
    addHeader(say('항목','Line item')+' ('+unit+')');
    for(const p of t.periods) addHeader(periodName(p));
    const showShare=known(total)&&total>0&&t.measure!=='financial-results';
    const y=(p:Period)=>Number((p.end||p.label).slice(0,4));
    const startAllowed=t.comparableFrom ? t.periods.findIndex(p=>p.label===t.comparableFrom||p.end===t.comparableFrom) : 0;
    const prior=t.periods.findIndex((p,index)=>{
      if(startAllowed<0 || index<startAllowed || index===last || y(end)-y(p)!==1) return false;
      return comparablePeriods(p,end,1,annual,t.id);
    });
    const sameDuration=prior>=0;
    const baseline=t.periods[startAllowed];
    const years=baseline?y(end)-y(baseline):0;
    const compound=annual && baseline && years>=2 && comparablePeriods(baseline,end,years,true,t.id);
    if(showShare)addHeader(say('합계 대비','Share'));
    if(sameDuration)addHeader(annual?say('전년 대비','Year on year'):say('전년 동기 대비','Year on year'));
    if(compound)addHeader(say('연평균 성장률','CAGR')+' ('+y(baseline)+'–'+y(end)+')');
    const body=table.createTBody();
    function row(name:string,values:(number|null)[],level=0,isTotal=false,allowGrowth=true){
      const tr=body.insertRow(),th=element('th',name);th.scope='row';
      th.style.paddingInlineStart=(.55+.7*Math.max(0,Math.min(level,3)))+'rem';tr.append(th);
      if(isTotal)tr.className='total';
      for(const v of values)tr.append(element('td',known(v)?num.format(v):'—'));
      const v=values[last],old=values[prior],first=values[startAllowed];
      if(showShare)tr.append(element('td',known(v)?pct.format(100*v/total!)+'%':'—'));
      if(sameDuration)tr.append(element('td',allowGrowth&&known(old)&&old>0&&known(v)?change(100*(v/old-1)):'—'));
      if(compound)tr.append(element('td',allowGrowth&&known(first)&&first>0&&known(v)&&v>0?change(100*(Math.pow(v/first,1/years)-1)):'—'));
    }
    for(const r of t.rows)row(en?r.en:r.ko,r.values,r.level,false,!['adjustment','gap','residual'].includes(r.kind));
    if(t.total)row(say('합계','Total'),t.total,0,true);
    scroller.append(table);region.append(scroller);
    for(const note of (en?t.notesEn:t.notes)||[])region.append(element('p',note,'report-note'));
    if(t.source?.url){
      const source=element('a',say('공시 원문','Original filing')+' ↗');source.href=t.source.url;
      const foot=element('p',(en?t.source.labelEn||t.source.label:t.source.label)+(t.source.filed?' · '+say('접수 ','Filed ')+t.source.filed:'')+' · ','report-foot');foot.append(source);region.append(foot);
    }
    return region;
  }
  for(const [annual,tables,label] of [[true,report.annual,say('연간 사업 구성과 실적','Annual business mix and results')],[false,report.interim,say('최근 분기·누계 비교','Interim results and prior-year comparison')]] as const){
    if(!tables.length)continue;
    const choice=element('details',undefined,'report-reading');
    choice.append(element('summary',label));
    for(const t of tables)choice.append(mountTable(t,annual));
    block.append(choice);
  }
  return block;
}

export function mountCompanyReport(panel:HTMLElement){
  const profile=panel.closest<HTMLElement>('[data-location-profile]')!;
  const content=panel.querySelector<HTMLElement>('[data-report-content]')!,status=panel.querySelector<HTMLElement>('[data-report-status]')!,retry=panel.querySelector<HTMLButtonElement>('[data-report-retry]')!;
  const en=document.documentElement.lang==='en', cache=new Map<string,Report>();
  let current='',revision=0;
  async function choose(force=false){
    const ticker=profile.dataset.company||'';
    if(ticker===current&&!force)return;
    current=ticker;const serial=++revision;
    content.replaceChildren();retry.hidden=true;status.textContent='';
    if(!ticker)return;
    const detail=profile.querySelector<HTMLElement>('[data-report-slug]');if(!detail)return;
    try {
      let data=cache.get(ticker);
      if(!data){
        status.textContent=en?'Loading filing data…':'공시 자료를 불러오는 중이에요.';
        const response=await fetch('/data/company-reports/'+encodeURIComponent(detail.dataset.reportSlug!)+'.json');
        if(!response.ok)throw new Error(String(response.status));
        data=await response.json() as Report;
        if(data.ticker!==ticker)throw new Error('Issuer mismatch');
        cache.set(ticker,data);
      }
      if(serial!==revision)return;
      content.replaceChildren(reportsPanel(data,en,detail));status.textContent='';
    }catch{
      if(serial!==revision)return;
      status.textContent=en?'The filing data could not be loaded.':'공시 자료를 불러오지 못했어요.';retry.hidden=false;
    }
  }
  retry.addEventListener('click',()=>choose(true));
  profile.addEventListener('company-report-change',()=>choose());
  choose();
}
