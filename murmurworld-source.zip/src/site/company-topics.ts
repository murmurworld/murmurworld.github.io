import {parseFragment,serializeOuter,type DefaultTreeAdapterTypes} from 'parse5';

type Node=DefaultTreeAdapterTypes.ChildNode;
type Element=DefaultTreeAdapterTypes.Element;
const tag=(node:Node)=>'tagName' in node ? node.tagName : '';
const text=(node:Node):string=>'value' in node ? node.value : 'childNodes' in node ? node.childNodes.map(text).join('') : '';
const inner=(node:Element)=>node.childNodes.map(serializeOuter).join('');
const cells=(node:Element,name:string):Element[]=>node.tagName===name?[node]:
  node.childNodes.flatMap(child=>'tagName' in child?cells(child,name):[]);
const attr=(node:Node,key:string)=>'attrs' in node?node.attrs.find(a=>a.name===key)?.value:undefined;
const table=(node:Node)=>tag(node)==='table'||(attr(node,'class')?.split(' ').includes('tw')??false);
const html=(nodes:Node[])=>nodes.map(serializeOuter).join('\n');
export type Topic = {title:string;id:string;kind:string;segments:Node[][]};

export function readSectorTopics(source:string){
  const groups:{heading:string;nodes:Node[]}[]=[];
  let current:typeof groups[number]|undefined;
  for(const node of parseFragment(source).childNodes){
    if(node.nodeName==='#text'&&!text(node).trim())continue;
    const heading=tag(node)==='section' ? cells(node as Element,'h2')[0] : undefined;
    if(heading){groups.push({heading:text(heading),nodes:[node]});current=undefined;continue;}
    if(!current || tag(node)==='h2'){
      current={heading:tag(node)==='h2'?text(node):'',nodes:[]};
      groups.push(current);
    }
    current.nodes.push(node);
  }
  const map=groups.findIndex(group=>['누가 누구에게 파나','Who supplies whom'].includes(group.heading));
  const table=groups.findIndex(group=>['공시에 이름이 나온 거래','Trading partners named in filings'].includes(group.heading));
  if(map>=0 && table>map+1)groups.splice(map+1,0,groups.splice(table,1)[0]);
  return groups.map(group=>({span:!group.heading || /이 섹터의 회사|companies in this sector/i.test(group.heading),html:html(group.nodes)}));
}

// Group the compiled, trusted Markdown tree before rendering. Footnotes, links and
// table units stay attached to their own subheading even when the grid changes.
export function readCompanyTopics(source:string){
  const topics:Topic[]=[{title:'',id:'',kind:'intro',segments:[[]]}];
  for(const node of parseFragment(source).childNodes){
    if(tag(node)==='h2'){
      const title=text(node).trim();
      const kind=({'무엇을 파나':'products','What it sells':'products','누구에게 파나':'customers','Who buys it':'customers',
        '숫자로 보기':'financials','In numbers':'financials','The numbers':'financials','출처':'sources','Sources':'sources',
        '공시에서 볼 곳':'filings','Where to look in the filing':'filings','Where to look in the filings':'filings'} as Record<string,string>)[title]??'context';
      topics.push({title,id:attr(node,'id')??'',kind,segments:[[]]});continue;
    }
    if(node.nodeName==='#text'&&!text(node).trim())continue;
    const segments=topics[topics.length-1].segments;
    if(tag(node)==='h3'&&segments[segments.length-1].length)segments.push([]);
    segments[segments.length-1].push(node);
  }
  return topics;
}

export type ProductFact={name:string;copy:string};
export type RevenueShare={label:string;values:number[]};
export function arrangeTopic(topic:Topic){
  const copy:string[]=[],data:string[]=[],facts:ProductFact[]=[],metrics:ProductFact[]=[],shares:RevenueShare[]=[];
  for(const nodes of topic.segments){
    let run:Node[]=[];
    let hasTable=false;
    const flush=()=>{
      if(run.length)(hasTable?data:copy).push(html(run));
      run=[];hasTable=false;
    };
    for(const node of nodes){
      if(topic.kind==='context' && run.length && ['p','ul','ol'].includes(tag(node)) &&
          !hasTable && !run.some(n=>tag(n)==='h3'))flush();
      if(table(node)){
        if(hasTable||run.some(n=>tag(n)!=='h3'))flush();
        const rows=cells(node as Element,'tr');
        const header=rows.length?text(rows[0]).trim().replace(/\s+/g,' '):'';
        if(topic.kind==='products'&&/^(제품·서비스|Product or service|Product\/service)/i.test(header)
            &&rows.slice(1).every(row=>cells(row,'td').length===2)){
          for(const row of rows.slice(1)){const [name,value]=cells(row,'td');facts.push({name:inner(name),copy:inner(value)});}
          continue;
        }
        if(topic.kind==='intro'){
          for(const row of rows.slice(1)){
            const pair=cells(row,'td');
            if(pair.length!==2 || !/^(연간 .*\(연결\)|기간 누계 .*\(연결\)|최근 분기 매출·영업이익|Annual consolidated (?:revenue|net revenue)|Fiscal year-to-date consolidated (?:revenue|net revenue)|Latest quarter sales and operating profit)$/i.test(text(pair[0])))continue;
            metrics.push({name:inner(pair[0]),copy:inner(pair[1])});
            const group=row.parentNode as Element;
            group.childNodes.splice(group.childNodes.indexOf(row),1);
          }
        }
        if(topic.kind==='customers'&&/10%.+(전체 매출에서|Share of group revenue)/i.test(header)){
          for(const row of rows.slice(1)){
            const pair=cells(row,'td');
            if(pair.length===4){
              const values=Array.from(text(pair[3]).matchAll(/([\d.]+)%/g),m=>Number(m[1]));
              if(values.length&&values.every(v=>v>=0&&v<=100))shares.push({label:text(pair[0]),values});
            }
          }
        }
        hasTable=true;
      }
      run.push(node);
    }
    flush();
  }
  return {copy,data,facts,metrics,shares};
}
