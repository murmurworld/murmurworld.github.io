export const householdPowerPath = '/blog/home/decor/power/';
const comboMonthlyKwh = Math.round((3.6 * 2 * 30 / 7) * 100) / 100;

export const householdAppliances = [
  {
    id: 601, model: 'RM80H64S2A', ko: '609L 키친핏 냉장고', en: '609 L Kitchen Fit refrigerator',
    kwh: 38.5, low: 38.5, high: 38.5, grade: 'A',
    noteKo: '삼성 사양의 월간소비전력량',
    noteEn: 'Monthly figure listed by Samsung',
    source: 'https://www.samsung.com/sec/support/model/RM80H64S2A/',
  },
  {
    id: 602, model: 'WD90H25AHY', ko: '25/20kg 세탁건조기', en: '25/20 kg washer-dryer',
    kwh: comboMonthlyKwh, low: comboMonthlyKwh, high: comboMonthlyKwh, grade: 'C',
    noteKo: '세탁·건조 한 번에 약 3.6kWh로 잡았다. 주 2회면 30일에 약 30.9kWh, 주 3회면 약 46.3kWh다.',
    noteEn: 'Assumes about 3.6 kWh per wash-and-dry cycle. Over 30 days, that’s about 30.9 kWh at two cycles a week or 46.3 kWh at three.',
    source: 'https://www.samsung.com/sec/support/model/WD90H25AHY/',
  },
  {
    id: 603, model: 'AP90H03163UGD', ko: '공기청정기', en: 'Air purifier',
    kwh: 7.6, low: 5.1, high: 10.1, grade: 'C',
    noteKo: '공단의 0.4W/㎡와 표준사용면적 35.2㎡로 약 14.1W를 계산해, 하루 18시간씩 30일 사용한다고 가정.',
    noteEn: 'Uses about 14.1 W, derived from the agency listing of 0.4 W/m² over 35.2 m², at 18 hours a day for 30 days.',
    source: 'https://eep.energy.or.kr/certification/certi_view_121.aspx?no=288250168',
  },
  {
    id: 604, model: 'VR90F01AAG', ko: '로봇청소기', en: 'Robot vacuum',
    kwh: 12, low: 9, high: 15, grade: 'C',
    noteKo: '청소·충전과 스테이션 세척·건조를 포함해 월 9~15kWh로 잡은 예시의 중간값. 삼성 사양의 스테이션 정격은 1,200W.',
    noteEn: 'Midpoint of a 9–15 kWh planning estimate for cleaning, charging and dock self-cleaning and drying. The dock is rated at 1,200 W.',
    source: 'https://www.samsung.com/sec/support/model/VR90F01AAG/',
  },
  {
    id: 605, model: 'RWP70F15ANW', ko: '정수기', en: 'Water purifier',
    kwh: 9.73, low: 9.73, high: 9.73, grade: 'A',
    noteKo: '한국에너지공단에 등록된 이 모델의 월간소비전력량',
    noteEn: 'Monthly figure registered for this model with the Korea Energy Agency',
    source: 'https://eep.energy.or.kr/certification/certi_view_159.aspx?no=282260116',
  },
];

const calculatorCategory = '신혼 가전 예시';

export function addHouseholdAppliances(database) {
  const modelIds = new Set(householdAppliances.map(({ id }) => id));
  return {
    categories: [...new Set([...database.categories, calculatorCategory])],
    items: [
      ...database.items.filter(({ id }) => !modelIds.has(id)),
      ...householdAppliances.map((item) => ({
        id: item.id,
        분류: calculatorCategory,
        제품: `${item.ko} ${item.model}`,
        대표스펙_W: null,
        패턴: '월간',
        기본사용: item.grade === 'A' ? '표시 기준' : '사용 가정',
        회당_kWh: null,
        월kWh_하한: item.low,
        월kWh_대표: item.kwh,
        월kWh_상한: item.high,
        산정메모: item.noteKo,
        근거등급: item.grade,
        출처: item.source,
      })),
    ],
  };
}
