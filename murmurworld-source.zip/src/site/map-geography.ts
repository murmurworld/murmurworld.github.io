export type Inset = '' | 'AK' | 'HI';
type MapPoint = { x:number; y:number; inset:Inset };
const radians = Math.PI / 180;
// Same ellipsoidal Albers projections and pixel transforms as the Census map.
// Each inset has an independent origin and scale.
const frames = {
  main:[452.5547750790941,565.9242476694119,.0001746597802263317,-96,23,29.5,45.5],
  AK:[129.3065556725797,532.1132493359703,.00004670741737128204,-154,50,55,65],
  HI:[262.0319568588508,611.9720418913587,.00014767727996847714,-157,13,8,18],
};
// SVG units per projected metre differ in each of the two inset maps.
export function projectedFrame(inset:Inset) {
  const [left,top,scale] = frames[inset || 'main'];
  return {left,top,scale};
}
function albers(inset:Inset) {
  const [left,top,scale,meridian,origin,parallel1,parallel2] = frames[inset || 'main'];
  const flattening = 1 / (inset === 'HI' ? 298.257223563 : 298.257222101);
  const e2 = flattening * (2-flattening), e = Math.sqrt(e2);
  const q = (s:number) => (1-e2)*(s/(1-e2*s*s) + Math.atanh(e*s)/e);
  const m2 = (s:number) => (1-s*s)/(1-e2*s*s);
  const s1 = Math.sin(parallel1*radians), s2 = Math.sin(parallel2*radians);
  const n = (m2(s1)-m2(s2))/(q(s2)-q(s1)), c = m2(s1) + n*q(s1);
  const radius = 6378137;
  const rho0 = radius*Math.sqrt(c-n*q(Math.sin(origin*radians)))/n;
  return {left,top,scale,meridian,e2,q,n,c,radius,rho0};
}
const projections = {main:albers(''), AK:albers('AK'), HI:albers('HI')};
export function projectLocation(longitude:number, latitude:number, inset:Inset) {
  const {left,top,scale,meridian,q,n,c,radius,rho0}=projections[inset || 'main'];
  const rho=radius*Math.sqrt(c-n*q(Math.sin(latitude*radians)))/n;
  const theta=(((longitude-meridian+540)%360)-180)*radians*n;
  return {x:left+scale*rho*Math.sin(theta), y:top-scale*(rho0-rho*Math.cos(theta))};
}
export function coordinates({x,y,inset}:MapPoint) {
  const {left,top,scale,meridian,e2,q,n,c,radius,rho0}=projections[inset || 'main'];
  const east = (x-left)/scale, south = rho0-(top-y)/scale;
  const target = (c-(Math.hypot(east,south)*n/radius)**2)/n;
  let s = Math.max(-1,Math.min(1,target/2));
  for (let i=0; i<5; i++) s += (target-q(s))*(1-e2*s*s)**2/(2*(1-e2));
  const latitude = Math.asin(Math.max(-1,Math.min(1,s)))/radians;
  const longitude = ((meridian+Math.atan2(east,south)/(n*radians)+540)%360)-180;
  return {latitude,longitude};
}

// Use the projection at the centre of this view. The Alaska and Hawaii insets
// have different scales from the contiguous states on the overview.
export function mapScale(point:MapPoint, pixelsPerUnit:number) {
  if (!(pixelsPerUnit > 0)) return;
  const samplePixels = 68;
  const half = samplePixels / (2*pixelsPerUnit);
  const left = coordinates({...point,x:point.x-half});
  const right = coordinates({...point,x:point.x+half});
  const a = Math.sin((right.latitude-left.latitude)*radians/2)**2 +
    Math.cos(left.latitude*radians)*Math.cos(right.latitude*radians)*Math.sin((right.longitude-left.longitude)*radians/2)**2;
  const distanceKm = 12742.0176*Math.asin(Math.min(1,Math.sqrt(a)));
  if (!Number.isFinite(distanceKm) || distanceKm<=0) return;
  const unit = 10**Math.floor(Math.log10(distanceKm));
  const kilometres = (distanceKm >= unit*5 ? 5 : distanceKm >= unit*2 ? 2 : 1)*unit;
  return { kilometres, width:samplePixels*kilometres/distanceKm };
}

export function googleAreaUrl(point:{x:number; y:number}, inset:Inset, zoom:number) {
  const {latitude,longitude}=coordinates({...point,inset});
  const url=new URL('https://www.google.com/maps/@');
  const center=latitude.toFixed(5)+','+longitude.toFixed(5);
  url.search=new URLSearchParams({api:'1',map_action:'map',center,zoom:String(zoom)}).toString();
  return url.href;
}
