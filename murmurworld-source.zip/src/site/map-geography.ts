type Inset = '' | 'AK' | 'HI';
type MapPoint = { x:number; y:number; inset:Inset };
const radians = Math.PI / 180;
// Same ellipsoidal Albers projections and pixel transforms as the Census map.
// Each inset has an independent origin and scale.
const frames = {
  main:[452.5547750790941,565.9242476694119,.0001746597802263317,-96,23,29.5,45.5],
  AK:[129.3065556725797,532.1132493359703,.00004670741737128204,-154,50,55,65],
  HI:[262.0319568588508,611.9720418913587,.00014767727996847714,-157,13,8,18],
};
export function coordinates({x,y,inset}:MapPoint) {
  const [left,top,scale,meridian,origin,parallel1,parallel2] = frames[inset || 'main'];
  const flattening = 1 / (inset === 'HI' ? 298.257223563 : 298.257222101);
  const e2 = flattening * (2-flattening), e = Math.sqrt(e2);
  const q = (s:number) => (1-e2)*(s/(1-e2*s*s) + Math.atanh(e*s)/e);
  const m2 = (s:number) => (1-s*s)/(1-e2*s*s);
  const s1 = Math.sin(parallel1*radians), s2 = Math.sin(parallel2*radians);
  const n = (m2(s1)-m2(s2))/(q(s2)-q(s1)), c = m2(s1) + n*q(s1);
  const radius = 6378137;
  const rho0 = radius*Math.sqrt(c-n*q(Math.sin(origin*radians)))/n;
  const east = (x-left)/scale, south = rho0-(top-y)/scale;
  const target = (c-(Math.hypot(east,south)*n/radius)**2)/n;
  let s = Math.max(-1,Math.min(1,target/2));
  for (let i=0; i<5; i++) s += (target-q(s))*(1-e2*s*s)**2/(2*(1-e2));
  const latitude = Math.asin(Math.max(-1,Math.min(1,s)))/radians;
  const longitude = ((meridian+Math.atan2(east,south)/(n*radians)+540)%360)-180;
  return {latitude,longitude};
}

export function mountGeography(root:HTMLElement) {
  const panel = root.querySelector<HTMLElement>('[data-street-panel]')!;
  const open = root.querySelector<HTMLButtonElement>('[data-street-open]')!;
  const close = panel.querySelector<HTMLButtonElement>('[data-street-close]')!;
  const external = panel.querySelector<HTMLAnchorElement>('[data-map-external]')!;
  const frame = panel.querySelector<HTMLIFrameElement>('iframe')!;
  const canvas = root.querySelector<SVGSVGElement>('[data-geo-surface]')!;
  const controls = root.querySelector<HTMLElement>('.geo-controls')!;
  let returnTarget:HTMLElement | SVGSVGElement = open;
  function dismiss(restoreFocus = true) {
    if (panel.hidden) return;
    panel.hidden = true;
    frame.removeAttribute('src');
    controls.inert = false;
    canvas.removeAttribute('inert');
    open.hidden = false;
    if (restoreFocus) returnTarget.focus({preventScroll:true});
  }
  open.hidden = false;
  open.addEventListener('click', () => root.dispatchEvent(new Event('location-map:request-geography')));
  root.addEventListener('location-map:geography', event => {
    if (!panel.hidden) return;
    const {latitude,longitude} = coordinates((event as CustomEvent<MapPoint>).detail);
    if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return;
    const center = latitude.toFixed(5)+','+longitude.toFixed(5);
    const maps = new URL('https://maps.google.com/maps');
    maps.search = new URLSearchParams({ll:center,z:'10',hl:root.dataset.lang || 'ko',output:'embed'}).toString();
    const full = new URL('https://www.google.com/maps/@');
    full.search = new URLSearchParams({api:'1',map_action:'map',center,zoom:'10'}).toString();
    returnTarget = document.activeElement === open ? open : canvas;
    external.href = full.href;
    panel.hidden = false;
    controls.inert = true;
    canvas.setAttribute('inert','');
    open.hidden = true;
    frame.src = maps.href;
    close.focus({preventScroll:true});
  });
  close.addEventListener('click', () => dismiss());
  panel.addEventListener('keydown', event => {
    if (event.key === 'Escape') { event.preventDefault(); dismiss(); }
  });
  root.addEventListener('location-map:update', () => dismiss(false));
}
