import directory from './market-directory.json';

export type Collection = 'companies' | 'funds';
export const marketGroups = directory;
export function companyLabel(english:string,korean:string,lang:'ko'|'en'){
  return lang==='en' || english.toLowerCase()===korean.toLowerCase() ? english : english+' · '+korean;
}
export const marketSections = {
  companies: {
    name: '주식 · 기업과 공시', nameEn: 'Stocks, Companies & Filings',
    line: '회사가 무엇을 팔고 누구와 거래하는지, 섹터별 관계도와 회사별 공시로 읽는다.',
    lineEn: 'Follow the products, customers and suppliers in each industry, then read the company filings.',
  },
  funds: {
    name: 'ETF·채권·원자재', nameEn: 'ETFs, Bonds & Commodities',
    line: '상품이 무엇을 따라가고 실제로 무엇을 담는지, 분류별로 살펴본다.',
    lineEn: 'See what each product tracks, what it holds and how its structure works.',
  },
};

const formerGuides: Record<string,string[]> = {
  semiconductors: ['memory-chips','ai-chips','chip-manufacturing','phone-car-chips'],
  technology: ['cloud-software','cybersecurity-business','digital-advertising'],
  financials: ['payment-networks','asset-management-and-custody'],
  healthcare: ['drug-business'],
  'industry-energy-materials': ['oil-and-lng','mining-products','power-grid','aerospace-business'],
};

export const marketEntries = directory.flatMap(group =>
  [{ path: group.slug, name: group.name, nameEn: group.nameEn },
    ...group.items.map(item => ({ path: group.slug + '/' + item.slug, name: item.name, nameEn: item.nameEn }))]
    .map(row => ({ ...row, collection: group.section as Collection, group: group.slug,
      href: '/blog/' + group.section + '/' + row.path + '/' })));

export function marketPaths(collection: Collection, lang: 'ko'|'en') {
  const articles = marketEntries.filter(entry => entry.collection === collection)
    .map(entry => ({ params: { path: entry.path }, props: { entry, lang, redirectTo: '' } }));
  if (collection === 'funds') return articles;
  const prefix = lang === 'en' ? '/en' : '';
  return [...articles, ...Object.entries(formerGuides).flatMap(([group, guides]) => guides.map(guide => ({
    params: { path: guide }, props: { lang, redirectTo: prefix + '/blog/companies/' + group + '/' },
  })))];
}
