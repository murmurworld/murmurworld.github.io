export { buildApplianceCatalog } from './monthly-appliance-catalog.mjs';

export const monthlyElectricityPath = '/blog/home/decor/energy/';

export const applianceLimits = {
  month: { power: 2000, usage: null },
  hours: { power: 20000, usage: 24 },
  minutes: { power: 20000, usage: 1440 },
  weekly: { power: 50, usage: 20 },
  daily: { power: 30, usage: 20 },
};

const profiles = [
  { id: 'studio', area: 8, fridge: '4', washer: '9', dryer: false, dishwasher: false, tv: null, router: 'router-only', lights: 0.4, other: 5, ac: '26' },
  { id: 'two-room', area: 15, fridge: '1', washer: '8', dryer: false, dishwasher: false, tv: '43', router: 'router-only', lights: 0.6, other: 8, ac: '26' },
  { id: '24', area: 24, fridge: '1', washer: '8', dryer: true, dishwasher: false, tv: '43', router: '45', lights: 1, other: 10, ac: '27' },
  { id: '32', area: 32, fridge: '2', washer: '8', dryer: true, dishwasher: true, tv: '44', router: '45', lights: 1.2, other: 13, ac: '27' },
];

const extraHomeAreas = [10, 12, 18, 20, 25, 28, 30, 33, 34, 38, 42, 45, 50];
const homeNames = {
  studio: { ko: '원룸', en: 'Studio' },
  'two-room': { ko: '투룸', en: 'Two-room' },
};

export const electricityHomeOptions = [
  ...[
    ...profiles.map(({ id, area }) => ({ id, area })),
    ...extraHomeAreas.map((area) => ({ id: String(area), area })),
  ].sort((a, b) => a.area - b.area).map(({ id, area }) => {
    const name = homeNames[id];
    const label = name
      ? { ko: `${name.ko} (약 ${area}평)`, en: `${name.en} (about ${area} pyeong)` }
      : { ko: `${area}평형`, en: `${area} pyeong` };
    return { id, area, label };
  }),
  { id: 'custom', area: null, label: { ko: '집 크기 직접 입력', en: 'Enter your own size' } },
];
const homeOptionById = new Map(electricityHomeOptions.map((option) => [option.id, option]));

const commonAppliances = [
  'fridge', 'riceCooker', 'microwave', 'kettle', 'washer', 'lighting', 'router', 'laptop', 'other',
];

const householdKinds = {
  fridge: '601',
  washer: '602',
  waterPurifier: '605',
  airPurifier: '603',
  robotVacuum: '604',
};
const washerDryerKinds = new Set([householdKinds.washer, 'washer-combo']);

const days = 30;
const roundTenth = (value) => Math.round(value * 10) / 10;
const blank = (value) => value == null || (typeof value === 'string' && value.trim() === '');

function boundedNumber(value, min, max) {
  if (blank(value) || (typeof value !== 'number' && typeof value !== 'string')) return null;
  const number = Number(value);
  return Number.isFinite(number) && number >= min && number <= max ? number : null;
}

function scaleByArea(area, key) {
  const first = profiles[0];
  const last = profiles.at(-1);
  if (area <= first.area) return first[key] * area / first.area;
  if (area >= last.area) return last[key] * area / last.area;
  const upperIndex = profiles.findIndex((profile) => area <= profile.area);
  const lower = profiles[upperIndex - 1];
  const upper = profiles[upperIndex];
  const fraction = (area - lower.area) / (upper.area - lower.area);
  return lower[key] + fraction * (upper[key] - lower[key]);
}

export function selectApplianceKind(row, definition, kindId) {
  const kind = definition.kinds.find(({ id }) => id === String(kindId));
  if (!kind) throw new RangeError(`Unknown kind for ${definition.id}`);
  return { ...row, kindId: kind.id, power: kind.power, usage: kind.usage };
}

export function createApplianceRows(catalog, { home = '24', area, month = 11 } = {}) {
  const selectedMonth = boundedNumber(month, 1, 12);
  if (!Number.isInteger(selectedMonth)) throw new RangeError('Invalid month');

  const option = homeOptionById.get(String(home));
  if (!option) throw new RangeError('Unknown home profile');
  const homeArea = option.id === 'custom' ? boundedNumber(area, 3, 100) : option.area;
  if (homeArea === null) throw new RangeError('Invalid home size');
  const profile = profiles.reduce((closest, candidate) =>
    Math.abs(homeArea - candidate.area) < Math.abs(homeArea - closest.area) ? candidate : closest);

  const kinds = { fridge: profile.fridge, washer: profile.washer, tv: profile.tv, router: profile.router, ac: profile.ac };
  const enabled = new Set(commonAppliances);
  if (profile.dryer) enabled.add('dryer');
  if (profile.dishwasher) enabled.add('dishwasher');
  if (profile.tv) enabled.add('tv');
  if (selectedMonth === 7 || selectedMonth === 8) enabled.add('ac');

  return Object.fromEntries(catalog.rows.map((definition) => {
    const { id } = definition;
    const result = selectApplianceKind({ enabled: enabled.has(id) }, definition, kinds[id] ?? definition.kinds[0].id);
    if (id === 'lighting') result.power = roundTenth(result.power * scaleByArea(homeArea, 'lights'));
    if (id === 'other') result.power = roundTenth(scaleByArea(homeArea, 'other'));
    return [id, result];
  }));
}

export function householdSelected(rows) {
  return Object.entries(householdKinds).every(([id, kindId]) =>
    rows[id]?.enabled && rows[id].kindId === kindId);
}

export function setHouseholdAppliances(rows, catalog, settings, enabled) {
  const result = { ...rows };
  if (enabled) {
    for (const definition of catalog.rows.filter(({ id }) => Object.hasOwn(householdKinds, id))) {
      const { id } = definition;
      result[id] = selectApplianceKind({ enabled: true }, definition, householdKinds[id]);
    }
  } else {
    const defaults = createApplianceRows(catalog, settings);
    for (const id of Object.keys(householdKinds)) result[id] = defaults[id];
  }
  return result;
}

export function isDryerLocked(rows) {
  return rows.washer?.enabled === true && washerDryerKinds.has(rows.washer.kindId);
}

function applianceKwh(mode, row) {
  if (!mode || !row) return null;
  const limits = applianceLimits[mode];
  const power = boundedNumber(row.power, 0, limits.power);
  if (power === null) return null;
  if (mode === 'month') return power;
  const usage = boundedNumber(row.usage, 0, limits.usage);
  if (usage === null) return null;
  switch (mode) {
    case 'hours': return power * usage * days / 1000;
    case 'minutes': return power * usage * days / 60000;
    case 'weekly': return power * usage * days / 7;
    case 'daily': return power * usage * days;
  }
}

export function estimateUsage(rows, catalog, { actualKwh, custom = [] } = {}) {
  const measured = !blank(actualKwh);
  const actual = measured ? boundedNumber(actualKwh, 0, 10000) : null;
  if (measured && !Number.isInteger(actual)) throw new RangeError('Use the whole kWh shown on the bill');

  const groupKwh = Object.fromEntries(catalog.groups.map(({ id }) => [id, 0]));
  groupKwh.custom = 0;
  const items = Object.create(null);
  let total = 0;
  const addRow = (id, group, rawKwh, enabled) => {
    const valid = rawKwh !== null;
    const included = valid && enabled;
    items[id] = { kwh: valid ? roundTenth(rawKwh) : 0, valid, included };
    if (included) {
      total += rawKwh;
      groupKwh[group] += rawKwh;
    }
  };

  const dryerLocked = isDryerLocked(rows);
  for (const definition of catalog.rows) {
    const { id, group, kinds } = definition;
    const row = rows[id];
    const kind = kinds.find(({ id }) => id === row?.kindId);
    addRow(id, group, applianceKwh(kind?.mode, row), row?.enabled === true && !(id === 'dryer' && dryerLocked));
  }
  for (const row of custom) {
    if (!row.id || Object.hasOwn(items, row.id)) throw new RangeError('Custom appliances need unique row identifiers');
    const kwh = typeof row.name === 'string' && row.name.trim() ? applianceKwh('hours', row) : null;
    addRow(row.id, 'custom', kwh, row.enabled !== false);
  }

  for (const group of Object.keys(groupKwh)) groupKwh[group] = roundTenth(groupKwh[group]);
  return {
    kwh: measured ? actual : roundTenth(total),
    billingKwh: measured ? actual : total,
    measured,
    items,
    groupKwh,
  };
}
