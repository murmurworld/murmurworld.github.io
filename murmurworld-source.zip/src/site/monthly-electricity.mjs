import { householdAppliances } from './household-power.mjs';

export const monthlyElectricityPath = '/blog/home/decor/electricity-bill/';

const profiles = {
  studio: { area: 8, fridge: 4, washer: 9, washes: 2, dries: 0, tv: null, router: 10, lights: 0.4, dishwasher: false, other: 5, ac: 'wall' },
  'two-room': { area: 15, fridge: 1, washer: 8, washes: 2, dries: 0, tv: 43, router: 10, lights: 0.6, dishwasher: false, other: 8, ac: 'wall' },
  24: { area: 24, fridge: 1, washer: 8, washes: 3, dries: 3, tv: 43, router: null, lights: 1, dishwasher: false, other: 10, ac: 'stand' },
  32: { area: 32, fridge: 2, washer: 8, washes: 4, dries: 4, tv: 44, router: null, lights: 1.2, dishwasher: true, other: 13, ac: 'stand' },
};
const profilesByArea = Object.values(profiles).sort((a, b) => a.area - b.area);

const usageMultipliers = { light: 0.7, typical: 1, heavy: 1.3 };
const coolingAppliances = { wall: 26, stand: 27, dual: 28 };
const householdFridge = householdAppliances.find(({ id }) => id === 601);
const householdCombo = householdAppliances.find(({ id }) => id === 602);
const additionalHouseholdKwh = householdAppliances.filter(({ id }) => id !== 601 && id !== 602)
  .reduce((total, { kwh }) => total + kwh, 0);
const days = 30;
const consumptionKeys = ['월kWh_대표', '회당_kWh', '대표스펙_W'];
export const monthlyReferenceIds = [1, 2, 4, 8, 9, 10, 13, 17, 18, 21, 26, 27, 28, 33, 43, 44, 45, 49, 50];

export function monthlyReferenceDatabase(database) {
  const picks = new Set(monthlyReferenceIds);
  return {
    items: database.items.filter(({ id }) => picks.has(id)).map((item) => ({
      id: item.id,
      ...Object.fromEntries(consumptionKeys.map((key) => [key, item[key]])),
    })),
  };
}

const present = (value) => value !== '' && value !== null && value !== undefined;
const roundTenth = (value) => Math.round(value * 10) / 10;
const daily = (watts, hours) => watts * hours * days / 1000;
const weekly = (kwh, times) => kwh * times * days / 7;

function numberInRange(value, min, max) {
  const number = Number(value);
  if (!present(value) || !Number.isFinite(number) || number < min || number > max) {
    throw new RangeError('Invalid electricity estimate inputs');
  }
  return number;
}

function scaleByArea(area, key) {
  const first = profilesByArea[0];
  const last = profilesByArea.at(-1);
  if (area <= first.area) return first[key] * area / first.area;
  if (area >= last.area) return last[key] * area / last.area;
  const upperIndex = profilesByArea.findIndex((profile) => area <= profile.area);
  const lower = profilesByArea[upperIndex - 1];
  const upper = profilesByArea[upperIndex];
  const fraction = (area - lower.area) / (upper.area - lower.area);
  return lower[key] + fraction * (upper[key] - lower[key]);
}

export function estimateUsage(input, database) {
  const month = numberInRange(input.month, 1, 12);
  if (!Number.isInteger(month)) throw new RangeError('Invalid month');
  if (present(input.actualKwh)) {
    const kwh = numberInRange(input.actualKwh, 0, 10000);
    if (!Number.isInteger(kwh)) throw new RangeError('Use the whole kWh shown on the bill');
    return { kwh, items: [{ key: 'measured', kwh }], measured: true };
  }

  const selected = input.home ?? '24';
  if (selected !== 'custom' && !Object.hasOwn(profiles, selected)) throw new RangeError('Invalid home profile');
  const area = selected === 'custom' ? numberInRange(input.area, 3, 100) : profiles[selected]?.area;
  const profile = selected === 'custom'
    ? profilesByArea.reduce((closest, candidate) =>
      Math.abs(area - candidate.area) < Math.abs(area - closest.area) ? candidate : closest)
    : profiles[selected];
  const multiplier = usageMultipliers[input.usage ?? 'typical'];
  const cooling = input.cooling ?? 'auto';
  if (!Number.isFinite(multiplier) || (cooling !== 'auto' && cooling !== 'off' && !Object.hasOwn(coolingAppliances, cooling))) {
    throw new RangeError('Invalid electricity estimate options');
  }

  const rows = new Map(database.items.map((item) => [item.id, item]));
  const monthly = (id) => rows.get(id)['월kWh_대표'];
  const watts = (id) => rows.get(id)['대표스펙_W'];
  const cycle = (id) => rows.get(id)['회당_kWh'];
  const primaryCooking = monthly(17) + monthly(18) + monthly(21);
  const optionalCooking = profile.dishwasher ? monthly(13) : 0;
  const media = monthly(49) + (profile.tv ? monthly(profile.tv) : 0) +
    (profile.router === null ? monthly(45) : daily(profile.router, 24));
  const acType = cooling === 'auto'
    ? (month === 7 || month === 8 ? profile.ac : 'off')
    : cooling;
  const coolingKwh = acType === 'off'
    ? 0
    : daily(watts(coolingAppliances[acType]), numberInRange(input.coolingHours ?? 4, 0, 24));
  const other = present(input.otherKwh)
    ? numberInRange(input.otherKwh, 0, 1000)
    : scaleByArea(area, 'other') * multiplier;

  const estimates = [
    ['fridge', input.household ? householdFridge.kwh : monthly(profile.fridge)],
    ['laundry', (input.household ? householdCombo.kwh : weekly(cycle(profile.washer), profile.washes) +
      weekly(cycle(10), profile.dries)) * multiplier],
    ['lighting', daily(watts(50) * scaleByArea(area, 'lights'), 5) * multiplier],
    ['media', media * multiplier],
    ['kitchen', (primaryCooking + optionalCooking) * multiplier],
    ['other', other],
    ['cooling', coolingKwh],
    ['heating', input.heater ? daily(watts(33), 2) : 0],
    ['household', input.household ? additionalHouseholdKwh : 0],
  ];
  const items = estimates.map(([key, kwh]) => ({ key, kwh: roundTenth(kwh) }));
  return { kwh: roundTenth(items.reduce((total, item) => total + item.kwh, 0)), items, measured: false };
}
