import type { MarkdownInstance } from 'astro';
import { homeApplianceDetailEntries } from './home-decor';
import type { SiteLanguage } from './locales';

const manuscripts = import.meta.glob<MarkdownInstance<Record<string, unknown>>>(
  '../articles/home-decor/*.md',
  { eager: true },
);

export function getAppliancePages(lang: SiteLanguage) {
  return homeApplianceDetailEntries.map(({ slug, title, titleEn, description, descriptionEn }) => {
    const { Content } = manuscripts[`../articles/home-decor/${slug}.${lang}.md`];
    return {
      params: { appliance: slug },
      props: {
        Content,
        title: lang === 'en' ? titleEn : title,
        englishTitle: lang === 'ko' ? titleEn : undefined,
        description: lang === 'en' ? descriptionEn : description,
        publishedOn: '2026-11-24',
        lang,
      },
    };
  });
}
