const configuredToken = import.meta.env.PUBLIC_CLOUDFLARE_WEB_ANALYTICS_TOKEN?.trim();

if (configuredToken && !/^[a-f0-9]{32}$/i.test(configuredToken)) {
  throw new Error('PUBLIC_CLOUDFLARE_WEB_ANALYTICS_TOKEN은 Cloudflare Web Analytics의 32자리 사이트 토큰이어야 합니다.');
}

export const analyticsToken = import.meta.env.PROD ? configuredToken : undefined;
export const analyticsDashboard = 'https://dash.cloudflare.com/?to=/:account/web-analytics';
