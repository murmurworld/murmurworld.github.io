import type { CompanySectorId } from './companies';

interface Wording {
  ko: string;
  en: string;
}

export interface SectorExample {
  heading: Wording;
  product: Wording;
  position: Wording;
  filing: { title: string; href: string; read: Wording };
  sources: { title: string; href: string }[];
  video?: { id: string; title: string; channel: string; start?: number; end?: number; label: Wording; context: Wording };
}

export const sectorExamples: Record<CompanySectorId, SectorExample> = {
  semiconductors: {
    heading: { ko: 'AI 가속기에서 HBM은 어떤 일을 할까?', en: 'What does HBM do in an AI accelerator?' },
    product: {
      ko: 'HBM은 여러 DRAM 칩을 위로 쌓아 만든 작업용 메모리입니다. AI 가속기에서 연산 칩 옆에 배치되고 넓은 연결 통로로 데이터를 주고받습니다. SSD에 쓰이는 NAND는 전원을 꺼도 파일을 보관합니다.',
      en: 'HBM stacks multiple DRAM dies into a type of working memory. It sits beside the compute die in the accelerator package and moves data over a wide interface. NAND in SSDs stores files even when the power is off.',
    },
    position: {
      ko: '가속기 업체 등에 HBM을 공급하는 회사로 SK하이닉스, 삼성전자, 마이크론이 있습니다. NVIDIA는 가속기를 설계하고, TSMC는 위탁생산과 패키징을 맡으며, ASML은 웨이퍼에 회로 패턴을 만드는 장비를 공급합니다. 같은 반도체 업종 안에서도 고객과 제품이 다릅니다.',
      en: 'SK hynix, Samsung, and Micron all sell HBM to customers such as accelerator makers. NVIDIA designs accelerators, TSMC manufactures and packages chips for customers, and ASML supplies the equipment that patterns circuits onto wafers. Each role serves a different buyer and need.',
    },
    filing: {
      title: 'Samsung Electronics · Q3 2026 Interim Business Report (Korean PDF)', href: 'https://images.samsung.com/kdp/ir/business-report/2026_3Q_Interim_Business_Report_kr.pdf#page=7',
      read: { ko: '삼성전자 분기보고서의 「사업의 내용 → 주요 제품 및 서비스」에 DRAM과 NAND Flash가 나옵니다. 연결재무제표의 부문별 보고를 보면 DS와 주요 제품인 메모리의 매출이 각각 나옵니다. 이 표에는 HBM만의 매출 항목이 없습니다. 3개월 실적과 1~9월 누적도 다른 표입니다.', en: 'In Samsung’s interim report, Business → Major Products and Services names DRAM and NAND Flash. The operating-segment note in the consolidated statements shows DS revenue and a separate Memory product category. The table does not break out HBM revenue. Three-month and January–September results appear in different tables.' },
    },
    sources: [
      { title: 'SK hynix · HBM packaging', href: 'https://news.skhynix.com/en/tech-note-series-ep2/' },
      { title: 'Micron · HBM', href: 'https://www.micron.com/products/memory/hbm' },
      { title: 'Samsung Electronics · Q3 2026 Consolidated Statements (PDF)', href: 'https://images.samsung.com/kdp/ir/financial-info/2026/2026_con_quarter03_all.pdf' },
      { title: 'Samsung Electronics · Q3 2026 Earnings (English)', href: 'https://news.samsung.com/global/samsung-electronics-announces-third-quarter-2026-results' },
      { title: 'NVIDIA · FY2026 Form 10-K', href: 'https://www.sec.gov/Archives/edgar/data/1045810/000104581026000021/nvda-20260125.htm' },
      { title: 'TSMC · 2025 Annual Report', href: 'https://investor.tsmc.com/static/annualReports/2025/english/index.html' },
      { title: 'ASML · Lithography principles', href: 'https://www.asml.com/en/technology/lithography-principles' },
    ],
    video: {
      id: '4MMfKTRZ_Mg', title: 'HBM, 그게 뭔데?', channel: 'Samsung Semiconductor Newsroom', start: 149, end: 291,
      label: { ko: '한국어 · 2:29~4:51', en: 'Korean · 2:29–4:51' },
      context: { ko: 'DRAM을 여러 장 쌓고 층 사이에 연결 통로를 만드는 모습을 그림으로 보여 줍니다.', en: 'This segment illustrates the DRAM stack and the connections between its layers.' },
    },
  },
  technology: {
    heading: { ko: '웹 서비스는 클라우드에서 무엇을 빌릴까?', en: 'What does a web service rent from a cloud provider?' },
    product: {
      ko: '오라클의 OCI Compute에서는 회사가 웹 서비스나 데이터 처리를 돌릴 서버 자원을 빌립니다. 가상 서버와 물리 서버를 통째로 빌리는 옵션이 있습니다.',
      en: 'Organizations rent computing capacity from Oracle OCI Compute to run web services or process data. Options include virtual machines and dedicated bare-metal servers.',
    },
    position: {
      ko: '같은 용도의 후보로 AWS EC2가 있습니다. 서버를 옮길 때는 컴퓨팅 기능과 함께 연결해 쓰던 데이터베이스나 네트워크를 어떻게 이전할지도 봐야 합니다. 오라클이 파는 기업용 업무 앱은 별개의 제품군입니다.',
      en: 'AWS EC2 serves a similar need. When switching, buyers also check how connected databases and networking would carry over. Oracle’s enterprise applications are a separate product line.',
    },
    filing: {
      title: 'Oracle FY2026 Form 10-K', href: 'https://www.sec.gov/Archives/edgar/data/1341439/000119312526277521/orcl-20260531.htm',
      read: { ko: 'Item 1의 Cloud and Software Business에서 인프라와 업무용 앱을 구분한 뒤, 사업부 매출 주석이 어느 범위까지 숫자를 묶는지 확인합니다.', en: 'Start with Cloud and Software Business in Item 1 to distinguish infrastructure from applications, then check the reporting notes for how revenue is grouped.' },
    },
    sources: [{ title: 'Oracle · OCI Compute', href: 'https://www.oracle.com/cloud/compute/' }, { title: 'AWS · EC2 documentation', href: 'https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/concepts.html' }],
    video: {
      id: 't48aVpw6kkI', title: 'What is Amazon EC2?', channel: 'Amazon Web Services',
      label: { ko: '영어', en: 'English' },
      context: { ko: '서버를 사서 설치하는 대신 클라우드 서비스에서 무엇을 빌리는지 설명합니다.', en: 'See what you rent from a cloud provider when you need to run a web app.' },
    },
  },
  financials: {
    heading: { ko: '블랙록에 맡긴 돈과 블랙록이 번 돈', en: 'Money BlackRock manages versus what it earns' },
    product: {
      ko: '블랙록은 기관과 개인의 자금을 운용하고 운용·관리 보수를 받습니다. iShares ETF를 운영하고, 기관이 위험을 관리하는 소프트웨어 Aladdin도 제공합니다.',
      en: 'BlackRock manages assets for institutions and individuals and collects management and administration fees. It operates iShares ETFs and offers Aladdin risk-management technology to institutions.',
    },
    position: {
      ko: 'iShares IVV와 뱅가드 VOO는 같은 S&P 500 지수를 따르는 펀드입니다. 두 상품의 운용 보수와 추적 성과를 비교할 수 있습니다. 블랙록 전체를 볼 때는 이런 펀드 외에도 기관 운용 계약과 기술 서비스가 있습니다.',
      en: 'iShares IVV and Vanguard VOO both track the S&P 500. You can compare fees and tracking for these two products. BlackRock also has institutional mandates and technology services beyond those funds.',
    },
    filing: {
      title: 'BlackRock 2025 Form 10-K', href: 'https://www.sec.gov/Archives/edgar/data/2012383/000119312526071966/blk-20251231.htm',
      read: { ko: 'AUM 표에는 고객이 맡긴 자산이, Revenue 표에는 운용사에 들어온 보수와 수입이 나옵니다. 같은 기간의 두 표를 나란히 읽어 보세요.', en: 'The AUM table measures client assets. The revenue table shows fees and other income BlackRock earned. Read the two tables for the same period.' },
    },
    sources: [
      { title: 'iShares · IVV', href: 'https://www.ishares.com/us/products/239726/ishares-core-sp-500-etf' },
      { title: 'Vanguard VOO · Summary Prospectus', href: 'https://www.sec.gov/Archives/edgar/data/36405/000003640526000183/f44783d1.htm' },
    ],
  },
  'consumer-telecom': {
    heading: { ko: '코카콜라 회사는 음료를 어떻게 팔까?', en: 'How does The Coca-Cola Company sell its drinks?' },
    product: {
      ko: '코카콜라 컴퍼니는 병입 업체에 음료 농축액과 시럽을 공급하고, 일부 사업에서는 완제품도 판매합니다. 병입 업체는 음료를 만들어 포장하고 매장까지 유통하는 역할을 맡습니다.',
      en: 'The Coca-Cola Company supplies concentrates and syrups to bottlers and also sells finished drinks through parts of its business. Bottlers make, pack, and distribute drinks to stores.',
    },
    position: {
      ko: '마트 음료 코너에서 코카콜라와 펩시콜라는 대체할 수 있는 상품입니다. 이름이 비슷한 코카콜라 콘솔리데이티드는 음료 생산과 유통을 맡는 별도 상장 회사입니다. 어느 회사의 공시를 보고 있는지에 따라 매출의 출처가 달라집니다.',
      en: 'Coca-Cola and Pepsi-Cola are alternatives on the drinks shelf. Coca-Cola Consolidated, despite the similar name, is a separate listed bottling and distribution company. Its filings tell a different revenue story.',
    },
    filing: {
      title: 'The Coca-Cola Company 2025 Form 10-K', href: 'https://www.sec.gov/Archives/edgar/data/21344/000162828026010047/ko-20251231.htm',
      read: { ko: 'Item 1에서 Concentrate Operations와 Finished Product Operations를 찾아 각각 누가 고객이고 무엇을 사 가는지 봅니다.', en: 'Find Concentrate Operations and Finished Product Operations in Item 1 and ask who buys what in each case.' },
    },
    sources: [
      { title: 'Coca-Cola Consolidated · 2025 Annual Report', href: 'https://www.sec.gov/Archives/edgar/data/317540/000162828026020501/coke2025annualreport.pdf' },
      { title: '한국 코카콜라 · 한국의 생산과 유통', href: 'https://www.coca-cola.com/kr/ko/about-us/coca-cola-korea' },
    ],
  },
  healthcare: {
    heading: { ko: '같은 성분인데 왜 약 이름이 두 개일까?', en: 'Why can the same ingredient have two brand names?' },
    product: {
      ko: '미국에서 일라이 릴리의 마운자로와 젭바운드는 둘 다 티르제파타이드를 씁니다. 마운자로는 제2형 당뇨병 치료, 젭바운드는 일정한 요건을 충족하는 환자의 장기 체중 관리 등에 허가받은 브랜드입니다.',
      en: 'In the United States, Lilly sells tirzepatide as Mounjaro and Zepbound. Mounjaro is approved for type 2 diabetes. Zepbound is approved for uses including long-term weight management in eligible patients.',
    },
    position: {
      ko: '미국에서 허가된 용도를 기준으로 제2형 당뇨병 사업은 마운자로와 오젬픽, 체중 관리는 젭바운드와 위고비를 비교할 수 있습니다. 같은 성분이 쓰여도 브랜드와 허가 범위가 다르면 읽어야 할 매출 항목도 달라집니다.',
      en: 'For the U.S. market, compare Mounjaro with Ozempic for type 2 diabetes and Zepbound with Wegovy for weight management. Brand and approved indication matter when mapping a drug to reported sales.',
    },
    filing: {
      title: 'Eli Lilly Q3 2026 Form 10-Q', href: 'https://www.sec.gov/Archives/edgar/data/59478/000005947826000108/lly-20260930.htm',
      read: { ko: '제품별 매출표의 브랜드명을 확인하고, 어떤 용도로 허가됐는지는 미국 FDA 자료에서 따로 확인합니다.', en: 'Look up the brand names in the product revenue table and check the approved indications separately in the FDA material.' },
    },
    sources: [
      { title: 'FDA · Zepbound approval', href: 'https://www.fda.gov/news-events/press-announcements/fda-approves-new-medication-chronic-weight-management' },
      { title: 'FDA · Semaglutide brands and indications (PDF)', href: 'https://www.accessdata.fda.gov/drugsatfda_docs/nda/2026/218316Orig1s000StatR.pdf' },
    ],
    video: {
      id: 'Vv6DlAS4duM', title: 'How does the FDA approve new drugs?', channel: 'U.S. Food and Drug Administration',
      label: { ko: '영어', en: 'English' },
      context: { ko: '제약사가 어떤 자료를 제출하고 FDA는 무엇을 판단하는지 알아볼 수 있습니다.', en: 'Find out what drugmakers submit and what the FDA evaluates before approval.' },
    },
  },
  'industry-energy-materials': {
    heading: { ko: '가스터빈을 판 뒤, 발전소와 어떤 일을 할까?', en: 'What does a turbine maker do after the sale?' },
    product: {
      ko: 'GE 버노바의 7HA는 발전소에서 가스를 태워 발전기를 돌리는 대형 터빈입니다. 발전 사업자는 장비를 설치한 뒤에도 점검, 부품 교체, 정비 서비스를 구매합니다.',
      en: 'GE Vernova’s 7HA is a large turbine that burns gas to turn a generator at a power plant. Operators can buy inspections, replacement parts, and maintenance long after installation.',
    },
    position: {
      ko: '지멘스 에너지의 60Hz급 SGT6-9000HL도 대형 가스 발전 프로젝트의 후보가 될 수 있습니다. 실제 비교에서는 발전소의 요구 출력과 연료 조건, 장비를 멈춰야 하는 시간, 장기 정비 계약을 함께 봅니다.',
      en: 'Siemens Energy’s 60 Hz SGT6-9000HL can serve large gas-power projects too. Buyers compare the plant’s output and fuel requirements, downtime, and long-term service contracts.',
    },
    filing: {
      title: 'GE Vernova 2025 Annual Report', href: 'https://www.gevernova.com/sites/default/files/gevernova_2025_annual_report.pdf',
      read: { ko: 'Power 사업부의 Equipment와 Services를 비교하면 발전 장비 판매와 설치 후 일어나는 매출을 구분해 볼 수 있습니다.', en: 'Compare Equipment and Services in the Power segment to distinguish equipment sales from the business that follows installation.' },
    },
    sources: [
      { title: 'GE Vernova · 7HA', href: 'https://www.gevernova.com/gas-power/products/gas-turbines/7ha' },
      { title: 'Siemens Energy · HL-class turbines', href: 'https://www.siemens-energy.com/global/en/home/products-services/product-offerings/gas-turbines/hl-class.html' },
    ],
    video: {
      id: '2Jm5RVHLlcQ', title: 'How a gas turbine works', channel: 'GE Vernova',
      label: { ko: '영어', en: 'English' },
      context: { ko: '공기 압축, 연소, 터빈 회전이 어떻게 발전기까지 이어지는지 볼 수 있습니다.', en: 'Follow air compression, combustion, and turbine rotation through to the generator.' },
    },
  },
  'funds-bonds-commodities': {
    heading: { ko: '같은 반도체 ETF인데 담는 종목은 왜 다를까?', en: 'Why do two semiconductor ETFs hold different stocks?' },
    product: {
      ko: 'SOXX와 SMH는 반도체 관련 기업을 묶어 담는 ETF입니다. SOXX는 NYSE Semiconductor Index를, SMH는 MVIS US Listed Semiconductor 25 Index를 추종합니다. 포함할 회사와 비중은 지수 규칙에 따라 정해집니다.',
      en: 'SOXX and SMH are ETFs that hold baskets of semiconductor companies. SOXX tracks the NYSE Semiconductor Index and SMH tracks the MVIS US Listed Semiconductor 25 Index. Each index has its own selection and weighting rules.',
    },
    position: {
      ko: '이름이 비슷한 두 ETF는 같은 날짜의 구성 종목, 상위 종목 비중, 운용 비용을 비교해 볼 수 있습니다. 장기 미국 국채를 담는 TLT는 같은 ETF 형식을 써도 기초 자산이 달라 비교 질문부터 달라집니다.',
      en: 'Compare the two funds’ holdings, largest weights, and operating expenses as of the same date. TLT also uses an ETF wrapper, but its long-dated U.S. Treasuries call for different questions.',
    },
    filing: {
      title: 'SOXX Summary Prospectus · 2026-07-31', href: 'https://www.sec.gov/Archives/edgar/data/1100663/000119312526327967/d132214d497k.htm',
      read: { ko: 'Principal Investment Strategies에서 지수와 편입 조건, Fund Fees and Expenses에서 보수를 확인합니다. 실제 보유 종목의 기준일은 운용사 페이지에 따로 표시됩니다.', en: 'Read Principal Investment Strategies for the benchmark and Fund Fees and Expenses for costs. The issuer’s actual holdings list has its own as-of date.' },
    },
    sources: [
      { title: 'VanEck · SMH', href: 'https://www.vaneck.com/us/en/investments/semiconductor-etf-smh/holdings/' },
      { title: 'iShares · TLT', href: 'https://www.ishares.com/us/products/239454/ishares-20-year-treasury-bond-etf' },
      { title: 'SEC Investor.gov · ETF bulletin', href: 'https://www.investor.gov/introduction-investing/general-resources/news-alerts/alerts-bulletins/investor-bulletins-24' },
    ],
    video: {
      id: 'j6DdMgv6Z_s', title: 'What Is an ETF?', channel: 'iShares by BlackRock', start: 25,
      label: { ko: '영어 · 0:25부터', en: 'English · starts at 0:25' },
      context: { ko: 'ETF 한 주를 사면 그 안에 어떤 자산을 함께 담게 되는지 간단한 비유로 설명합니다.', en: 'An illustration of the basket of assets an ETF share gives you exposure to.' },
    },
  },
};
