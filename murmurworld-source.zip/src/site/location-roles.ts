import type { SiteLanguage } from './locales';

type Location = { role:string; kind?:string };
const kinds:Record<string,[string,string]>={
  hq:['본사','HQ'], regional:['지역 본부','Regional HQ'], subsidiary:['미국 자회사 본사','U.S. subsidiary HQ'],
  second:['제2본사','Second HQ'], ops:['운영 본부','Operations HQ'], bank:['은행 지점','Bank branch'],
  fab:['웨이퍼 생산','Wafer fab'], packaging:['반도체 패키징','Chip packaging'], equipment:['부품 개발·생산','Components'],
  plant:['생산 공장','Manufacturing'], refinery:['정유·화학','Refining'], mine:['광산','Mining'],
  production:['유전','Oil production'], pilot:['실증 시설','Pilot site'], research:['연구개발','R&D'],
  support:['고객 기술지원','Customer support'], maintenance:['엔진 정비','Engine maintenance'],
  store:['매장','Retail'], cloud:['클라우드 거점','Cloud operations'], construction:['착공·건설','Under construction'],
  project:['개발 사업','Development project'], peering:['통신망 접속점','Network access'],
};
const operatingSites=new Set(['fab','packaging','plant','mine','cloud','production','refinery','equipment']);

export function siteKind(site:Location,lang:SiteLanguage) {
  return (kinds[site.kind ?? site.role] ?? ['거점','Site'])[lang==='en'?1:0];
}

export function primarySite<T extends Location>(sites:T[]) {
  return sites.find(site=>site.role==='hq') ?? sites.find(site=>site.kind==='regional' || site.kind==='subsidiary') ??
    sites.find(site=>operatingSites.has(site.kind ?? '')) ??
    sites.find(site=>site.kind!=='construction' && site.kind!=='project') ?? sites[0];
}
