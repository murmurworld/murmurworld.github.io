import type { MarkdownInstance } from 'astro';
import { companiesTopic, companySectors, type CompanySectorId } from './companies';
import type { SiteLanguage } from './locales';

interface GuideFrontmatter {
  title: string;
  description: string;
  sector: CompanySectorId;
  publishedOn: string;
  order?: number;
  video?: { id: string; title: string; channel: string; label: string; context: string; start?: number; end?: number };
}

const guides = import.meta.glob<MarkdownInstance<GuideFrontmatter>>('../articles/companies/*.md', { eager: true });
const directory = '../articles/companies/';

export const companyGuideEntries = Object.entries(guides)
  .filter(([path]) => path.endsWith('.ko.md'))
  .map(([path, korean]) => {
    const slug = path.slice(directory.length, -'.ko.md'.length);
    const english = guides[`${directory}${slug}.en.md`];
    const { sector, publishedOn } = korean.frontmatter;
    if (!english || !companySectors.some(({ id }) => id === sector) || english.frontmatter.sector !== sector) {
      throw new Error(`Verify the sector and both languages for the company guide ${slug}`);
    }
    return {
      slug, sector, publishedOn, href: `${companiesTopic.href}${slug}/`,
      title: korean.frontmatter.title, titleEn: english.frontmatter.title,
      ko: korean, en: english,
    };
  })
  .sort((a, b) => (a.ko.frontmatter.order ?? 99) - (b.ko.frontmatter.order ?? 99));

export function companyGuidePaths(lang: SiteLanguage) {
  return companyGuideEntries.map(({ slug, titleEn, publishedOn, [lang]: guide }) => ({
    params: { guide: slug },
    props: { guide, titleEn, publishedOn, lang },
  }));
}
