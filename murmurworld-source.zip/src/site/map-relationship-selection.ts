type Direction = 'in' | 'out' | 'joint';
export type MapRelation = {
  id: string;
  peer: string;
  label: string;
  kind: string;
  direction: Direction;
  caseId: string;
};

// Read the already-rendered, sourced network. The map and its text alternative share
// the same ordering, including relationships whose counterparty has no mapped site.
export function setupMapRelationships(atlas: HTMLElement, refresh: () => void) {
  const panel = atlas.querySelector<HTMLElement>('[data-map-relations]')!;
  const picker = panel.querySelector<HTMLSelectElement>('[data-map-relation-select]')!;
  const picks = panel.querySelector<HTMLElement>('[data-map-relation-picks]')!;
  const detail = panel.querySelector<HTMLElement>('[data-map-relation-detail]')!;
  const pair = panel.querySelector<HTMLElement>('[data-map-relation-pair]')!;
  const product = panel.querySelector<HTMLElement>('[data-map-relation-label]')!;
  const jump = panel.querySelector<HTMLAnchorElement>('[data-map-relation-jump]')!;
  const source = panel.querySelector<HTMLAnchorElement>('[data-map-relation-source]')!;
  const english = document.documentElement.lang === 'en';
  const directions = english
    ? { out: 'Sales & use', in: 'Purchases & use', joint: 'Partnership' }
    : { out: '판매·이용처', in: '구매·도입', joint: '협업' };
  const status: Record<string,string> = english
    ? { showcase:'Exhibited hardware', design:'Product design', production:'Production announcement', agreement:'Agreement' }
    : { showcase:'실물 공개', design:'제품 설계', production:'양산 발표', agreement:'계약·합의' };
  let company = '';
  let companyName = '';
  let selected = '';
  let edges: MapRelation[] = [];
  let rows: HTMLElement[] = [];
  let peerNames: string[] = [];

  function publish() {
    atlas.dispatchEvent(new CustomEvent('location-map:relations', {
      bubbles:true, detail:{company,edges,selected},
    }));
  }

  function choose(id: string) {
    const edge = edges.find(item => item.id === id);
    if (id && !edge) return;
    const url = new URL(location.href);
    if (edge) {
      url.searchParams.set('case',edge.caseId);
      url.searchParams.set('relation',edge.id);
    } else {
      url.searchParams.delete('case');
      url.searchParams.delete('relation');
    }
    url.hash = 'us-map';
    if (url.href !== location.href) {
      const previous = history.state ?? {};
      const next = {...previous};
      if (previous.marketMap?.href === location.href) {
        next.marketMap = {...previous.marketMap, href:url.href};
      }
      history.pushState(next,'',url);
    }
    refresh();
  }

  picker.addEventListener('change', () => choose(picker.value));
  document.addEventListener('location-map:relation-select', event => {
    const value = (event as CustomEvent<{company:string;id:string}>).detail;
    if (value?.company === company && typeof value.id === 'string') choose(value.id);
  });
  document.addEventListener('location-map:relations-request', publish);
  picks.addEventListener('click',event => {
    const button=(event.target as Element).closest<HTMLButtonElement>('[data-relation-pick]');
    if(button)choose(button.dataset.relationPick!);
  });

  return function sync(nextCompany: string, profile: HTMLElement | undefined, id: string) {
    if (nextCompany !== company) {
      for (const row of rows) {
        row.removeAttribute('data-selected');
        row.removeAttribute('aria-current');
      }
      company = nextCompany;
      companyName = profile?.querySelector('[data-network-title]')?.textContent?.trim() ?? company;
      rows = profile ? [...profile.querySelectorAll<HTMLElement>('[data-edge-id]')] : [];
      peerNames = [];
      const options: HTMLOptionElement[] = [new Option(english?'All connections':'전체 연결선','')];
      edges = rows.map((row,i) => {
        const peer = row.querySelector<HTMLAnchorElement>('[data-network-peer]')!;
        const peerName = peer.textContent?.replace(/\s*→\s*$/,'').trim() || peer.dataset.networkPeer!;
        const group = row.closest<HTMLElement>('[data-network-group]')!.dataset.networkGroup;
        const direction = group === 'outgoing' ? 'out' : group === 'incoming' ? 'in' : 'joint';
        const label = row.querySelector('p')!.textContent!.trim();
        const kind = row.dataset.kind || '';
        peerNames.push(peerName);
        options.push(new Option((i+1)+'. '+peerName+' · '+(status[kind] ?? directions[direction])+' · '+label, row.dataset.edgeId));
        return {id:row.dataset.edgeId!, peer:peer.dataset.networkPeer!, label, kind, direction, caseId:row.dataset.caseId!};
      });
      picker.replaceChildren(...options);
      const indices = edges.map((_,i)=>i);
      const featured:number[] = [];
      const eligible = indices.filter(i => atlas.querySelector<HTMLButtonElement>('[data-company-option="'+CSS.escape(edges[i].peer)+'"]')?.dataset.home);
      const ranked = [...eligible, ...indices.filter(i=>!eligible.includes(i))];
      for (const dir of ['out','in','joint']) {
        const i = ranked.find(i=>edges[i].direction===dir && !featured.some(prev=>edges[prev].peer===edges[i].peer));
        if(i!==undefined)featured.push(i);
      }
      for (const i of ranked) if(featured.length<3 && !featured.some(prev=>edges[prev].peer===edges[i].peer))featured.push(i);
      for (const i of ranked) if(featured.length<3 && !featured.includes(i))featured.push(i);
      picks.replaceChildren(...featured.map(i=>{
        const edge=edges[i], button=document.createElement('button');
        button.type='button';
        button.dataset.relationPick=edge.id;
        button.setAttribute('aria-controls','map-relation-detail company-connections');
        const number=document.createElement('b'), heading=document.createElement('strong'), text=document.createElement('small');
        number.textContent=String(i+1);
        heading.textContent=peerNames[i]+' · '+(status[edge.kind] ?? directions[edge.direction]);
        text.textContent=edge.label;
        button.append(number,heading,text);
        return button;
      }));
    }
    const index = edges.findIndex(edge => edge.id === id);
    const edge = edges[index];
    selected = edge?.id ?? '';
    panel.hidden = !edges.length || company.startsWith('ext-');
    detail.hidden = !edge;
    picker.value = selected;
    for (const button of picks.querySelectorAll<HTMLButtonElement>('[data-relation-pick]')) {
      button.setAttribute('aria-pressed', String(button.dataset.relationPick === selected));
    }
    for (let i=0; i<rows.length; i++) {
      rows[i].toggleAttribute('data-selected', i === index);
      if (i===index) rows[i].setAttribute('aria-current','true');
      else rows[i].removeAttribute('aria-current');
    }
    if (edge) {
      const peer = peerNames[index];
      const [from,to] = edge.direction === 'in' ? [peer,companyName] : [companyName,peer];
      const connector = edge.direction === 'joint' ? ' ↔ ' : status[edge.kind] ? ' · ' : ' → ';
      pair.textContent = (index+1)+'. '+from+connector+to+' · '+(status[edge.kind] ?? directions[edge.direction]);
      product.textContent = edge.label;
      const url = new URL(location.href);
      url.hash = 'case-'+edge.caseId;
      jump.href = url.href;
      source.href = rows[index].querySelector<HTMLAnchorElement>('[data-network-source]')!.href;
    }
    publish();
    return edge;
  };
}
