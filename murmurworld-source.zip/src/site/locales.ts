import { homeDecorEntries } from './home-decor';
import { firstEpisode } from './murmurworld';

export type SiteLanguage = 'ko' | 'en';

export const translatedPages = [
  '/',
  '/about/',
  '/privacy/',
  '/blog/',
  '/blog/outside/',
  '/blog/outside/orso-espresso-bar-huam/',
  '/blog/home/',
  '/blog/home/decor/',
  ...homeDecorEntries.map(({ href }) => href),
  firstEpisode.href,
];

export const englishPath = (path: string) => `/en${path}`;
