import { homeDecorEntries } from './home-decor';
import { firstEpisode } from './murmurworld';
import { baliTrip } from './bali-trip';
import { marketEntries } from './markets';

export type SiteLanguage = 'ko' | 'en';

export const translatedPages = [
  '/',
  '/about/',
  '/privacy/',
  '/blog/',
  '/stocks/',
  '/blog/outside/',
  '/blog/outside/orso-espresso-bar-huam/',
  baliTrip.href,
  '/blog/companies/',
  '/blog/funds/',
  ...marketEntries.map(({ href }) => href),
  '/blog/home/',
  '/blog/home/decor/',
  ...homeDecorEntries.map(({ href }) => href),
  firstEpisode.href,
];

export const englishPath = (path: string) => `/en${path}`;
