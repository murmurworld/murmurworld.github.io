import { homeDecorEntries } from './home-decor';
import { householdPowerPath } from './household-power.mjs';

export type SiteLanguage = 'ko' | 'en';

export const translatedPages = [
  '/',
  '/about/',
  '/privacy/',
  '/blog/',
  '/blog/outside/',
  '/blog/outside/orso-espresso-bar-huam/',
  '/blog/home/',
  '/blog/home/decor/',
  householdPowerPath,
  ...homeDecorEntries.map(({ href }) => href),
  '/blog/murmurworld/',
  '/blog/murmurworld/intro/',
  '/blog/murmurworld/first-light/',
];

export const englishPath = (path: string) => `/en${path}`;
