export type SiteLanguage = 'ko' | 'en';

export const translatedPages = [
  '/',
  '/about/',
  '/privacy/',
  '/blog/',
  '/blog/outside/',
  '/blog/outside/orso-espresso-bar-huam/',
  '/blog/home/',
  '/blog/home/decor/',
  '/blog/home/decor/energy/',
  '/blog/murmurworld/',
  '/blog/murmurworld/intro/',
  '/blog/murmurworld/first-light/',
];

export const englishPath = (path: string) => `/en${path}`;
