import { homeDecorEntries } from './home-decor';
import { firstEpisode } from './murmurworld';
import { baliTrip } from './bali-trip';
import { companiesTopic } from './companies';
import { companyGuideEntries } from './company-guides';

export type SiteLanguage = 'ko' | 'en';

export const translatedPages = [
  '/',
  '/about/',
  '/privacy/',
  '/blog/',
  '/blog/outside/',
  '/blog/outside/orso-espresso-bar-huam/',
  baliTrip.href,
  companiesTopic.href,
  ...companyGuideEntries.map(({ href }) => href),
  '/blog/home/',
  '/blog/home/decor/',
  ...homeDecorEntries.map(({ href }) => href),
  firstEpisode.href,
];

export const englishPath = (path: string) => `/en${path}`;
