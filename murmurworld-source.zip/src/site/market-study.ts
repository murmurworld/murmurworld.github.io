import type { SiteLanguage } from './locales';

export interface StudyQuestion { question: string; answer: string; source: string }
export interface StudyCase {
  featured: string;
  title: string;
  intro: string;
  lenses: { label: string; body: string; source: string }[];
  exercise: StudyQuestion;
  peers: string[];
}
type StudyMetadata = { study?: StudyQuestion; studyCase?: StudyCase };
const articles = import.meta.glob<StudyMetadata>('../articles/companies/**/*.{ko,en}.md', {
  eager: true, import: 'frontmatter',
});
export function companyMetadata(path: string, lang: SiteLanguage) {
  return articles[`../articles/companies/${path}.${lang}.md`];
}
