import { frontmatter as korean } from '../articles/outside/bali-trip.ko.md';
import { frontmatter as english } from '../articles/outside/bali-trip.en.md';

export const baliTrip = {
  href: '/blog/outside/bali-trip/',
  title: korean.title,
  titleEn: english.title,
  description: korean.description,
  descriptionEn: english.description,
  cover: {
    src: '/media/bali/petitenget-sunset.webp', width: 1280, height: 853,
    alt: '스미냑 페티텐겟 해변의 해 질 무렵', altEn: 'Sunset at Petitenget Beach in Seminyak',
  },
  section: { id: 'outside', href: '/blog/outside/', title: '집 밖', titleEn: 'Out & About' },
};
