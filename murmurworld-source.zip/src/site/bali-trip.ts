import { frontmatter as korean } from '../articles/outside/bali-trip.ko.md';
import { frontmatter as english } from '../articles/outside/bali-trip.en.md';

export const baliTrip = {
  href: '/blog/outside/bali-trip/',
  title: korean.title,
  titleEn: english.title,
  description: korean.description,
  descriptionEn: english.description,
  cover: { label: '발리', labelEn: 'Bali' },
  section: { id: 'outside', href: '/blog/outside/', title: '집 밖', titleEn: 'Out & About' },
};
