/* app.js — 전기요금 역산 계산기. elec_calc.py 를 그대로 옮긴 계산부 + 화면.
   수치는 data/tariff.json 하나가 정본이다. */
(function () {
  "use strict";

  // ---------- 계산부 (elec_calc.py 포팅) ----------
  const roundWon = (x) => Math.floor(x + 0.5);
  const floor10 = (x) => Math.floor(x / 10) * 10;
  const tierOf = (kwh, bounds) => (kwh <= bounds[0] ? 1 : kwh <= bounds[1] ? 2 : 3);

  function bill(kwh, season, contract, T) {
    const s = T.seasons[season], c = T.contracts[contract];
    const [b1, b2] = s.bounds, [r1, r2, r3] = c.rate;
    const t = tierOf(kwh, s.bounds);
    const energy = Math.floor(Math.min(kwh, b1) * r1 + Math.max(0, Math.min(kwh, b2) - b1) * r2 + Math.max(0, kwh - b2) * r3);
    const surcharge = Math.floor(kwh * (T.surcharge_per_kwh.climate + T.surcharge_per_kwh.fuel_adj));
    const base = c.base[t - 1];
    const subtotal = base + energy + surcharge;
    const vat = roundWon(subtotal * T.vat_rate);
    const fund = floor10(subtotal * T.fund_rate);
    const total = floor10(subtotal + vat + fund);
    return { kwh, season, contract, tier: t, base, energy, surcharge, subtotal, vat, fund, total };
  }
  function marginalRate(tier, contract, T) {
    const c = T.contracts[contract], mult = 1 + T.vat_rate + T.fund_rate;
    return (c.rate[tier - 1] + T.surcharge_per_kwh.climate + T.surcharge_per_kwh.fuel_adj) * mult;
  }
  function boundaryJump(fromTier, contract, T) {
    const c = T.contracts[contract], mult = 1 + T.vat_rate + T.fund_rate;
    return (c.base[fromTier] - c.base[fromTier - 1]) * mult + marginalRate(fromTier + 1, contract, T);
  }
  function inverse(total, season, contract, T, tvIncluded, maxKwh = 5000) {
    const target = total - (tvIncluded ? T.tv_license_fee : 0);
    const bounds = T.seasons[season].bounds;
    if (target <= bill(0, season, contract, T).total) return { kwh: 0, tier: 1, flag: "below_minimum", target };
    let lo = 0, hi = maxKwh;
    while (lo < hi) { const mid = Math.floor((lo + hi + 1) / 2); if (bill(mid, season, contract, T).total <= target) lo = mid; else hi = mid - 1; }
    const k = lo, bk = bill(k, season, contract, T).total, bn = bill(k + 1, season, contract, T).total;
    let flag = "ok", kwh = k;
    if (target > bk && target < bn) { if (bounds.includes(k)) flag = "boundary_gap"; else kwh = k + (target - bk) / (bn - bk); }
    else if (k >= maxKwh) flag = "above_range";
    kwh = Math.round(kwh * 10) / 10;
    const t = tierOf(kwh, bounds);
    const nxt = bounds.find((b) => kwh < b) ?? null;
    return { kwh, tier: t, flag, target, next_boundary: nxt, headroom: nxt === null ? null : Math.round((nxt - kwh) * 10) / 10,
      marginal: Math.round(marginalRate(t, contract, T) * 100) / 100, jump_if_cross: t === 3 ? null : Math.round(boundaryJump(t, contract, T)) };
  }
  function increment(baseKwh, addKwh, season, contract, T) {
    const before = bill(baseKwh, season, contract, T), after = bill(baseKwh + addKwh, season, contract, T);
    return { season, before_kwh: baseKwh, after_kwh: baseKwh + addKwh, before_total: before.total, after_total: after.total,
      delta: after.total - before.total, from_tier: before.tier, to_tier: after.tier, crossed: after.tier > before.tier,
      per_kwh: addKwh === 0 ? null : Math.round(((after.total - before.total) / addKwh) * 10) / 10 };
  }
  function applianceKwh(row, hoursPerDay, timesPerWeek) {
    const w = num(row["대표스펙_W"]), per = num(row["회당_kWh"]), rep = num(row["월kWh_대표"]) || 0;
    const p = row["패턴"];
    if (p === "상시" && w) return r1(w * 24 * 30 / 1000);
    if (p === "일일시간" && w && hoursPerDay != null) return r1(w * hoursPerDay * 30 / 1000);
    if (p === "회당" && per && timesPerWeek != null) return r1(per * timesPerWeek * 30 / 7);
    return rep;
  }
  const num = (v) => (v === null || v === undefined || v === "" ? null : Number(v));
  const r1 = (x) => Math.round(x * 10) / 10;

  // ---------- 상태·DOM ----------
  const root = document.querySelector("[data-reverse-calculator]");
  if (!root) return;
  const $ = (id) => root.querySelector(`#${id}`);
  if (!$("billRows") || !$("applList")) return;
  const en = (root.lang || document.documentElement.lang) === "en";
  const locale = en ? "en-US" : "ko-KR";
  const tr = (ko, english) => en ? english : ko;
  const fmt = (n) => Math.round(n).toLocaleString(locale);
  const won = (n) => tr(`${fmt(n)}원`, `₩${fmt(n)}`);
  const tierText = (tier) => tr(`${tier}단계`, `Tier ${tier}`);
  const usageText = (n) => n.toLocaleString(locale);
  const SEASON_LABEL = { normal: tr("기타계절", "Non-summer"), summer: tr("하계(7·8월)", "Summer (Jul–Aug)") };
  const MAX_AMOUNT = 100000000;
  const MAX_KWH = 100000;
  const contractType = (value) => value === "high" ? "high" : "low";
  const isSeason = (value) => value === "normal" || value === "summer";
  const validNumber = (value, minimum, maximum) => typeof value === "number" && Number.isFinite(value) && value >= minimum && value <= maximum;
  let T = null, DB = null;
  const state = { rows: [{ amount: "", season: "normal" }, { amount: "", season: "normal" }, { amount: "", season: "normal" }],
    inverse: null, baseKwh: null, appliances: [] };

  function parseHoursDefault(row) {
    const m = String(row["기본사용"] || "").match(/([\d.]+)\s*(h|시간)/);
    if (m) return Number(m[1]);
    const mm = String(row["기본사용"] || "").match(/([\d.]+)\s*분/);
    if (mm) return Number(mm[1]) / 60;
    return 8;
  }
  function parseTimesDefault(row) {
    const s = String(row["기본사용"] || "");
    const w = s.match(/주\s*([\d.]+)\s*회/); if (w) return Number(w[1]);
    const d = s.match(/(매일|([\d.]+)\s*회\s*\/\s*일)/); if (d) return (d[2] ? Number(d[2]) : 1) * 7;
    return 3;
  }

  function renderBillRows() {
    const box = $("billRows"); box.innerHTML = "";
    state.rows.forEach((r, i) => {
      const amountLabel = tr(`${i + 1}번째 달 전기요금(원)`, `Month ${i + 1} bill (KRW)`);
      const normal = tr("기타계절(1~6·9~12월)", "Non-summer (Jan–Jun, Sep–Dec)");
      const div = document.createElement("div"); div.className = "row cols-2";
      div.innerHTML = `<div><label for="reverse-amount-${i}">${amountLabel}</label><input id="reverse-amount-${i}" type="number" min="0" max="${MAX_AMOUNT}" step="1" inputmode="numeric" placeholder="38,440" data-i="${i}" class="amt"></div>
        <div><label for="reverse-season-${i}">${tr("계절", "Season")}</label><select id="reverse-season-${i}" data-i="${i}" class="season"><option value="normal">${normal}</option><option value="summer">${SEASON_LABEL.summer}</option></select></div>`;
      div.querySelector(".amt").value = r.amount;
      div.querySelector(".season").value = r.season;
      box.appendChild(div);
    });
    $("btnAddRow").disabled = state.rows.length >= 6;
    box.querySelectorAll(".amt").forEach((el) => el.addEventListener("input", (e) => { state.rows[e.target.dataset.i].amount = e.target.value; }));
    box.querySelectorAll(".season").forEach((el) => el.addEventListener("change", (e) => { state.rows[e.target.dataset.i].season = e.target.value; }));
  }

  function runInverse() {
    const contract = contractType($("contract").value), tv = $("tv").checked;
    const rows = state.rows.filter((r) => validNumber(Number(r.amount), 1, MAX_AMOUNT) && isSeason(r.season));
    const feedback = $("reverseBillFeedback");
    if (feedback) {
      feedback.textContent = rows.length ? "" : tr("고지서 금액을 하나 이상 넣어 주세요.", "Enter at least one bill amount.");
      feedback.classList.toggle("hidden", rows.length > 0);
    }
    if (!rows.length) {
      state.inverse = null;
      $("inverseOut").classList.add("hidden");
      renderCard();
      return;
    }
    const results = rows.map((r) => ({ ...r, inv: inverse(Number(r.amount), r.season, contract, T, tv) }));
    const body = $("inverseBody"); body.innerHTML = "";
    results.forEach((r, i) => {
      const inv = r.inv;
      const notes = {
        boundary_gap: tr(`경계 직전(${inv.kwh}kWh)으로 봄`, `Estimated just below the boundary (${inv.kwh} kWh)`),
        below_minimum: tr("기본요금 미만 금액", "Below the base charge"),
        above_range: tr("범위 초과", "Above the supported range"),
      };
      body.insertAdjacentHTML("beforeend", `<tr><td>${i + 1}</td><td class="num">${fmt(r.amount)}</td><td>${SEASON_LABEL[r.season]}</td><td class="num">${usageText(inv.kwh)}</td><td>${tierText(inv.tier)}</td><td>${notes[inv.flag] || ""}</td></tr>`);
    });
    const avg = results.reduce((a, r) => a + r.inv.kwh, 0) / results.length;
    const avgR = Math.round(avg * 10) / 10;
    const nb = T.seasons.normal.bounds, t = tierOf(avgR, nb);
    const nxt = nb.find((b) => avgR < b) ?? null;
    $("kAvg").textContent = `${usageText(avgR)} kWh`;
    $("kTier").textContent = tierText(t);
    $("kHead").textContent = nxt === null ? tr("3단계(경계 없음)", "Tier 3 (highest tier)") : `${r1(nxt - avgR)} kWh (${nxt} kWh)`;
    $("kMarg").textContent = won(marginalRate(t, contract, T));
    const jump = t === 3 ? null : Math.round(boundaryJump(t, contract, T));
    $("inverseNote").textContent = jump
      ? tr(`다음 경계를 1kWh 넘기면 기본요금이 바뀌어 약 ${won(jump)}이 한꺼번에 늘어나요.`, `Crossing the next tier by 1 kWh adds about ${won(jump)}, including the higher base charge.`)
      : tr("이미 3단계라 이 누진 구간의 한계 단가가 적용돼요.", "Usage is in tier 3, and the corresponding marginal rate applies.");
    $("inverseOut").classList.remove("hidden");
    state.inverse = { contract, tv, results, avg: avgR };
    if (!$("baseKwh").value) { $("baseKwh").value = Math.round(avgR); }
    state.baseKwh = Number($("baseKwh").value);
    runDelta(); renderCard();
  }

  // ---------- 2단 ----------
  const categoryNames = {
    냉장: "Refrigeration", 세탁건조: "Laundry", 주방: "Kitchen", "공기·물": "Air and water", 냉방: "Cooling",
    난방: "Heating", 청소: "Cleaning", "영상·컴퓨터": "TV and computing", 조명: "Lighting",
    기타: "Other", "신혼 가전 예시": "Example household appliances",
  };
  // The published appliance database assigns IDs 1–54 to the general presets.
  const applianceNames = [
    "Side-by-side refrigerator, 800 L (Grade 1)", "Side-by-side refrigerator, 850 L (Grade 2)",
    "Four-door refrigerator, 900 L", "Compact refrigerator, 150–200 L", "Upright kimchi refrigerator, 300 L",
    "Chest-style kimchi refrigerator, 200 L", "Wine fridge, 50 bottles", "Front-load washer, 21 kg",
    "Top-load washer, 16 kg", "Heat pump dryer, 17 kg", "Electric resistance dryer", "Washer-dryer combo, 25 kg",
    "Dishwasher, 12 place settings", "Induction cooktop, 3 burners", "Radiant cooktop, 2 burners",
    "IH rice cooker, 10 servings (with keep-warm)", "Electric rice cooker (without keep-warm)", "Microwave, 1,100 W",
    "Air fryer, 1,600 W", "Electric oven, 2.5 kW", "Electric kettle, 1,800 W", "Coffee machine, 1,300 W",
    "Instant hot water purifier", "Water purifier with ice maker", "Water purifier with hot-water tank",
    "Wall-mounted inverter AC, 23–30 m²", "Floor-standing inverter AC, 50–66 m²", "Ceiling or two-in-one AC",
    "Wall-mounted fixed-speed AC", "Fan, 50 W", "Air circulator, 35 W", "Dehumidifier, 15 L",
    "Electric space heater, 1.8 kW", "Single electric heating mat", "Double heated water mat",
    "Storage water heater, 50 L", "Gas boiler pump and controls", "Mid-size air purifier, 20 W",
    "Ultrasonic humidifier", "Warm-mist humidifier", "Robot vacuum and dock", "Cordless vacuum (charging)",
    "65-inch 4K TV", "TV, 75 inches or larger", "Set-top box and router", "Gaming desktop",
    "Office or mini PC", "32-inch monitor", "Laptop, 40 W", "LED lighting, 150 W total",
    "Bidet seat (standby and hot water)", "Hair dryer, 1,800 W", "Iron, 1,500 W", "EV charging, 1,500 km/month",
  ];
  const householdNames = {
    601: "Kitchen Fit refrigerator, 609 L (RM80H64S2A)", 602: "Washer-dryer, 25/20 kg (WD90H25AHY)",
    603: "Air purifier (AP90H03163UGD)", 604: "Robot vacuum (VR90F01AAG)", 605: "Water purifier (RWP70F15ANW)",
  };
  const categoryName = (category) => tr(category, categoryNames[category] || category);
  const applianceName = (row) => tr(row["제품"], applianceNames[row.id - 1] || householdNames[row.id] || row["제품"]);
  const monthlyUsage = (value) => tr(`${usageText(value)} kWh/월`, `${usageText(value)} kWh/mo`);
  const usageRange = (row) => `${row["월kWh_하한"]}–${row["월kWh_상한"]} kWh`;

  function renderCats() {
    $("cat").replaceChildren(...DB.categories.map((category) => new Option(categoryName(category), category)));
    renderAppl();
  }
  function renderAppl() {
    const items = DB.items.filter((row) => row["분류"] === $("cat").value);
    $("appl").replaceChildren(...items.map((row) => new Option(
      `${applianceName(row)} · ${monthlyUsage(Number(row["월kWh_대표"]))} (${row["근거등급"]})`, row.id
    )));
    showHint();
  }
  function showHint() {
    const row = DB.items.find((r) => String(r.id) === $("appl").value); if (!row) return;
    const usage = {
      상시: "Always on",
      일일시간: `Default ${usageText(r1(parseHoursDefault(row)))} hours/day`,
      회당: `Default ${usageText(parseTimesDefault(row))} cycles/week`,
    };
    $("applHint").textContent = tr(
      `${row["패턴"]} · 기본 ${row["기본사용"] || "—"} · 범위 ${usageRange(row)} · ${row["산정메모"] || ""}`,
      `${usage[row["패턴"]] || "Representative estimate"} · Typical range ${usageRange(row)} per month`,
    );
  }
  function addAppl() {
    const row = DB.items.find((r) => String(r.id) === $("appl").value); if (!row) return;
    const item = { id: row.id, row, hours: parseHoursDefault(row), times: parseTimesDefault(row), kwh: null };
    item.kwh = computeKwh(item);
    state.appliances.push(item); renderApplList(); runDelta(); renderCard();
  }
  function computeKwh(item) {
    const p = item.row["패턴"];
    if (item.override != null) return item.override;
    if (p === "일일시간") return applianceKwh(item.row, item.hours, null);
    if (p === "회당") return applianceKwh(item.row, null, item.times);
    return applianceKwh(item.row, null, null);
  }
  function renderApplList() {
    const box = $("applList"); box.innerHTML = "";
    state.appliances.forEach((it, i) => {
      const p = it.row["패턴"];
      let ctrl = "";
      if (p === "일일시간") ctrl = `<label>${tr("하루 사용 시간", "Hours/day")} <input type="number" step="any" min="0" max="24" value="${it.hours}" data-i="${i}" class="hrs"></label>`;
      else if (p === "회당") ctrl = `<label>${tr("주간 사용 횟수", "Cycles/week")} <input type="number" step="any" min="0" max="50" value="${it.times}" data-i="${i}" class="tms"></label>`;
      else ctrl = `<span class="meta">${p === "상시" ? tr("24시간 상시", "Always on") : tr("복합(대표값)", "Representative estimate")}</span>`;
      ctrl += ` <label>${tr("월 kWh 직접 입력", "Set monthly kWh")} <input type="number" step="any" min="0" max="${MAX_KWH}" value="${it.override ?? ""}" data-i="${i}" class="ovr"></label>`;
      const div = document.createElement("div"); div.className = "appl-row";
      div.innerHTML = `<div><div class="name"></div><div class="meta"></div><div class="ctrl">${ctrl}</div></div>
        <div><div class="kwh">${monthlyUsage(it.kwh)}</div><button type="button" class="secondary small" data-i="${i}" data-act="rm">${tr("빼기", "Remove")}</button></div>`;
      div.querySelector(".name").textContent = applianceName(it.row);
      div.querySelector(".meta").textContent = `${categoryName(it.row["분류"])} · ${tr("근거", "Grade")} ${it.row["근거등급"]} · ${usageRange(it.row)}`;
      div.querySelector("button").setAttribute("aria-label", tr(`${applianceName(it.row)} 빼기`, `Remove ${applianceName(it.row)}`));
      box.appendChild(div);
    });
    box.querySelectorAll("input").forEach((input) => input.addEventListener("input", () => {
      input.setAttribute("aria-invalid", String(!input.validity.valid));
      if (!input.validity.valid) return;
      const item = state.appliances[input.dataset.i];
      if (input.classList.contains("ovr")) item.override = input.value === "" ? null : Number(input.value);
      else {
        item[input.classList.contains("hrs") ? "hours" : "times"] = Number(input.value);
        item.override = null;
        input.closest(".appl-row").querySelector(".ovr").value = "";
      }
      item.kwh = computeKwh(item);
      refreshList();
    }));
    box.querySelectorAll("[data-act=rm]").forEach((el) => el.addEventListener("click", (e) => { state.appliances.splice(Number(e.target.dataset.i), 1); renderApplList(); runDelta(); renderCard(); }));
  }
  function refreshList() {
    $("applList").querySelectorAll(".kwh").forEach((element, i) => { element.textContent = monthlyUsage(state.appliances[i].kwh); });
    runDelta(); renderCard();
  }
  function runDelta() {
    const input = $("baseKwh");
    const validBase = validNumber(input.valueAsNumber, 0, MAX_KWH);
    state.baseKwh = validBase ? input.valueAsNumber : null;
    input.setAttribute("aria-invalid", String(!input.validity.valid));
    const add = Math.round(state.appliances.reduce((a, it) => a + it.kwh, 0) * 10) / 10;
    $("kAdd").textContent = `${usageText(add)} kWh`;
    if (!validBase) {
      $("kDeltaN").textContent = $("kDeltaS").textContent = $("kAnnual").textContent = tr("기준 사용량 필요", "Enter starting use");
      $("deltaTable").classList.add("hidden");
      $("crossOut").replaceChildren();
      state.delta = null;
      return;
    }
    const contract = contractType($("contract").value);
    const n = increment(state.baseKwh, add, "normal", contract, T), s = increment(state.baseKwh, add, "summer", contract, T);
    const annual = n.delta * 10 + s.delta * 2;
    $("kDeltaN").textContent = `+${won(n.delta)}`; $("kDeltaS").textContent = `+${won(s.delta)}`; $("kAnnual").textContent = `+${won(annual)}`;
    const body = $("deltaBody"); body.innerHTML = "";
    [n, s].forEach((r) => {
      const change = tr(`${r.from_tier}→${r.to_tier}단계`, `Tier ${r.from_tier} → ${r.to_tier}`);
      const crossed = r.crossed ? ` <span class="badge danger">${tr("경계 넘음", "Higher tier")}</span>` : "";
      body.insertAdjacentHTML("beforeend", `<tr><td>${SEASON_LABEL[r.season]}</td><td class="num">${usageText(r.before_kwh)}</td><td class="num">${won(r.before_total)}</td><td class="num">${usageText(r1(r.after_kwh))}</td><td class="num">${won(r.after_total)}</td><td class="num">+${won(r.delta)}</td><td>${change}${crossed}</td></tr>`);
    });
    $("deltaTable").classList.toggle("hidden", add === 0);
    let msg = "";
    if (add > 0) {
      const mN = Math.round(marginalRate(n.from_tier, contract, T));
      const nonSummer = n.crossed
        ? tr(`기타계절에는 ${n.from_tier}단계에서 ${n.to_tier}단계로 넘어가요. 기본요금 인상분까지 포함하면 추가 사용량 1kWh당 약 ${won(n.per_kwh)}이에요. 원래 구간에서는 약 ${won(mN)}이에요.`,
          `Outside summer, these appliances move usage from tier ${n.from_tier} to ${n.to_tier}. With the higher base charge, each added kWh costs about ${won(n.per_kwh)}. The current tier charges about ${won(mN)} per kWh.`)
        : tr(`기타계절에는 구간을 유지해요. 추가 사용량 1kWh당 약 ${won(mN)}, 월 +${won(n.delta)}이에요.`,
          `Outside summer, usage stays in the same tier at about ${won(mN)} per added kWh, or +${won(n.delta)} a month.`);
      msg += `<div class="alert${n.crossed ? " danger" : ""}">${nonSummer}</div>`;
      if (s.crossed) msg += `<div class="alert">${tr(`7·8월에는 ${s.from_tier}단계에서 ${s.to_tier}단계로 넘어가요. 월 +${won(s.delta)}이에요.`,
        `In July and August, usage moves from tier ${s.from_tier} to ${s.to_tier} and costs +${won(s.delta)} a month.`)}</div>`;
    }
    $("crossOut").innerHTML = msg;
    state.delta = { n, s, annual, add };
  }

  // ---------- 3단 ----------
  function renderCard() {
    const lines = [];
    const contract = contractType($("contract").value);
    const contractLabel = $("contract").selectedOptions[0].textContent;
    lines.push(`${tr("[전기요금 역산 계산기]", "[Electricity bill estimator]")} ${contractLabel}`);
    if (state.inverse) {
      state.inverse.results.forEach((r, i) => {
        const month = tr(`${i + 1}번째 달`, `Month ${i + 1}`);
        lines.push(`${month} ${won(r.amount)} (${SEASON_LABEL[r.season]}) → ≈${usageText(r.inv.kwh)} kWh, ${tierText(r.inv.tier)}`);
      });
      const t = tierOf(state.inverse.avg, T.seasons.normal.bounds);
      const price = won(marginalRate(t, contract, T));
      lines.push(tr(`평균 ${usageText(state.inverse.avg)} kWh · 지금 1kWh = 약 ${price}`,
        `Average ${usageText(state.inverse.avg)} kWh · Next kWh ≈ ${price}`));
    }
    if (state.delta && state.delta.add > 0) {
      const { n, s, annual } = state.delta;
      const names = state.appliances.map((it) => `${applianceName(it.row)} ${usageText(it.kwh)} kWh`).join(", ");
      const increase = tr(" (경계 넘음)", " (higher tier)");
      const normal = `${won(n.delta)}${n.crossed ? increase : ""}`;
      const summer = `${won(s.delta)}${s.crossed ? increase : ""}`;
      lines.push(`${tr("추가 가전", "Added appliances")} · ${names}`);
      lines.push(tr(`→ 기타계절 월 +${normal}, 하계 월 +${summer}, 연간 약 +${won(annual)}`,
        `→ +${normal}/mo outside summer, +${summer}/mo in summer, about +${won(annual)}/year`));
    }
    lines.push(tr(`근사값 · 요금표 ${T.effective_from} 기준`, `Estimates · Tariff effective ${T.effective_from}`));
    $("cardText").textContent = lines.join("\n");
  }
  let copyTimer;
  async function copyText(text, msg) {
    const status = $("copyMsg");
    clearTimeout(copyTimer);
    try {
      await navigator.clipboard.writeText(text);
      status.textContent = msg;
    } catch {
      status.textContent = tr("복사하지 못했어요. 내용이나 주소를 직접 복사해 주세요.", "Copy the summary or address manually.");
    }
    copyTimer = setTimeout(() => { status.textContent = ""; }, 3000);
  }
  function encodeState() {
    const s = { c: contractType($("contract").value), tv: $("tv").checked ? 1 : 0,
      rows: state.rows.filter((r) => r.amount !== "" && validNumber(Number(r.amount), 0, MAX_AMOUNT)).map((r) => [Number(r.amount), r.season]),
      base: state.baseKwh, ap: state.appliances.map((it) => [it.id, it.hours, it.times, it.override]) };
    return btoa(JSON.stringify(s)).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  function decodeState() {
    const match = location.hash.match(/^#s=([A-Za-z0-9_-]{1,100000})$/);
    if (!match || !DB) return;
    let s;
    try {
      const b = match[1].replace(/-/g, "+").replace(/_/g, "/");
      s = JSON.parse(atob(b + "=".repeat((4 - b.length % 4) % 4)));
    } catch {
      return;
    }
    if (!s || typeof s !== "object" || Array.isArray(s)) return;

    $("contract").value = contractType(s.c);
    $("tv").checked = s.tv === 1 || s.tv === true;
    $("baseKwh").value = validNumber(s.base, 0, MAX_KWH) ? s.base : "";
    state.inverse = null;
    $("inverseOut").classList.add("hidden");

    const rows = Array.isArray(s.rows) ? s.rows.slice(0, 6) : [];
    state.rows = rows.filter((row) => Array.isArray(row) && validNumber(row[0], 0, MAX_AMOUNT) && isSeason(row[1]))
      .map(([amount, season]) => ({ amount, season }));
    while (state.rows.length < 3) state.rows.push({ amount: "", season: "normal" });
    renderBillRows();

    const appliances = Array.isArray(s.ap) ? s.ap : [];
    state.appliances = [];
    for (const record of appliances) {
      if (!Array.isArray(record)) continue;
      const [id, hours, times, override] = record;
      const row = DB.items.find((item) => item.id === id);
      if (!row) continue;
      const item = { id, row,
        hours: validNumber(hours, 0, 24) ? hours : parseHoursDefault(row),
        times: validNumber(times, 0, 50) ? times : parseTimesDefault(row),
        override: validNumber(override, 0, MAX_KWH) ? override : null };
      item.kwh = computeKwh(item);
      state.appliances.push(item);
    }
    renderApplList();
    const feedback = $("reverseBillFeedback");
    if (feedback) feedback.classList.add("hidden");
    if (state.rows.some((r) => Number(r.amount) > 0)) runInverse();
    else { runDelta(); renderCard(); }
  }

  function openForHash() {
    if (location.hash === "#bill-reverse" || location.hash.startsWith("#s=")) {
      root.open = true;
      if (location.hash.startsWith("#s=")) requestAnimationFrame(() => root.scrollIntoView({ block: "start" }));
    }
  }

  async function loadData(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`HTTP ${response.status} from ${url}`);
    return response.json();
  }

  // ---------- 초기화 ----------
  async function init() {
    const [t, db] = await Promise.all([loadData("/calc/data/tariff.json"), loadData("/calc/data/appliances.json")]);
    T = t; DB = db;
    for (const id of ["tariffDate", "tariffDate2"]) {
      $(id).textContent = T.effective_from;
      $(id).dateTime = T.effective_from;
    }
    renderBillRows(); renderCats();
    $("cat").addEventListener("change", renderAppl);
    $("appl").addEventListener("change", showHint);
    $("btnInverse").addEventListener("click", runInverse);
    $("btnAddRow").addEventListener("click", () => { if (state.rows.length < 6) { state.rows.push({ amount: "", season: "normal" }); renderBillRows(); } });
    $("btnAddAppl").addEventListener("click", addAppl);
    $("baseKwh").addEventListener("input", () => { runDelta(); renderCard(); });
    $("contract").addEventListener("change", () => { if (state.inverse) runInverse(); else { runDelta(); renderCard(); } });
    $("tv").addEventListener("change", () => { if (state.inverse) runInverse(); });
    $("btnCopy").addEventListener("click", () => copyText($("cardText").textContent, tr("복사했습니다.", "Copied.")));
    $("btnShare").addEventListener("click", () => {
      const hash = "#s=" + encodeState();
      history.replaceState(null, "", hash);
      copyText(location.origin + location.pathname + hash, tr("링크를 복사했습니다.", "Link copied."));
    });
    runDelta();
    renderCard();
    decodeState();
  }
  window.ElecCalc = { bill, inverse, increment, marginalRate, boundaryJump, applianceKwh, tierOf };
  openForHash();
  window.addEventListener("hashchange", () => {
    openForHash();
    decodeState();
  });
  init().catch(() => {
    const status = $("reverseLoadError");
    status.textContent = tr("계산기 데이터를 불러오지 못했어요. 새로고침해 다시 시도해 주세요.", "Calculator data could not load. Refresh to try again.");
    status.classList.remove("hidden");
  });
})();
