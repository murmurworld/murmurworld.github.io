import { householdAppliances } from './household-power.mjs';
import { refrigerationModels } from './refrigeration-models.mjs';

const label = (ko, en) => ({ ko, en });

const groups = [
  { id: 'kitchen', label: label('주방', 'Kitchen') },
  { id: 'laundry', label: label('세탁', 'Laundry') },
  { id: 'living', label: label('거실과 방', 'Living rooms') },
  { id: 'climate', label: label('냉방과 난방', 'Heating and cooling') },
  { id: 'care', label: label('공기·물·청소', 'Air, water and cleaning') },
];

const kindFields = {
  month: '월kWh_대표',
  hours: '대표스펙_W',
  minutes: '대표스펙_W',
  weekly: '회당_kWh',
  daily: '회당_kWh',
};

const customDefaults = [
  [19, label('에어프라이어', 'Air fryer'), 0.5],
  [22, label('커피머신', 'Coffee machine'), 0.17],
  [30, label('선풍기', 'Fan'), 8],
  [39, label('가습기', 'Humidifier'), 10],
  [46, label('데스크톱 컴퓨터', 'Desktop computer'), 8],
  [48, label('모니터', 'Monitor'), 8],
  [51, label('비데', 'Bidet'), 24],
  [52, label('헤어드라이어', 'Hair dryer'), 0.17],
];

export function buildApplianceCatalog(database) {
  const reference = new Map(database.items.map((item) => [item.id, item]));
  const household = new Map(householdAppliances.map((item) => [item.id, item]));
  const kind = (id, name, mode, power, usage = null) => ({
    id: String(id), label: name, mode, power, usage,
  });
  const fromReference = (id, name, mode, usage) => {
    const power = reference.get(id)?.[kindFields[mode]];
    if (!Number.isFinite(power) || power < 0) {
      throw new Error(`Missing appliance reference ${id}: ${kindFields[mode]}`);
    }
    return kind(id, name, mode, power, usage);
  };
  const row = (group, id, name, kinds) => ({ group, id, label: name, kinds });
  const verifiedModels = (rowId) => refrigerationModels[rowId].map(({ model, brandId, year, kwh, photoId, source, ko, en }) => ({
    ...kind(`model-${model}`, label(ko, en), 'month', kwh),
    photoId,
    example: { model, brandId, year, source, basis: 'official' },
  }));
  const combo = fromReference(12, label('세탁건조기 (25/20kg)', 'Washer-dryer (25/20 kg)'), 'weekly', 2);

  const rows = [
    row('kitchen', 'fridge', label('냉장고', 'Refrigerator'), [
      fromReference(1, label('양문 800L', 'Side-by-side 800 L'), 'month'),
      fromReference(2, label('양문 850L', 'Side-by-side 850 L'), 'month'),
      fromReference(3, label('4도어 900L', 'Four-door 900 L'), 'month'),
      fromReference(4, label('소형 200L', 'Compact 200 L'), 'month'),
      kind(601, label('머머월드 · 609L', 'Murmurworld · 609 L'), 'month', household.get(601).kwh),
      kind('kitchen-fit', label('키친핏·깊이가 얕은 600L급', 'Shallow 600 L class'), 'month', household.get(601).kwh),
      ...verifiedModels('fridge'),
    ]),
    row('kitchen', 'kimchiFridge', label('김치냉장고', 'Kimchi fridge'), [
      fromReference(5, label('스탠드 300L', 'Upright 300 L'), 'month'),
      fromReference(6, label('뚜껑형 200L', 'Chest 200 L'), 'month'),
      ...verifiedModels('kimchiFridge'),
    ]),
    row('kitchen', 'riceCooker', label('전기밥솥', 'Rice cooker'), [
      fromReference(17, label('취사만', 'Cook only'), 'daily', 1),
      fromReference(16, label('취사·보온 12시간', 'Cook and keep warm'), 'month'),
    ]),
    row('kitchen', 'microwave', label('전자레인지', 'Microwave'), [
      fromReference(18, label('일반형', 'Standard'), 'minutes', 10),
    ]),
    row('kitchen', 'kettle', label('전기포트', 'Kettle'), [
      fromReference(21, label('1L 기준', '1 L per boil'), 'daily', 3),
    ]),
    row('kitchen', 'dishwasher', label('식기세척기', 'Dishwasher'), [
      fromReference(13, label('12인용', '12 place settings'), 'daily', 1),
    ]),
    row('kitchen', 'range', label('전기레인지', 'Electric cooktop'), [
      fromReference(14, label('인덕션 3구', '3-zone induction'), 'minutes', 40),
      fromReference(15, label('하이라이트 2구', '2-zone radiant'), 'minutes', 40),
    ]),
    row('laundry', 'washer', label('세탁기', 'Washer'), [
      fromReference(8, label('드럼 21kg', 'Front-load 21 kg'), 'weekly', 2),
      fromReference(9, label('통돌이 16kg', 'Top-load 16 kg'), 'weekly', 2),
      { ...combo, id: '602' },
      { ...combo, id: 'washer-combo', label: label('일체형 세탁건조기', 'All-in-one washer-dryer') },
    ]),
    row('laundry', 'dryer', label('건조기', 'Dryer'), [
      fromReference(10, label('히트펌프 17kg', 'Heat-pump 17 kg'), 'weekly', 2),
      fromReference(11, label('히터식', 'Resistance heater'), 'weekly', 2),
    ]),
    row('living', 'lighting', label('조명', 'Lighting'), [
      fromReference(50, label('LED 조명', 'LED lights'), 'hours', 5),
    ]),
    row('living', 'tv', label('TV', 'TV'), [
      fromReference(43, label('65형', '65-inch'), 'hours', 4),
      fromReference(44, label('75형 이상', '75-inch or larger'), 'hours', 4),
    ]),
    row('living', 'router', label('공유기', 'Router'), [
      fromReference(45, label('셋톱+공유기', 'Router and TV box'), 'hours', 24),
      kind('router-only', label('공유기만', 'Router only'), 'hours', 10, 24),
    ]),
    row('living', 'laptop', label('노트북', 'Laptop'), [
      fromReference(49, label('일반형', 'Standard'), 'hours', 8),
    ]),
    row('living', 'other', label('기타 기기', 'Other devices'), [
      kind('other', label('충전기·대기전력', 'Chargers and standby'), 'month', 10),
    ]),
    row('climate', 'ac', label('에어컨', 'Air conditioner'), [
      fromReference(26, label('벽걸이', 'Wall-mounted'), 'hours', 4),
      fromReference(27, label('스탠드형', 'Floor-standing'), 'hours', 4),
      fromReference(28, label('두 대', 'Two units'), 'hours', 4),
      fromReference(29, label('구형 정속', 'Fixed-speed'), 'hours', 4),
    ]),
    row('climate', 'heater', label('전기히터', 'Electric heater'), [
      fromReference(33, label('일반형', 'Standard'), 'hours', 2),
    ]),
    row('climate', 'blanket', label('전기장판', 'Heated mat'), [
      fromReference(34, label('1인용 장판', 'Single electric mat'), 'hours', 8),
      fromReference(35, label('2인용 온수매트', 'Double water-heated mat'), 'hours', 8),
    ]),
    row('care', 'waterPurifier', label('정수기', 'Water purifier'), [
      fromReference(23, label('순간온수', 'Instant hot water'), 'month'),
      fromReference(24, label('얼음정수기', 'With ice maker'), 'month'),
      fromReference(25, label('저탕식', 'Hot-water tank'), 'month'),
      kind(605, label('머머월드 것', 'Murmurworld model'), 'month', household.get(605).kwh),
    ]),
    row('care', 'airPurifier', label('공기청정기', 'Air purifier'), [
      fromReference(38, label('중형', 'Medium'), 'hours', 24),
      kind(603, label('머머월드 것', 'Murmurworld model'), 'hours', 14.1, 18),
    ]),
    row('care', 'robotVacuum', label('로봇청소기', 'Robot vacuum'), [
      fromReference(41, label('일반형', 'Standard'), 'hours', 24),
      kind(604, label('머머월드 것', 'Murmurworld model'), 'month', household.get(604).kwh),
      kind('robot-dock', label('물걸레 세척 도크형', 'Mop-washing station'), 'month', household.get(604).kwh),
    ]),
    row('care', 'dehumidifier', label('제습기', 'Dehumidifier'), [
      fromReference(32, label('15L급', '15 L class'), 'hours', 6),
    ]),
  ];

  const customPresets = customDefaults.map(([id, name, usage]) => {
    const preset = fromReference(id, name, 'hours', usage);
    return { id: preset.id, label: preset.label, power: preset.power, usage: preset.usage };
  });
  return { groups, rows, customPresets };
}
