import cases from './market-relationships.json';
import { marketGroups } from './markets';
import type { SiteLanguage } from './locales';

export type Direction = 'outgoing' | 'incoming' | 'partners';
type Bilingual = Record<SiteLanguage, string>;
type Participant = { ticker: string | null; name?: { en: string } };

export function networkNodeId(node: Participant) {
  if (node.ticker) return node.ticker;
  if (!node.name?.en) throw new Error('Missing company name in relationship');
  return 'ext-' + node.name.en.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

export function networkHref(lang: SiteLanguage, id: string) {
  const key = id.startsWith('ext-') ? 'peer' : 'company';
  return (lang === 'en' ? '/en' : '') + '/stocks/?' + key + '=' + encodeURIComponent(id);
}

export type NetworkEdge = { peerId: string; caseId: string; component?: string; label: string; source: {label:string; url:string} };
type NetworkCompany = { id: string; name: string; groups: Record<Direction, NetworkEdge[]> };
type Link = { from: number; to: number; joint?: boolean; label: Bilingual; sourceIndex?: number };
const wording = (ko: string, en: string): Bilingual => ({ko, en});

// Short labels for an individual company view must make sense outside the full case diagram.
const labels: Record<string, Bilingual[]> = {
  'ai-servers': [wording('H200용 8단 24GB HBM3E 스택', '8-high, 24 GB HBM3E stack for the H200'), wording('AWS EC2 P5e 서버에 탑재한 H200 가속기', 'H200 accelerators in AWS EC2 P5e servers')],
  hbm4: [wording('SK하이닉스 HBM4 베이스 다이에 TSMC 로직 공정 적용', 'TSMC logic process for the base die of SK hynix HBM4')],
  'dram-patterning': [wording('EUV 노광용 건식 감광막 공동 연구', 'Joint research on dry resist for EUV lithography'), wording('첨단 D램 개발에 채택한 건식 감광막 공정', 'Dry-resist process selected for advanced DRAM development')],
  foundry: [wording('애리조나 팹 21에서 애플 설계 칩 양산', 'Volume production of Apple chips at Fab 21 in Arizona')],
  satellite: [wording('T-Satellite 문자 서비스에 쓰는 스타링크 위성망', 'Starlink satellite coverage for T-Satellite messaging')],
  card: [wording('프라임 비자 카드 발급과 아마존 구매 적립', 'Prime Visa card issuance and Amazon shopping rewards')],
  retail: [wording('월마트·샘스클럽에서 판매하는 스낵과 음료', 'Snacks and drinks sold through Walmart and Sam’s Club')],
  discovery: [wording('릴리팟 연구용 슈퍼컴퓨터에 들어간 DGX B300', 'DGX B300 systems in the LillyPod research supercomputer')],
  'amd-meta-epyc': [wording('메타 서버에 설치한 EPYC 프로세서', 'EPYC processors deployed in Meta’s servers')],
  'qualcomm-galaxy-s25': [wording('갤럭시 S25에 탑재한 스냅드래곤 8 엘리트', 'Snapdragon 8 Elite chips in the Galaxy S25 series')],
  'sandisk-kioxia-yokkaichi': [wording('요카이치 3D 낸드 공장 합작을 2034년까지 연장', 'Yokkaichi 3D NAND manufacturing venture extended to 2034')],
  'intel-cisco-ucs': [wording('UCS M6 서버에 들어간 3세대 제온 CPU', 'Third-generation Xeon CPUs in UCS M6 servers')],
  'ti-delta-ev-chargers': [wording('전기차 탑재형 충전기와 전압 변환기 공동 개발', 'Joint development of onboard EV chargers and voltage converters')],
  'applied-samsung-epic': [wording('EPIC 센터에서 반도체 제조 공정 공동 연구', 'Joint research on chip manufacturing at the EPIC Center')],
  'kla-tsmc-process-control': [wording('웨이퍼 공정 검사·계측 부문의 주요 고객으로 공시', 'Named major customer for semiconductor process control')],
  'crowdstrike-microsoft-marketplace': [wording('마이크로소프트 마켓플레이스에서 팔콘 보안 제품 유통', 'Distribution of Falcon security products on Microsoft Marketplace')],
  'paloalto-google-ai-security': [wording('Prisma AIRS와 구글 클라우드 AI 서비스의 보안 통합 협약', 'Agreement to integrate Prisma AIRS with Google Cloud AI services')],
  'costco-citi-visa': [wording('씨티은행이 발급하는 코스트코 회원 카드의 결제망', 'Payment network for Citi’s Costco member card'), wording('미국 코스트코 회원용 제휴 신용카드', 'Co-branded credit cards for U.S. Costco members')],
  'shinhan-mastercard-sol-travel': [wording('신한 SOL트래블 체크카드의 해외 가맹점 캐시백', 'Overseas merchant rewards on Shinhan’s SOL Travel debit card')],
  'kb-life-microsoft-copilot': [wording('KB라이프생명이 도입한 Microsoft 365 Copilot', 'Microsoft 365 Copilot adopted by KB Life Insurance')],
  'pg-walmart-tide': [wording('월마트에서 판매하는 타이드 액상 세탁세제', 'Tide liquid laundry detergent sold by Walmart')],
  'ktg-pmi-distribution': [wording('KT&G 가열담배 기기와 스틱의 한국 밖 독점 유통 계약', 'Exclusive distribution of KT&G devices and tobacco sticks outside Korea')],
  'novo-wegovy-amazon-pharmacy': [wording('아마존 파머시에서 처방전을 받아 조제하는 위고비', 'Prescription Wegovy dispensed by Amazon Pharmacy')],
  'novo-microsoft-research': [wording('클라우드 컴퓨팅을 이용한 신약 후보 공동 연구', 'Joint drug discovery research using cloud computing')],
  'merck-daiichi-oncology': [wording('항암제 후보의 일본 외 공동 개발·사업화 계약', 'Agreement to jointly develop and commercialize oncology candidates outside Japan')],
  'xom-linde-beaumont': [wording('보몬트 수소 공장의 이산화탄소 운송·저장 계약', 'CO₂ transport and storage agreement for the Beaumont hydrogen plant')],
  'gev-chevron-data-center-turbines': [wording('서부 텍사스 발전소에 사용할 가스터빈', 'Gas turbines planned for a West Texas power plant'), wording('데이터센터용 전력 20년 구매 계약', '20-year power purchase agreement for a data center')],
  'cat-bhp-rio-pilbara': [wording('짐블바 철광산에서 793 XE 배터리 트럭 공동 시험', 'Joint 793 XE battery truck trials at Jimblebar'), wording('짐블바 광산의 배터리 트럭 충전·운행 시험', 'Battery truck charging and operation trials at Jimblebar')],
  'cat-newmont-colorado': [wording('콜로라도 광산에 인도한 793 XE 시험용 트럭', '793 XE trial truck delivered to a Colorado mine')],
  'tesla-toyota-rav4ev': [wording('RAV4 EV 배터리·모터·구동계 납품 (2012~2014년)', 'RAV4 EV batteries, motors and powertrains supplied in 2012–14')],
  'google-home-depot-customer-service': [wording('홈디포 문자·채팅 상담에 도입한 구글 Gemini', 'Google Gemini used for Home Depot SMS and chat support')],
};

// These additional pairs and roles are explicitly described in the cited records.
// A chain of products alone does not establish a direct relationship between its endpoints.
const additional: Record<string, Link[]> = {
  'qualcomm-galaxy-s25': [{from:0, to:1, joint:true, label:wording('갤럭시 S25용 칩의 화질·전력 소모 공동 최적화', 'Joint tuning of the Galaxy S25 chip for display quality and power use'), sourceIndex:1}],
  'sandisk-kioxia-yokkaichi': [{from:1, to:0, label:wording('요카이치 낸드 제조 서비스·물량 확보 계약', 'Agreement for NAND manufacturing services and supply at Yokkaichi')}],
  'cat-bhp-rio-pilbara': [{from:0, to:2, joint:true, label:wording('BHP 광산에서 793 XE 트럭 공동 시험', 'Joint trial of 793 XE trucks at BHP’s mine')}],
  'costco-citi-visa': [{from:0, to:2, label:wording('미국·푸에르토리코 코스트코의 비자 신용카드 결제', 'Visa credit card acceptance at Costco in the U.S. and Puerto Rico')}],
};

export function buildCompanyNetwork(lang: SiteLanguage) {
  const network: Record<string, NetworkCompany> = Object.create(null);
  const register = (id: string, name: string) => {
    if (!network[id]) network[id] = { id, name, groups: { outgoing: [], incoming: [], partners: [] } };
  };
  for (const group of marketGroups.filter(group => group.section === 'companies')) {
    for (const company of group.items) register(company.ticker, lang === 'ko' ? company.name : company.nameEn);
  }
  for (const item of cases) {
    const ids = item.nodes.map(node => {
      const id = networkNodeId(node);
      if (!node.ticker && 'name' in node && node.name) register(id, node.name[lang]);
      if (!network[id]) throw new Error('Unknown company in ' + item.id + ': ' + id);
      return id;
    });
    const links: Link[] = item.edges.map((edge, i) => ({
      from: i, to: i+1, joint: ('joint' in edge && edge.joint) || item.id === 'cat-bhp-rio-pilbara',
      label: labels[item.id]?.[i] ?? edge,
      sourceIndex: (item.id === 'ai-servers' || item.id === 'dram-patterning') ? i : 0,
    }));
    for (const link of [...links, ...(additional[item.id] ?? [])]) {
      const a = ids[link.from], b = ids[link.to];
      const source = item.sources[link.sourceIndex ?? 0];
      const detail = { caseId: item.id, component: item.component, label: link.label[lang], source: {label:source[lang],url:source.url} };
      network[a].groups[link.joint ? 'partners' : 'outgoing'].push({ peerId:b, ...detail });
      network[b].groups[link.joint ? 'partners' : 'incoming'].push({ peerId:a, ...detail });
    }
  }
  return network;
}
