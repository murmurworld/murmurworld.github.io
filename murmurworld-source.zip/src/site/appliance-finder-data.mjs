import { householdAppliances } from './household-power.mjs';

const label = (ko, en) => ({ ko, en });

const brands = [
  ['unknown', '모름', 'Not sure'],
  ['samsung', '삼성전자', 'Samsung'],
  ['lg', 'LG전자', 'LG'],
  ['winia', '위니아·딤채', 'Winia / Dimchae'],
  ['cuckoo', '쿠쿠', 'Cuckoo'],
  ['cuchen', '쿠첸', 'Cuchen'],
  ['tefal', '테팔', 'Tefal'],
  ['philips', '필립스', 'Philips'],
  ['sk-magic', 'SK매직', 'SK Magic'],
  ['osram', '오스람', 'Osram'],
  ['sony', '소니', 'Sony'],
  ['iptime', '아이피타임', 'ipTIME'],
  ['tp-link', '티피링크', 'TP-Link'],
  ['asus', '에이수스', 'ASUS'],
  ['apple', '애플', 'Apple'],
  ['lenovo', '레노버', 'Lenovo'],
  ['hp', 'HP', 'HP'],
  ['dell', '델', 'Dell'],
  ['carrier', '캐리어', 'Carrier'],
  ['shinil', '신일', 'Shinil'],
  ['hanil', '한일전기', 'Hanil Electric'],
  ['ilwoul', '일월', 'Ilwoul'],
  ['navien', '경동나비엔', 'Navien'],
  ['coway', '코웨이', 'Coway'],
  ['winix', '위닉스', 'Winix'],
  ['xiaomi', '샤오미', 'Xiaomi'],
  ['roborock', '로보락', 'Roborock'],
  ['dreame', '드리미', 'Dreame'],
  ['ecovacs', '에코백스', 'Ecovacs'],
  ['other', '기타 브랜드', 'Other brand'],
].map(([id, ko, en]) => ({ id, label: label(ko, en) }));

const brandsByRow = {
  fridge: ['samsung', 'lg', 'winia'],
  kimchiFridge: ['samsung', 'lg', 'winia'],
  riceCooker: ['cuckoo', 'cuchen'],
  microwave: ['samsung', 'lg'],
  kettle: ['tefal', 'philips'],
  dishwasher: ['samsung', 'lg', 'sk-magic'],
  range: ['samsung', 'lg', 'cuckoo', 'sk-magic'],
  washer: ['samsung', 'lg'],
  dryer: ['samsung', 'lg'],
  lighting: ['philips', 'osram'],
  tv: ['samsung', 'lg', 'sony'],
  router: ['iptime', 'tp-link', 'asus'],
  laptop: ['samsung', 'lg', 'apple', 'lenovo', 'hp', 'dell', 'asus'],
  ac: ['samsung', 'lg', 'carrier', 'winia'],
  heater: ['shinil', 'hanil'],
  blanket: ['ilwoul', 'navien'],
  waterPurifier: ['samsung', 'lg', 'coway', 'cuckoo', 'sk-magic'],
  airPurifier: ['samsung', 'lg', 'coway', 'winix', 'xiaomi'],
  robotVacuum: ['samsung', 'lg', 'roborock', 'dreame', 'ecovacs', 'xiaomi'],
  dehumidifier: ['samsung', 'lg', 'winix'],
};

const eras = [
  { id: 'unknown', label: label('모름', 'Not sure'), min: null, max: null },
  { id: '2026-on', label: label('2026년 이후', '2026 or later'), min: 2026, max: null },
  { id: '2025', label: label('2025년쯤', 'Around 2025'), min: 2025, max: 2025 },
  { id: '2023-2024', label: label('2023~2024년쯤', 'Around 2023–2024'), min: 2023, max: 2024 },
  { id: '2020-2022', label: label('2020~2022년쯤', 'Around 2020–2022'), min: 2020, max: 2022 },
  { id: 'before-2020', label: label('2020년 이전', 'Before 2020'), min: null, max: 2019 },
];

const styleLabels = {
  1: label('양문형 800L급 · 1등급', 'Side-by-side, about 800 L · Grade 1'),
  2: label('양문형 850L급 · 2등급', 'Side-by-side, about 850 L · Grade 2'),
  3: label('4도어 900L급', 'Four-door, about 900 L'),
  4: label('위아래 문 소형 200L급', 'Compact top-freezer, about 200 L'),
  5: label('서랍 있는 스탠드형', 'Upright with drawers'),
  6: label('위로 여는 뚜껑형', 'Top-opening chest'),
  8: label('앞으로 여는 드럼', 'Front-loading drum'),
  9: label('위로 여는 통돌이', 'Top-loading washer'),
  26: label('벽에 붙은 벽걸이형', 'Wall-mounted unit'),
  27: label('바닥에 세우는 스탠드형', 'Floor-standing unit'),
  28: label('벽걸이와 스탠드 두 대', 'Wall and floor units together'),
  41: label('충전대가 작은 일반형', 'Basic charging dock'),
  601: label('609L 키친핏 · RM80H64S2A', '609 L Kitchen Fit · RM80H64S2A'),
  602: label('일체형 세탁건조기 · WD90H25AHY', 'All-in-one washer-dryer · WD90H25AHY'),
  603: label('33㎡ 인피니트 AI · AP90H03163UGD', '33 m² Infinite AI · AP90H03163UGD'),
  604: label('물걸레 스테이션형 · VR90F01AAG', 'Mop-cleaning station · VR90F01AAG'),
  605: label('카운터탑 정수기 · RWP70F15ANW', 'Countertop purifier · RWP70F15ANW'),
};

const photosByKind = {
  3: 'fridge-four-door',
  4: 'fridge-compact',
  6: 'kimchiFridge-chest',
  9: 'washer-top-load',
  15: 'range-radiant',
  24: 'waterPurifier-ice',
  25: 'waterPurifier-tank',
  27: 'ac-floor',
  28: 'ac-two-units',
  29: 'ac-fixed',
  35: 'blanket-water',
  601: 'fridge-kitchen-fit',
  602: 'washer-combo',
  604: 'robotVacuum-dock',
  'kitchen-fit': 'fridge-kitchen-fit',
  'washer-combo': 'washer-combo',
  'robot-dock': 'robotVacuum-dock',
  'router-only': 'router-only',
};

// These years date published product evidence. They do not date an individual unit.
const householdDates = {
  601: { year: 2026, yearSource: 'https://shinsegaemall.ssg.com/item/itemView.ssg?itemId=1000881529327' },
  602: { year: 2026, yearSource: 'https://www.samsung.com/sec/support/model/WD90H25AHY/' },
  603: { year: 2026, yearSource: 'https://www.samsung.com/sec/air-cleaner/air-purifier-ap90h03163gd-d2c/AP90H03163UGD/' },
  604: { year: 2026, yearSource: 'https://www.samsung.com/sec/support/model/VR90F01AAG/' },
  605: { year: 2025, yearSource: 'https://www.samsung.com/sec/water-purifier/water-purifier-rwp70f15anw-d2c/RWP70F15ANW/' },
};

const householdExamples = new Map(householdAppliances.map((item) => [
  String(item.id),
  {
    ...householdDates[item.id],
    model: item.model,
    brandId: 'samsung',
    source: item.source,
    basis: item.grade === 'A' ? 'official' : 'estimate',
    note: label(item.noteKo, item.noteEn),
  },
]));

export function buildApplianceFinder(catalog) {
  const rows = catalog.rows.map(({ id, group, label: rowLabel, kinds }) => {
    const styles = kinds.map((kind) => ({
      id: kind.id,
      kindId: kind.id,
      label: styleLabels[kind.id] ?? kind.label,
      photoId: kind.photoId ?? photosByKind[kind.id] ?? id,
      example: kind.example ?? householdExamples.get(kind.id) ?? null,
    }));
    const standard = styles.find(({ example }) => example === null);
    if (!standard) throw new Error(`Missing representative appliance style: ${id}`);
    const unknown = {
      ...standard,
      id: 'unknown',
      label: label('종류를 모르겠어요', 'Not sure about the style'),
    };
    const choices = new Set(['unknown', 'other', ...(brandsByRow[id] ?? [])]);
    for (const { example } of styles) {
      if (example) choices.add(example.brandId);
    }
    const brandIds = brands.filter(({ id }) => choices.has(id)).map(({ id }) => id);
    return { id, group, label: rowLabel, brandIds, styles: [...styles, unknown] };
  });
  return { brands, eras, rows };
}

function nearPurchaseEra(year, era) {
  return Number.isInteger(year) &&
    (era.min === null || year >= era.min - 2) &&
    (era.max === null || year <= era.max);
}

export function finderStyles(finder, { rowId, brandId = 'unknown', eraId = 'unknown' }) {
  const row = finder.rows.find(({ id }) => id === rowId);
  const era = finder.eras.find(({ id }) => id === eraId);
  if (!row || !era || !row.brandIds.includes(brandId)) return [];
  const matchesBrand = row.styles.filter(({ example }) => !example ||
    brandId === 'unknown' || brandId === example.brandId);
  if (era.id === 'unknown') return matchesBrand;
  // Purchases can be later than a model's published reference year.
  const hasNearbyExample = matchesBrand.some(({ example }) =>
    example && nearPurchaseEra(example.year, era));
  return matchesBrand.flatMap((style) => {
    if (!style.example) return [style];
    if (!Number.isInteger(style.example.year)) return [{ ...style, timeMatch: null }];
    const timeMatch = nearPurchaseEra(style.example.year, era);
    return timeMatch || !hasNearbyExample ? [{ ...style, timeMatch }] : [];
  });
}

export function resolveFinderSelection(finder, selection) {
  const style = finderStyles(finder, selection).find(({ id }) => id === selection.styleId);
  if (!style) return null;
  return {
    row: finder.rows.find(({ id }) => id === selection.rowId),
    style,
    kindId: style.kindId,
    exact: style.example !== null,
    estimated: style.example?.basis !== 'official',
    example: style.example,
  };
}
