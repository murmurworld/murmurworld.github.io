export const loreHome = '/#murmurworld';

export const firstEpisode = {
  href: '/blog/murmurworld/first-light/',
  title: '유리 쉼터의 작은 돌',
  titleEn: 'The Little Stone in the Glass Shelter',
  cover: '/media/forestlily-shelter.webp',
  shareImage: '/media/forestlily-shelter.jpg',
  video: '/media/forestlily-shelter.mp4',
};
