import { VectorTile } from '@mapbox/vector-tile';
import Pbf from 'pbf';
import { projectLocation, type Inset } from './map-geography';

type XY = { x:number; y:number };
export type TileID = { x:number; y:number; z:number };
export type StreetLabel = XY & { text:string; kind:'place'|'street'|'water'; priority:number; angle:number; span:number };
export type RenderedTile = { group:SVGGElement; labels:StreetLabel[] };
const namespace = 'http://www.w3.org/2000/svg';
export function svgNode<K extends keyof SVGElementTagNameMap>(tag:K) { return document.createElementNS(namespace,tag); }
const worldSize = 4096;
export function tilePosition(longitude:number, latitude:number, z:number) {
  const cap=Math.max(-85.05112,Math.min(85.05112,latitude))*Math.PI/180;
  return {x:(longitude+180)/360*2**z,y:(1-Math.asinh(Math.tan(cap))/Math.PI)/2*2**z};
}

// Resample Web Mercator geometry in the same ellipsoidal Albers coordinate
// frame as the Census outline. A small per-tile mesh also follows curved edges.
function tileFrame(id:TileID, inset:Inset) {
  const grid=8, count=2**id.z;
  function at(x:number,y:number) {
    return projectLocation((id.x+x)/count*360-180, Math.atan(Math.sinh(Math.PI*(1-2*(id.y+y)/count)))*180/Math.PI,inset);
  }
  const origin=at(.5,.5), edge=at(1,.5);
  const unit=Math.hypot(edge.x-origin.x,edge.y-origin.y)*2/worldSize;
  const mesh=Array.from({length:grid+1},(_,j)=>Array.from({length:grid+1},(_,i)=>{
    const p=at(i/grid,j/grid); return {x:(p.x-origin.x)/unit,y:(p.y-origin.y)/unit};
  }));
  function local(x:number,y:number,extent:number):XY {
    const u=x/extent*grid,v=y/extent*grid,i=Math.max(0,Math.min(grid-1,Math.floor(u))),j=Math.max(0,Math.min(grid-1,Math.floor(v)));
    const a=mesh[j][i],b=mesh[j][i+1],c=mesh[j+1][i],d=mesh[j+1][i+1],dx=u-i,dy=v-j;
    return {x:Math.round((a.x+(b.x-a.x)*dx)*(1-dy)+(c.x+(d.x-c.x)*dx)*dy),
      y:Math.round((a.y+(b.y-a.y)*dx)*(1-dy)+(c.y+(d.y-c.y)*dx)*dy)};
  }
  const boundary=[...mesh[0],...mesh.slice(1).map(row=>row[grid]),...mesh[grid].slice(0,-1).reverse(),...mesh.slice(1,-1).reverse().map(row=>row[0])];
  return {origin,unit,local,outline:boundary.map((p,i)=>(i?'L':'M')+p.x.toFixed(1)+' '+p.y.toFixed(1)).join('')+'Z'};
}
const paintOrder=['park','urban','sand','wood','water','river','boundary','building','rail','path','service','local','collector','artery','motorway'];
const highways=new Set(['motorway','trunk']);
const arterial=new Set(['primary','secondary']);
const localRoads=new Set(['minor','residential','unclassified','living_street','road','busway','bus_guideway']);
function roadKind(kind:string,z:number) {
  if(highways.has(kind))return 'motorway';
  if(arterial.has(kind))return 'artery';
  if(kind==='tertiary')return 'collector';
  if(localRoads.has(kind))return 'local';
  if(kind==='service' && z>=13)return 'service';
  if(kind==='path' && z>=14)return 'path';
  if(kind==='rail' || kind==='transit')return 'rail';
}
function featureKind(layer:string, kind:string, z:number, admin:number) {
  if(layer==='transportation')return roadKind(kind,z);
  if(layer==='landcover') {
    if(['wood','grass','farmland','wetland'].includes(kind))return 'wood';
    if(kind==='sand')return 'sand';
  }
  if(layer==='park')return 'park';
  if(layer==='landuse') {
    if(['park','grass','cemetery','recreation_ground','pitch'].includes(kind))return 'park';
    if(['residential','industrial','commercial','retail'].includes(kind))return 'urban';
  }
  if(layer==='boundary')return admin<=4?'boundary':undefined;
  if(layer==='waterway')return 'river';
  if(layer==='water')return 'water';
  if(layer==='building' && z>=13)return 'building';
}
function priority(kind:string, road:boolean, rank:number) {
  if(!road) return ({city:1,town:2,suburb:4,village:5,neighbourhood:7,hamlet:8} as Record<string,number>)[kind] ?? 12+rank;
  return highways.has(kind)?3:arterial.has(kind)?6:kind==='tertiary'?8:10;
}

export function decodeStreetTile(bytes:ArrayBuffer,id:TileID,inset:Inset,en:boolean):RenderedTile {
  const frame=tileFrame(id,inset), groups=new Map<string,string[]>(), labels:StreetLabel[]=[];
  const tile=new VectorTile(new Pbf(new Uint8Array(bytes)));
  for(const [name,layer] of Object.entries(tile.layers)) {
    if(!['park','landuse','landcover','water','waterway','boundary','building','transportation','place','transportation_name','water_name'].includes(name))continue;
    for(let i=0;i<layer.length;i++) {
      const feature=layer.feature(i),props=feature.properties,kind=String(props.class ?? '');
      const labelLayer=name==='place' || name==='transportation_name' || name==='water_name';
      const group=labelLayer?undefined:featureKind(name,kind,id.z,Number(props.admin_level ?? 99));
      if(!labelLayer && !group)continue;
      const road=name==='transportation_name';
      const words=labelLayer?String((!en && props['name:ko']) || props['name:en'] || props.name || (road && props.ref) || ''):'';
      if(labelLayer && (!words || (road && !roadKind(kind,id.z))))continue;
      const parts=feature.loadGeometry();
      if(labelLayer) {
        const points=parts.reduce((longest,next)=>next.length>longest.length?next:longest,parts[0] ?? []);
        if(!points.length)continue;
        const located=points.map(p=>frame.local(p.x,p.y,feature.extent));
        const first=located[0]; let length=0;
        const stops=located.map((p,index)=>{if(index)length+=Math.hypot(p.x-located[index-1].x,p.y-located[index-1].y);return length;});
        // Repeat candidates along a long road so overzoomed neighbourhoods still get names.
        const ticks=road && length>1250?[.2,.5,.8]:[.5];
        for(const fraction of ticks) {
          let p=first,angle=0;
          if(located.length>1 && length) {
            const end=Math.max(1,stops.findIndex(stop=>stop>=length*fraction)),a=located[end-1],b=located[end];
            const t=(length*fraction-stops[end-1])/(stops[end]-stops[end-1] || 1);
            p={x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};
            angle=Math.atan2(b.y-a.y,b.x-a.x)*180/Math.PI;
            if(angle>90)angle-=180; if(angle < -90)angle+=180;
          }
          labels.push({x:frame.origin.x+p.x*frame.unit,y:frame.origin.y+p.y*frame.unit,text:words,
            kind:road?'street':name==='water_name'?'water':'place',priority:priority(kind,road,Number(props.rank ?? 0)),angle:road?angle:0,span:length*frame.unit});
        }
      } else if(group) {
        let commands='';
        for(const part of parts) {
          if(part.length<2)continue;
          let previous:XY|undefined;
          for(const point of part) {
            const p=frame.local(point.x,point.y,feature.extent);
            if(previous && p.x===previous.x && p.y===previous.y)continue;
            commands+=(previous?'L':'M')+p.x+' '+p.y; previous=p;
          }
          if(feature.type===3)commands+='Z';
        }
        if(commands){if(!groups.has(group))groups.set(group,[]);groups.get(group)!.push(commands);}
      }
    }
  }
  const group=svgNode('g'),clip=svgNode('clipPath'),rim=svgNode('path'),base=svgNode('path'),body=svgNode('g');
  const key='street-clip-'+(inset || 'us')+'-'+id.z+'-'+id.x+'-'+id.y+'-'+(en?'en':'ko');
  group.setAttribute('transform','translate('+frame.origin.x+' '+frame.origin.y+') scale('+frame.unit+')');
  group.setAttribute('data-street-tile',[id.z,id.x,id.y].join('/'));
  clip.id=key;rim.setAttribute('d',frame.outline);clip.append(rim);
  base.setAttribute('d',frame.outline);base.setAttribute('data-street-kind','ground');
  body.setAttribute('clip-path','url(#'+key+')');
  group.append(clip,base,body);
  for(const kind of paintOrder) {
    const lines=groups.get(kind);if(!lines?.length)continue;
    const path=svgNode('path');path.setAttribute('d',lines.join(''));path.setAttribute('data-street-kind',kind);
    path.setAttribute('vector-effect','non-scaling-stroke');path.setAttribute('fill-rule','evenodd');
    if(['local','collector','artery','motorway'].includes(kind)) {
      const casing=path.cloneNode(false) as SVGPathElement;casing.setAttribute('data-street-casing','');body.append(casing);
    }
    body.append(path);
  }
  return {group,labels};
}
