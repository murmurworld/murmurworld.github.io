import { projectedFrame, type Inset } from './map-geography';

type Box = { x:number; y:number; w:number; h:number };
type View = { box:Box; inset:Inset; pixels:number };
type ImageView = View & { bounds:Box };
const endpoint = 'https://basemap.nationalmap.gov/arcgis/rest/services/USGSTopo/MapServer/export';
// Hawaii uses the site's local WGS84 Albers inset, which has no EPSG code.
const hawaii = JSON.stringify({wkt:'PROJCS["Hawaii Albers",GEOGCS["GCS_WGS_1984",DATUM["D_WGS_1984",SPHEROID["WGS_1984",6378137,298.257223563]],PRIMEM["Greenwich",0],UNIT["Degree",0.0174532925199433]],PROJECTION["Albers"],PARAMETER["False_Easting",0],PARAMETER["False_Northing",0],PARAMETER["Central_Meridian",-157],PARAMETER["Standard_Parallel_1",8],PARAMETER["Standard_Parallel_2",18],PARAMETER["Latitude_Of_Origin",13],UNIT["Meter",1]]'});
function covers(image:ImageView, view:View) {
  const a=image.bounds,b=view.box, resolution=(image.box.w/image.pixels)/(b.w/view.pixels);
  return image.inset===view.inset && resolution>.82 && resolution<1.22 &&
    a.x<=b.x && a.y<=b.y && a.x+a.w>=b.x+b.w && a.y+a.h>=b.y+b.h;
}

export function mountUsgsLayer(root:HTMLElement, svg:SVGSVGElement, withinUS:(view:Box,inset:Inset)=>boolean) {
  const layer=root.querySelector<SVGImageElement>('[data-usgs-layer]')!;
  const status=root.querySelector<HTMLElement>('[data-usgs-status]')!;
  const retry=root.querySelector<HTMLButtonElement>('[data-usgs-retry]')!;
  const en=root.dataset.lang==='en';
  let current:View|undefined, painted:(ImageView & {url:string})|undefined;
  let pending:(ImageView & {task:AbortController})|undefined, timer:number|undefined;
  let lastKey='',failedUntil=0;
  function message(text:string, failed=false) {
    status.parentElement!.hidden=!text;
    if(status.textContent!==text) status.textContent=text;
    retry.hidden=!failed;
  }
  function clearImage() {
    if(!painted) return;
    layer.removeAttribute('href');svg.removeAttribute('data-usgs-drawn');
    URL.revokeObjectURL(painted.url);painted=undefined;
  }
  function stop() {
    clearTimeout(timer);
    pending?.task.abort();pending=undefined;
  }
  function failure() {
    message(en?'Local terrain is unavailable. You can still explore the base map.':'상세 지형도를 불러오지 못했어요. 기본 지도는 계속 볼 수 있어요.',true);
  }
  async function load(view:View) {
    if(!withinUS(view.box,view.inset)) {
      clearImage();
      message(en?'The base map continues here. Local terrain covers the United States.':'미국 주변 지역은 기본 지도로 볼 수 있어요.');
      return;
    }
    if(Date.now()<failedUntil || !navigator.onLine) { failure();return; }
    const task=new AbortController();
    const {box,inset,pixels}=view;
    // Extra coverage lets a small drag reuse the same image without another request.
    const bounds={x:box.x-box.w*.08,y:box.y-box.h*.08,w:box.w*1.16,h:box.h*1.16};
    const {left,top,scale}=projectedFrame(inset);
    const bbox=[(bounds.x-left)/scale,(top-bounds.y-bounds.h)/scale,(bounds.x+bounds.w-left)/scale,(top-bounds.y)/scale];
    const sr=inset==='HI'?hawaii:inset==='AK'?'3338':'5070';
    const w=Math.round(pixels*1.16),h=Math.round(w*bounds.h/bounds.w);
    const params=new URLSearchParams({bbox:bbox.map(n=>n.toFixed(3)).join(','),bboxSR:sr,imageSR:sr,
      size:w+','+h,format:'jpg',transparent:'false',f:'image'});
    const requested={...view,bounds,task};pending=requested;
    if(!painted)message(en?'Loading USGS terrain…':'미국 지질조사국 지형도를 불러오는 중…');
    const timeout=window.setTimeout(()=>task.abort(),14000);
    let url:string|undefined;
    try {
      const response=await fetch(endpoint+'?'+params,{credentials:'omit',referrerPolicy:'no-referrer',signal:task.signal});
      if(!response.ok || !response.headers.get('Content-Type')?.startsWith('image/'))throw Error('Invalid map response');
      url=URL.createObjectURL(await response.blob());
      const image=new Image();image.src=url;await image.decode();
      if(image.naturalWidth!==w || image.naturalHeight!==h)throw Error('Unexpected map dimensions');
      if(pending!==requested || !current || !covers(requested,current))return;
      clearImage();
      layer.setAttribute('x',String(bounds.x));layer.setAttribute('y',String(bounds.y));
      layer.setAttribute('width',String(bounds.w));layer.setAttribute('height',String(bounds.h));
      layer.setAttribute('href',url);svg.setAttribute('data-usgs-drawn','');
      painted={...requested,url};url=undefined;failedUntil=0;
      message(en?'USGS terrain · Company locations refer to cities.':'미국 지질조사국 지형도 · 기업 위치는 도시 단위로 표시해요.');
    } catch {
      if(pending===requested){failedUntil=Date.now()+30000;clearImage();failure();}
    } finally {
      clearTimeout(timeout);
      if(url)URL.revokeObjectURL(url);
      if(pending===requested)pending=undefined;
    }
  }
  function update(box:Box,inset:Inset,enabled:boolean) {
    if(!enabled){
      if(current){stop();clearImage();current=undefined;lastKey='';message('');}
      return;
    }
    const cssWidth=svg.clientWidth;
    if(!cssWidth)return;
    const pixels=Math.round(Math.max(220,Math.min(cssWidth*Math.min(devicePixelRatio||1,1.5),cssWidth<520?720:1080)));
    const key=[inset,box.x,box.y,box.w,box.h,pixels].join(',');
    if(key===lastKey)return;
    lastKey=key;current={box,inset,pixels};
    if(pending && covers(pending,current))return;
    stop();
    if(painted && covers(painted,current))return;
    if(painted){
      const a=painted.bounds;
      if(painted.inset!==inset || a.x>box.x+box.w || a.y>box.y+box.h || a.x+a.w<box.x || a.y+a.h<box.y || painted.box.w>box.w*3)clearImage();
    }
    const requested=current;
    timer=window.setTimeout(()=>load(requested),350);
  }
  retry.addEventListener('click',()=>{
    if(!current)return;
    failedUntil=0;lastKey='';
    // The accessible retry button disappears on success. Return the reader to the same map position.
    svg.focus({preventScroll:true});
    update(current.box,current.inset,true);
  });
  return update;
}
