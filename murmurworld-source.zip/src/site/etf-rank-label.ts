export type HoldingPosition = [rank: number, symbol: string];

export function fundRankLabel(fund: string, date: string, positions: HoldingPosition[], en: boolean) {
  const rank = en ? positions.map(([n]) => '#' + n).join(', ') : positions.map(([n]) => n).join('·') + '위';
  const detail = positions.map(([n, symbol]) => symbol + (en ? ' #' + n : ' ' + n + '위')).join(', ');
  const title = en ? fund + ' · ' + detail + ' by portfolio weight as of ' + date
    : fund + ' · 보유 비중 순위 ' + detail + ' · ' + date + ' 기준';
  return { rank, title };
}
