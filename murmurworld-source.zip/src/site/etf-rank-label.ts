export type HoldingPosition = [rank: number, symbol: string, weight: number];

export function holdingsHref(guide: string, positions?: HoldingPosition[]) {
  const search = positions?.length ? '?holding=' + encodeURIComponent(positions.map(([,symbol])=>symbol).join(',')) : '';
  return guide + search + '#holdings';
}

export function fundRankLabel(fund: string, date: string, positions: HoldingPosition[], en: boolean) {
  const rank = en ? positions.map(([n]) => '#' + n).join(', ') : positions.map(([n]) => n).join('·') + '위';
  const percent = new Intl.NumberFormat(en ? 'en-US' : 'ko-KR', {maximumFractionDigits:3});
  const detail = positions.map(([n, symbol, weight]) => symbol + (en ? ' #' + n : ' ' + n + '위') + ' (' + percent.format(weight) + '%)').join(', ');
  const title = en ? fund + ' · ' + detail + ' by portfolio weight as of ' + date
    : fund + ' · 보유 비중 순위 ' + detail + ' · ' + date + ' 기준';
  return { rank, title };
}
