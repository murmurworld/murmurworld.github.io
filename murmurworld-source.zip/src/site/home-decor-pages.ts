import type { MarkdownInstance } from 'astro';
import { homeDetailEntries } from './home-decor';
import type { SiteLanguage } from './locales';

const manuscripts = import.meta.glob<MarkdownInstance<Record<string, unknown>>>(
  '../articles/home-decor/*.md',
  { eager: true },
);

export function getHomeDecorPages(lang: SiteLanguage) {
  return homeDetailEntries.map(({ slug, title, titleEn, description, descriptionEn, cover, publishedOn }) => {
    const { Content } = manuscripts[`../articles/home-decor/${slug}.${lang}.md`];
    return {
      params: { guide: slug },
      props: {
        Content,
        title: lang === 'en' ? titleEn : title,
        englishTitle: lang === 'ko' ? titleEn : undefined,
        description: lang === 'en' ? descriptionEn : description,
        socialImage: 'src' in cover ? { ...cover, alt: lang === 'en' ? cover.altEn : cover.alt } : undefined,
        publishedOn,
        lang,
      },
    };
  });
}
