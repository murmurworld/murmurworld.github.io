import type { MarkdownInstance } from 'astro';
import { homeDetailEntries } from './home-decor';
import type { SiteLanguage } from './locales';

const manuscripts = import.meta.glob<MarkdownInstance<Record<string, unknown>>>(
  '../articles/home-decor/*.md',
  { eager: true },
);

export function getHomeDecorPages(lang: SiteLanguage) {
  return homeDetailEntries.map(entry => {
    const { slug, title, titleEn, description, descriptionEn, publishedOn } = entry;
    const photo = 'socialImage' in entry ? entry.socialImage : entry.cover;
    const { Content } = manuscripts[`../articles/home-decor/${slug}.${lang}.md`];
    return {
      params: { guide: slug },
      props: {
        Content,
        title: lang === 'en' ? titleEn : title,
        englishTitle: lang === 'ko' ? titleEn : undefined,
        description: lang === 'en' ? descriptionEn : description,
        socialImage: { ...photo, alt: lang === 'en' ? photo.altEn : photo.alt },
        publishedOn,
        lang,
      },
    };
  });
}
