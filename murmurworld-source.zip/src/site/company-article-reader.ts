type Reading = { ticker:string; name:string; url:string; home:string; sites:string[]; row:HTMLAnchorElement };

// Use the deployed manuscript so the reading view and its permanent URL always agree.
// Include the article's own illustrations and sources while omitting page navigation.
function articleBody(source:Document, articleUrl:string):DocumentFragment {
  const copy=source.querySelector<HTMLElement>('.market-article > .market-copy');
  if(!copy) throw Error('Company article body missing');
  const fragment=document.createDocumentFragment();
  fragment.append(document.importNode(copy,true));
  const clip=source.querySelector<HTMLElement>('.market-article > [data-industry-video]');
  if(clip) fragment.append(document.importNode(clip,true));
  for(const element of fragment.querySelectorAll('script,style,link,template,iframe,object,embed,form,[data-tabs],[data-video-open],.back')) element.remove();
  // Nested native disclosures preserve every product diagram without importing the
  // standalone page's tab controller or creating additional keyboard tab stops.
  for(const panel of fragment.querySelectorAll<HTMLElement>('[data-product-detail]')){
    const heading=panel.querySelector('h3');
    if(!heading) continue;
    const disclosure=document.createElement('details'), summary=document.createElement('summary');
    disclosure.className='inline-product'; summary.textContent=heading.textContent; heading.remove();
    panel.replaceWith(disclosure); disclosure.append(summary,panel);
  }
  const idMap=new Map<string,string>();
  for(const el of fragment.querySelectorAll<HTMLElement>('[id]')){
    const original=el.id; el.id='reader-'+original; idMap.set(original,el.id);
  }
  for(const el of fragment.querySelectorAll('[aria-labelledby],[aria-describedby],[aria-controls],[headers]')){
    for(const key of ['aria-labelledby','aria-describedby','aria-controls','headers']){
      const ids=el.getAttribute(key);
      if(ids) el.setAttribute(key,ids.split(/\s+/).map(id=>idMap.get(id)||id).join(' '));
    }
  }
  for(const link of fragment.querySelectorAll<HTMLAnchorElement>('a[href]')){
    const raw=link.getAttribute('href')!;
    const local=raw.startsWith('#') && idMap.get(raw.slice(1));
    link.href=local?'#'+local:new URL(raw,articleUrl).href;
  }
  // Astro scopes the diagrams and the memory-package cross section to their own
  // component. Reuse only locally built stylesheet assets for the manuscript.
  for(const link of source.querySelectorAll<HTMLLinkElement>('head link[rel="stylesheet"][href]')){
    const asset=new URL(link.getAttribute('href')!,articleUrl);
    if(asset.origin!==location.origin || !asset.pathname.startsWith('/_astro/')) continue;
    if([...document.querySelectorAll<HTMLLinkElement>('link[rel="stylesheet"]')].some(el=>el.href===asset.href)) continue;
    const css=document.createElement('link'); css.rel='stylesheet'; css.href=asset.href; document.head.append(css);
  }
  return fragment;
}

export function mountCompanyArticleReader(reader:HTMLElement){
  const hub=reader.closest<HTMLElement>('[data-stock-hub]');
  const map=hub?.querySelector<HTMLElement>('[data-market-us-map]');
  if(!hub || !map) return;
  const atlas=hub.querySelector<HTMLElement>('#us-map')!;
  const shelf=hub.querySelector<HTMLElement>('.company-shelf');
  const rows=new Map([...hub.querySelectorAll<HTMLAnchorElement>('a[data-directory-company]')].map(row=>[row.dataset.directoryCompany!,row]));
  const records=new Map<string,Reading>();
  for(const button of map.querySelectorAll<HTMLElement>('[data-company-option]')){
    const ticker=button.dataset.companyOption!, row=rows.get(ticker);
    if(row) records.set(ticker,{ticker,row,url:row.href,name:button.dataset.name!,home:button.dataset.home!,sites:button.dataset.sites!.split(' ')});
  }
  const entryByUrl=new Map([...records.values()].map(c=>[new URL(c.url).pathname,c]));
  const details=reader.querySelector('details')!;
  const wide=window.matchMedia('(min-width:1600px)');
  const title=reader.querySelector<HTMLElement>('[data-reader-title]')!;
  const summary=reader.querySelector<HTMLElement>('summary')!;
  const body=reader.querySelector<HTMLElement>('[data-reader-body]')!;
  const status=reader.querySelector<HTMLElement>('[data-reader-status]')!;
  const retry=reader.querySelector<HTMLButtonElement>('[data-reader-retry]')!;
  const permanent=reader.querySelector<HTMLAnchorElement>('[data-reader-permalink]')!;
  const en=document.documentElement.lang==='en';
  let current:Reading|undefined, pending:AbortController|undefined, loaded='', navigatingBack=false;
  let requestedSection='';
  function sectionId(hash:string,prefix:string){
    if(!hash.startsWith(prefix))return '';
    try{return decodeURIComponent(hash.slice(prefix.length))}catch{return '';}
  }
  function showRequestedSection(){
    if(!requestedSection||loaded!==current?.ticker)return;
    const section=body.querySelector<HTMLElement>('#'+CSS.escape('reader-'+requestedSection));
    requestedSection='';
    if(!section)return;
    for(let fold=section.closest('details');fold&&reader.contains(fold);fold=fold.parentElement?.closest('details')??null)fold.open=true;
    const guide=section.matches('[data-guide-product]')&&section.querySelector('details');
    if(guide)guide.open=true;
    const heading=section.closest('.inline-product')?.querySelector<HTMLElement>('summary')||section;
    if(heading.tagName!=='SUMMARY')heading.tabIndex=-1;
    heading.focus({preventScroll:true});heading.scrollIntoView({block:'start',behavior:'instant'});
  }
  let readingAnchor:{element:HTMLElement; offset:number}|undefined;
  function holdSection(){
    if(!readingAnchor) return;
    const gap=readingAnchor.element.getBoundingClientRect().top-readingAnchor.offset;
    if(Math.abs(gap)<=1)return;
    let parent=readingAnchor.element.parentElement;
    while(parent && parent!==document.body){
      if(/^(auto|scroll)$/.test(getComputedStyle(parent).overflowY) && parent.scrollHeight>parent.clientHeight)break;
      parent=parent.parentElement;
    }
    (parent && parent!==document.body ? parent : window).scrollBy({top:gap,behavior:'instant'});
  }
  for(const event of ['pointerdown','wheel','touchstart','keydown']) {
    window.addEventListener(event,()=>{readingAnchor=undefined;},{passive:true,capture:true});
  }

  async function load(){
    const company=current;
    if(!company || !details.open || pending || loaded===company.ticker) return;
    const request=new AbortController(); pending=request;
    status.textContent=en?'Loading the article…':'글을 불러오고 있어요.';
    retry.hidden=true;
    body.setAttribute('aria-busy','true');
    try{
      const response=await fetch(company.url,{signal:request.signal,credentials:'same-origin'});
      if(!response.ok || new URL(response.url).origin!==location.origin) throw Error('Could not load company article');
      const html=await response.text();
      if(pending!==request || current!==company) return;
      body.replaceChildren(articleBody(new DOMParser().parseFromString(html,'text/html'),company.url));
      loaded=company.ticker; body.dataset.article=loaded; status.textContent='';
      holdSection();
      showRequestedSection();
    }catch{
      if(request.signal.aborted || pending!==request) return;
      status.textContent=en?'The article could not be loaded. Try again or open its permanent link.':'글을 불러오지 못했어요. 다시 시도하거나 아래 개별 글 주소를 열어 보세요.';
      retry.hidden=false;
    }finally{
      if(pending===request){pending=undefined; body.removeAttribute('aria-busy');}
    }
  }
  function select(ticker:string){
    const company=records.get(ticker);
    if(company===current) return;
    readingAnchor=undefined;
    current?.row.removeAttribute('aria-current');
    pending?.abort(); pending=undefined; loaded=''; body.removeAttribute('aria-busy');
    current=company; body.replaceChildren(); delete body.dataset.article;
    requestedSection=company?sectionId(location.hash,'#reader-'):'';
    retry.hidden=true; status.textContent=''; reader.hidden=!company;
    if(!company){details.open=false; delete reader.dataset.ticker; return;}
    reader.dataset.ticker=company.ticker;
    company.row.setAttribute('aria-current','true');
    permanent.href=company.url; title.textContent=company.name;
    if(navigatingBack) details.open=history.state?.openCompanyArticle===ticker;
    if(wide.matches||requestedSection||location.hash==='#company-article')details.open=true;
    if(details.open) void load();
  }
  wide.addEventListener('change',()=>{if(wide.matches&&current){details.open=true;void load();}});
  details.addEventListener('toggle',()=>{
    if(!current) return;
    if(details.open) void load();
    history.replaceState({...history.state,openCompanyArticle:details.open?current.ticker:null},'');
  });
  retry.addEventListener('click',()=>void load());
  map.addEventListener('market-location-view',event=>select((event as CustomEvent<{company:string}>).detail.company));

  function leaveDirectory(record:Reading, origin:HTMLAnchorElement){
    const oldUrl=location.href, fromDirectory=origin===record.row;
    const frame=map!.querySelector('[data-geo-surface]')!.getBoundingClientRect();
    const visibleHeight=Math.min(frame.bottom,innerHeight)-Math.max(frame.top,0);
    const seeMap=visibleHeight>=Math.min(frame.height*.5,160);
    // A pinned directory stays alongside the article, relationships and news.
    // Keep readers in whichever part they were using when they picked their next company.
    const sticky=fromDirectory && shelf && getComputedStyle(shelf).position==='sticky';
    const anchor=sticky && !seeMap ? [...hub!.querySelectorAll<HTMLElement>(
      '[data-location-profile]:not([hidden]),#company-article:not([hidden]),#relationships,#business-study,#market-news'
    )].map(element=>({element,box:element.getBoundingClientRect()}))
       .filter(({box})=>box.bottom>Math.min(160,innerHeight*.25) && box.top<innerHeight*.6)
       .sort((a,b)=>Math.abs(Math.max(a.box.top,0))-Math.abs(Math.max(b.box.top,0)))[0] : undefined;
    if(fromDirectory) history.replaceState({...history.state,companyDirectoryReturn:{
      href:oldUrl,ticker:record.ticker,offset:origin.getBoundingClientRect().top,shelfTop:shelf?.scrollTop||0,
      open:details.open?current?.ticker:null,context:anchor?{id:anchor.element.id || 'profile',offset:anchor.box.top}:null
    }},'');
    const region=map!.dataset.locationState!;
    map!.dispatchEvent(new CustomEvent('location-map:select',{detail:{
      state:record.sites.includes(region)?region:record.home,company:record.ticker
    }}));
    if(fromDirectory && location.href===oldUrl) history.pushState({...history.state},'',oldUrl);
    const next={...history.state,openCompanyArticle:record.ticker};
    delete next.companyDirectoryReturn;
    history.replaceState(next,'');
    select(record.ticker); details.open=true; void load();
    if(fromDirectory){
      if(anchor){
        readingAnchor={element:anchor.element,offset:Math.max(12,anchor.box.top)};
        holdSection();
      }else if(!seeMap){
        const heading=atlas.querySelector<HTMLElement>('#atlas-title')!;
        heading.tabIndex=-1; heading.focus({preventScroll:true});
        atlas.scrollIntoView({block:'start',behavior:'instant'});
      }
      const scene=history.state?.marketMap;
      if(scene?.href===location.href) history.replaceState({...history.state,marketMap:{...scene,scroll:{top:scrollY,left:scrollX}}},'');
    } else {
      summary.focus({preventScroll:true}); reader.scrollIntoView({block:'start',behavior:'instant'});
    }
  }
  hub.addEventListener('click',event=>{
    if(event.defaultPrevented || event.button!==0 || event.ctrlKey || event.metaKey || event.altKey || event.shiftKey || !map.hasAttribute('data-interactive')) return;
    const link=(event.target as Element).closest<HTMLAnchorElement>('a[href]');
    if(!link || link.target || link.hasAttribute('download') || link===permanent) return;
    const article=link.origin===location.origin?entryByUrl.get(link.pathname):undefined;
    const section=sectionId(link.hash,'#');
    if(article&&section&&(link.dataset.readProduct||link.dataset.readCompany||body.contains(link))){
      event.preventDefault();
      const hash='#reader-'+encodeURIComponent(section);
      if(article!==current||location.hash!==hash){
        history.replaceState({...history.state,returnToArticleLink:link.href},'');
        const same=article===current;
        if(!same)leaveDirectory(article,link);
        const next={...history.state,openCompanyArticle:article.ticker};
        delete next.returnToArticleLink;
        delete next.companyDirectoryReturn;
        if(same)history.pushState(next,'',hash);
        else history.replaceState(next,'',hash);
      }
      requestedSection=section;
      hub.dispatchEvent(new Event('market-reader-change',{bubbles:true}));
      details.open=true;
      if(loaded===article.ticker)showRequestedSection();
      else {summary.focus({preventScroll:true});reader.scrollIntoView({block:'start',behavior:'instant'});void load();}
      return;
    }
    const directory=link.dataset.directoryCompany, guide=link.dataset.readCompany;
    const target=directory||guide?records.get(directory||guide!):
      body.contains(link) && link.origin===location.origin && !link.hash ? entryByUrl.get(link.pathname) : undefined;
    if(!target) return;
    event.preventDefault();
    if(guide && target===current){
      details.open=true; void load(); summary.focus({preventScroll:true});
      reader.scrollIntoView({block:'start',behavior:'instant'});
      return;
    }
    leaveDirectory(target,link);
  });
  // Browser history may restore native scroll while the company panel above the
  // directory changes height. Restore the triggering row's offset after the layout.
  window.addEventListener('popstate',()=>{
    navigatingBack=true;
    const returning=history.state?.companyDirectoryReturn;
    select(map.dataset.locationCompany || '');
    requestedSection=sectionId(location.hash,'#reader-');
    details.open=Boolean(current && (wide.matches||requestedSection||(returning?.open || history.state?.openCompanyArticle)===current.ticker));
    navigatingBack=false;
    if(requestedSection&&current){showRequestedSection();void load();return;}
    const origin=history.state?.returnToArticleLink;
    if(origin){
      requestAnimationFrame(()=>{
        const link=[...hub.querySelectorAll<HTMLAnchorElement>('a[data-read-product],a[data-read-company],[data-reader-body] a')].find(a=>a.href===origin&&a.getClientRects().length);
        if(link){link.focus({preventScroll:true});link.scrollIntoView({block:'nearest',behavior:'instant'});}
      });
      return;
    }
    const row=returning?.href===location.href && rows.get(returning.ticker);
    if(!row) return;
    const href=location.href;
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(location.href!==href) return;
      if(shelf) shelf.scrollTop=returning.shelfTop;
      row.focus({preventScroll:true});
      const target=returning.context?.id==='profile'?map.querySelector<HTMLElement>('[data-location-profile]'):
        returning.context && document.getElementById(returning.context.id);
      if(target){
        readingAnchor={element:target,offset:returning.context.offset};
        holdSection();
      } else window.scrollBy({top:row.getBoundingClientRect().top-returning.offset,behavior:'instant'});
    }));
  });
  select(map.dataset.locationCompany || '');
}
