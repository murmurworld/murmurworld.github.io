// Manufacturer-listed monthly energy for an exact model, separate from type estimates.
// Years are public release years. A missing year means the source does not specify it.
const lg = (model, product = 'refrigerators') => `https://www.lge.co.kr/product/${product}/${model.toLowerCase()}`;
const samsung = (model) => `https://www.samsung.com/sec/support/model/${model}/`;

export const refrigerationModels = {
  fridge: [
    { model: 'S834MWW12', brandId: 'lg', year: 2023, kwh: 52.3, photoId: 'fridge', source: lg('S834MWW12'), ko: 'LG 양문형 832L (2023)', en: 'LG side-by-side 832 L (2023)' },
    { model: 'S834MQQ111', brandId: 'lg', year: 2024, kwh: 40.2, photoId: 'fridge', source: lg('S834MQQ111'), ko: 'LG 오브제 양문형 832L (2024)', en: 'LG Objet side-by-side 832 L (2024)' },
    { model: 'M616MQQ0M1', brandId: 'lg', year: 2025, kwh: 29.5, photoId: 'fridge-kitchen-fit', source: lg('M616MQQ0M1'), ko: 'LG Fit & Max 609L (2025)', en: 'LG Fit & Max 609 L (2025)' },
    { model: 'S836GBB142', brandId: 'lg', year: 2025, kwh: 51.5, photoId: 'fridge', source: lg('S836GBB142'), ko: 'LG 양문형 832L (2025)', en: 'LG side-by-side 832 L (2025)' },
    { model: 'B182W13', brandId: 'lg', year: 2021, kwh: 29.8, photoId: 'fridge-compact', source: lg('B182W13'), ko: 'LG 소형 189L (2021)', en: 'LG compact 189 L (2021)' },
    { model: 'RS84DB5002CW', brandId: 'samsung', year: null, kwh: 51.5, photoId: 'fridge', source: samsung('RS84DB5002CW'), ko: '삼성 양문형 852L', en: 'Samsung side-by-side 852 L' },
    { model: 'RM70F90M1ZD', brandId: 'samsung', year: null, kwh: 44.4, photoId: 'fridge-four-door', source: samsung('RM70F90M1ZD'), ko: '삼성 4도어 902L', en: 'Samsung four-door 902 L' },
  ],
  kimchiFridge: [
    { model: 'K227S121', brandId: 'lg', year: 2022, kwh: 9.4, photoId: 'kimchiFridge-chest', source: lg('K227S121', 'kimchi-refrigerators'), ko: 'LG 김치톡톡 뚜껑형 219L (2022)', en: 'LG KimchiTalkTalk chest 219 L (2022)' },
    { model: 'K225S121', brandId: 'lg', year: 2025, kwh: 9.9, photoId: 'kimchiFridge-chest', source: lg('K225S121', 'kimchi-refrigerators'), ko: 'LG 김치톡톡 뚜껑형 219L (2025)', en: 'LG KimchiTalkTalk chest 219 L (2025)' },
    { model: 'RQ33DB7411EW', brandId: 'samsung', year: null, kwh: 11.5, photoId: 'kimchiFridge', source: samsung('RQ33DB7411EW'), ko: '삼성 키친핏 3도어 313L', en: 'Samsung Kitchen Fit 3-door 313 L' },
    { model: 'RQ33C71G3S9', brandId: 'samsung', year: null, kwh: 14.4, photoId: 'kimchiFridge', source: samsung('RQ33C71G3S9'), ko: '삼성 김치플러스 스탠드 328L', en: 'Samsung Kimchi Plus upright 328 L' },
    { model: 'RP22C3111Z3', brandId: 'samsung', year: null, kwh: 10.1, photoId: 'kimchiFridge-chest', source: samsung('RP22C3111Z3'), ko: '삼성 김치플러스 뚜껑형 221L', en: 'Samsung Kimchi Plus chest 221 L' },
  ],
};
