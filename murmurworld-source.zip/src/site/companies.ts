export const companiesTopic = {
  id: 'companies',
  href: '/blog/companies/',
  title: '주식 · 기업과 공시',
  titleEn: 'Stocks, Companies & Filings',
  description: '회사가 무엇을 팔고 어디에서 돈을 버는지, 경쟁 제품과 공시를 함께 읽어 봅니다.',
  descriptionEn: 'What companies sell, how they make money, and what their competitors and filings can tell us.',
};

export const companySectors = [
  { id: 'semiconductors', title: '반도체·장비', titleEn: 'Semiconductors & Equipment' },
  { id: 'technology', title: '빅테크·소프트웨어·IT', titleEn: 'Big Tech, Software & IT' },
  { id: 'financials', title: '금융·은행·우선주', titleEn: 'Financials, Banks & Preferred Shares' },
  { id: 'consumer-telecom', title: '소비·통신', titleEn: 'Consumer & Telecom' },
  { id: 'healthcare', title: '헬스케어', titleEn: 'Healthcare' },
  { id: 'industry-energy-materials', title: '산업·에너지·소재', titleEn: 'Industrials, Energy & Materials' },
  { id: 'funds-bonds-commodities', title: 'ETF·채권·원자재', titleEn: 'ETFs, Bonds & Commodities' },
] as const;

export type CompanySectorId = typeof companySectors[number]['id'];
