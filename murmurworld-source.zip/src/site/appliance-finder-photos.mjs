const sheets = {
  'cooling-refrigeration': [
    'fridge', 'fridge-four-door', 'fridge-kitchen-fit',
    'fridge-compact', 'kimchiFridge', 'kimchiFridge-chest',
    'ac', 'ac-floor', 'ac-fixed',
  ],
  kitchen: [
    'riceCooker', 'microwave', 'kettle',
    'dishwasher', 'range', 'range-radiant',
    'waterPurifier', 'waterPurifier-ice', 'waterPurifier-tank',
  ],
  'laundry-living': [
    'washer', 'washer-top-load', 'washer-combo',
    'dryer', 'lighting', 'tv',
    'router', 'laptop', 'other',
  ],
  'comfort-care': [
    'heater', 'blanket', 'blanket-water',
    'airPurifier', 'robotVacuum', 'robotVacuum-dock',
    'dehumidifier', 'ac-two-units', 'router-only',
  ],
};

const photos = new Map(Object.entries(sheets).flatMap(([sheet, ids]) => ids.map((id, index) => [id, {
  src: `/media/appliance-finder/${sheet}.png`,
  x: (index % 3) * 50,
  y: Math.floor(index / 3) * 50,
  generated: true,
}])));

const newsroomPhotos = {
  'waterPurifier-605': 'samsung-water-purifier-countertop.jpg',
  'airPurifier-603': 'samsung-air-purifier-infinite-2024.jpg',
  'robotVacuum-604': 'samsung-robot-steam-kitchen-2026.jpg',
};

for (const [id, file] of Object.entries(newsroomPhotos)) {
  photos.set(id, { src: `/media/newsroom/${file}`, generated: false });
}

export function finderPhoto(photoId) {
  return photos.get(photoId);
}
