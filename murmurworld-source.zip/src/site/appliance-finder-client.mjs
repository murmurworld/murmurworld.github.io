import { finderStyles, resolveFinderSelection } from './appliance-finder-data.mjs';
import { finderPhoto } from './appliance-finder-photos.mjs';
import { estimateUsage } from './monthly-electricity.mjs';

const questions = ['brand', 'era', 'style', 'review'];

const labels = {
  ko: {
    none: '이 가전은 없어요', apply: '계산기에 반영', remove: '계산기에서 빼기',
    generatedPhoto: '형태를 보여주는 생성 이미지', manufacturerPhoto: '제조사 사진',
    source: '제품·사용량 출처', generic: '비슷한 종류의 표준값이 기본이에요.',
    known: '기본값은 이 모델의 공개 소비전력 자료를 따라요.', estimated: '이 모델의 기본값은 예시 사용량이에요.',
    otherYear: (year) => `이 모델의 확인 자료는 ${year}년이에요.`,
    preview: (name, value) => `${name} · 예상 ${value} kWh/달`,
    current: (name, value) => `현재 계산기에는 ${name}으로 ${value} kWh/달이 들어 있어요.`,
    preserved: '같은 종류에 이미 입력한 값을 사용해요.',
    confirmed: (name, removed) => `${name}${removed ? ' 항목을 계산기에서 뺐어요.' : ' 항목을 계산기에 반영했어요.'}`,
    blocked: {
      bill: '고지서 사용량을 비우면 가전 선택을 계산기에 넣을 수 있어요.',
      area: '집 크기를 입력하면 가전 선택을 계산기에 넣을 수 있어요.',
      dryer: '지금은 세탁건조기에 건조기 사용량이 포함돼 있어요.',
    },
  },
  en: {
    none: 'I don’t have this appliance', apply: 'Use in calculator', remove: 'Remove from calculator',
    generatedPhoto: 'Generated example of the shape', manufacturerPhoto: 'Manufacturer photo',
    source: 'Model and energy source', generic: 'The starting values are for a similar appliance type.',
    known: 'The starting values follow the published energy figures for this model.', estimated: 'The starting values are an example usage estimate for this model.',
    otherYear: (year) => `The documented reference for this model is from ${year}.`,
    preview: (name, value) => `${name} · about ${value} kWh/mo`,
    current: (name, value) => `The calculator currently has ${name} at ${value} kWh/mo.`,
    preserved: 'Uses the values already entered for this type.',
    confirmed: (name, removed) => removed ? `${name} removed from the calculator.` : `${name} applied to the calculator.`,
    blocked: {
      bill: 'Clear billed usage to include your appliance choice in the estimate.',
      area: 'Enter your home size to include your appliance choice in the estimate.',
      dryer: 'Drying is currently included in the washer-dryer usage.',
    },
  },
};

function photoFrame(photo) {
  const frame = document.createElement('span');
  frame.className = 'finder-photo-frame';
  frame.setAttribute('aria-hidden', 'true');
  if (photo.x !== undefined && photo.y !== undefined) {
    const tile = document.createElement('span');
    tile.className = 'finder-photo finder-photo-sprite';
    tile.style.backgroundImage = `url('${photo.src}')`;
    tile.style.backgroundPosition = `${photo.x}% ${photo.y}%`;
    frame.append(tile);
  } else {
    const image = new Image();
    image.className = 'finder-photo';
    image.src = photo.src;
    image.alt = '';
    image.loading = 'lazy';
    image.decoding = 'async';
    frame.append(image);
  }
  return frame;
}

function choiceButton(id, name) {
  const button = document.createElement('button');
  button.type = 'button';
  button.dataset.finderStyle = id;
  button.textContent = name;
  return button;
}

function styleButton(style, lang, copy) {
  const button = choiceButton(style.id, style.label[lang]);
  button.className = 'finder-style';
  button.textContent = '';
  const photo = finderPhoto(style.photoId);
  if (photo) button.append(photoFrame(photo));
  const name = document.createElement('span');
  name.className = 'finder-name';
  name.textContent = style.label[lang];
  button.append(name);
  const creditText = [];
  if (photo) creditText.push(photo.generated ? copy.generatedPhoto : copy.manufacturerPhoto);
  if (style.timeMatch === false && Number.isInteger(style.example?.year)) creditText.push(copy.otherYear(style.example.year));
  if (creditText.length) {
    const credit = document.createElement('small');
    credit.className = 'finder-photo-credit';
    credit.textContent = creditText.join(' · ');
    button.append(credit);
  }
  return button;
}

export function mountApplianceFinder(root) {
  const get = (part, scope = root) => scope.querySelector(`[data-finder-${part}]`);
  const { lang, catalog, finder } = JSON.parse(get('config').textContent);
  const copy = labels[lang];
  const dialog = get('guide');
  const options = new Map(finder.rows.map((row) => [row.id, row]));
  const definitions = new Map(catalog.rows.map((row) => [row.id, row]));
  const tabs = [...root.querySelectorAll('[data-finder-tab]')];
  const panels = [...root.querySelectorAll('[data-finder-panel]')];
  const steps = [...dialog.querySelectorAll('[data-finder-step]')];
  const apply = get('apply');
  const resultLink = get('result-link');
  const status = get('status');
  const formatter = new Intl.NumberFormat(lang === 'en' ? 'en-US' : 'ko-KR', { maximumFractionDigits: 1, minimumFractionDigits: 1 });
  let tab = 0;
  let step = 'brand';
  let trigger = null;
  let selection = null;
  let snapshot = { rows: {} };

  function activateTab(index) {
    tab = index;
    tabs.forEach((button, buttonIndex) => {
      const active = buttonIndex === tab;
      button.tabIndex = active ? 0 : -1;
      button.setAttribute('aria-selected', String(active));
      panels[buttonIndex].hidden = !active;
    });
  }

  function showStep(name) {
    step = name;
    const pane = steps[questions.indexOf(name)];
    for (const stepPane of steps) stepPane.hidden = stepPane !== pane;
    get('footer').hidden = name === 'brand';
    dialog.scrollTop = 0;
    get('question', pane).focus({ preventScroll: true });
  }

  function showStyles() {
    const styles = finderStyles(finder, selection);
    const generic = styles.filter((style) => !style.example && style.id !== 'unknown');
    const exact = styles.filter((style) => style.example);
    const unknown = styles.find(({ id }) => id === 'unknown');
    get('generic').replaceChildren(...generic.map((style) => styleButton(style, lang, copy)));
    get('exact').replaceChildren(...exact.map((style) => styleButton(style, lang, copy)));
    get('model-group').hidden = exact.length === 0;
    const rest = [choiceButton('none', copy.none)];
    if (unknown) rest.unshift(choiceButton(unknown.id, unknown.label[lang]));
    get('other').replaceChildren(...rest);
    showStep('style');
  }

  function chosenKind() {
    if (selection.styleId === 'none') return { kindId: null, row: options.get(selection.rowId) };
    return resolveFinderSelection(finder, selection);
  }

  function blockedReason(chosen) {
    if (snapshot.paused) return snapshot.blocked === 'area' ? 'area' : 'bill';
    if (snapshot.rows[selection.rowId]?.locked && chosen.kindId) return 'dryer';
    return '';
  }

  function reviewChoice() {
    const chosen = chosenKind();
    if (!chosen) return;
    const current = snapshot.rows[selection.rowId];
    const definition = definitions.get(selection.rowId);
    const kind = definition.kinds.find(({ id }) => id === chosen.kindId);
    const currentKind = definition.kinds.find(({ id }) => id === current?.kindId);
    const note = get('match');
    const source = get('source');
    const existing = get('current');
    apply.textContent = kind ? copy.apply : copy.remove;
    existing.hidden = !current?.enabled || !currentKind || !Number.isFinite(current.kwh);
    if (!existing.hidden) existing.textContent = copy.current(currentKind.label[lang], formatter.format(current.kwh));
    const sameKind = kind && current?.kindId === kind.id && Number.isFinite(current.kwh);
    if (kind) {
      const usage = sameKind ? current.kwh : estimateUsage({
        [definition.id]: { kindId: kind.id, enabled: true, power: kind.power, usage: kind.usage },
      }, catalog).kwh;
      get('preview').textContent = copy.preview(kind.label[lang], formatter.format(usage));
      const evidence = chosen.estimated ? copy.estimated : copy.known;
      const basis = chosen.exact ? evidence : copy.generic;
      note.textContent = sameKind ? `${basis} ${copy.preserved}` : basis;
    } else {
      get('preview').textContent = copy.none;
    }
    note.hidden = !kind;
    source.hidden = !chosen.example?.source;
    if (!source.hidden) {
      source.href = chosen.example.source;
      source.textContent = copy.source;
      source.target = '_blank';
      source.rel = 'noopener';
    }
    const blocked = blockedReason(chosen);
    apply.disabled = Boolean(blocked);
    if (blocked) status.textContent = copy.blocked[blocked];
  }

  root.addEventListener('click', (event) => {
    const category = event.target.closest('[data-finder-tab]');
    if (category) return activateTab(tabs.indexOf(category));
    const device = event.target.closest('[data-finder-device]');
    if (!device || dialog.open) return;
    trigger = device;
    selection = { rowId: device.dataset.finderDevice, brandId: 'unknown', eraId: 'unknown', styleId: '' };
    const chosen = options.get(selection.rowId);
    get('device-title').textContent = chosen.label[lang];
    dialog.querySelectorAll('[data-finder-brand]').forEach((brand) => {
      brand.hidden = !(chosen.brandIds?.includes(brand.dataset.finderBrand) ?? true);
    });
    status.textContent = '';
    resultLink.hidden = true;
    dialog.showModal();
    showStep('brand');
  });

  root.addEventListener('keydown', (event) => {
    if (!event.target.matches('[data-finder-tab]')) return;
    const direction = { ArrowRight: (tab + 1) % tabs.length, ArrowLeft: (tab + tabs.length - 1) % tabs.length, Home: 0, End: tabs.length - 1 };
    const index = direction[event.key];
    if (index === undefined) return;
    event.preventDefault();
    activateTab(index);
    tabs[index].focus();
  });

  dialog.addEventListener('click', (event) => {
    const button = event.target.closest('button');
    if (!button) return;
    if (button.hasAttribute('data-finder-close')) return dialog.close();
    if (button.hasAttribute('data-finder-back')) return showStep(questions[questions.indexOf(step) - 1]);
    if (button.hasAttribute('data-finder-brand')) {
      selection.brandId = button.dataset.finderBrand;
      showStep('era');
    } else if (button.hasAttribute('data-finder-era')) {
      selection.eraId = button.dataset.finderEra;
      showStyles();
    } else if (button.hasAttribute('data-finder-style')) {
      selection.styleId = button.dataset.finderStyle;
      status.textContent = '';
      resultLink.hidden = true;
      reviewChoice();
      showStep('review');
    } else if (button === apply) {
      const chosen = chosenKind();
      if (!chosen || blockedReason(chosen)) return;
      document.dispatchEvent(new CustomEvent('murmurworld:appliance-finder-select', { detail: { id: selection.rowId, kindId: chosen.kindId } }));
    }
  });
  dialog.addEventListener('close', () => trigger?.focus({ preventScroll: true }));
  resultLink.addEventListener('click', () => dialog.close());

  document.addEventListener('murmurworld:appliance-selection-change', ({ detail }) => {
    if (!detail?.rows) return;
    snapshot = detail;
    if (step !== 'review' || !dialog.open) return;
    reviewChoice();
    if (detail.blocked) {
      status.textContent = copy.blocked[detail.blocked] ?? '';
      return;
    }
    if (detail.applied?.id === selection.rowId) {
      const { kindId } = detail.applied;
      status.textContent = copy.confirmed(options.get(selection.rowId).label[lang], kindId === null);
      resultLink.hidden = false;
    }
  });
  document.dispatchEvent(new Event('murmurworld:appliance-selection-request'));
}
