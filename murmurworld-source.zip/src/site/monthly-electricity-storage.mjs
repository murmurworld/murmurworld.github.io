const version = 1;
const key = `murmurworld:monthly-electricity:v${version}`;
const homes = ['studio', 'two-room', '24', '32', 'custom'];
const tariffs = ['unknown', 'low', 'high'];
const fieldId = /^[a-z\d][a-z\d-]{0,79}$/i;

const isRecord = (value) => value !== null && typeof value === 'object' && !Array.isArray(value);
const inRange = (value, min, max) => Number.isFinite(value) && value >= min && value <= max ? value : null;

function sanitizeRows(rows) {
  const entries = [];
  for (const [id, row] of Object.entries(rows)) {
    if (!fieldId.test(id) || !isRecord(row) || typeof row.enabled !== 'boolean' ||
      typeof row.kindId !== 'string' || !fieldId.test(row.kindId)) continue;
    entries.push([id, {
      kindId: row.kindId,
      enabled: row.enabled,
      power: inRange(row.power, 0, 20000),
      usage: inRange(row.usage, 0, 1440),
    }]);
  }
  return Object.fromEntries(entries);
}

function sanitizeCustom(rows) {
  const ids = new Set();
  const custom = [];
  for (const row of rows) {
    if (!isRecord(row) || typeof row.id !== 'string' || !/^custom-[1-9]\d*$/.test(row.id) ||
      !Number.isSafeInteger(Number(row.id.slice(7))) || ids.has(row.id) ||
      typeof row.name !== 'string' || typeof row.enabled !== 'boolean') continue;
    const name = row.name.trim().slice(0, 16);
    if (!name) continue;
    ids.add(row.id);
    custom.push({
      id: row.id, name, enabled: row.enabled,
      power: inRange(row.power, 1, 20000),
      usage: inRange(row.usage, 0, 24),
    });
  }
  return custom;
}

function sanitize(snapshot) {
  if (!isRecord(snapshot) || !homes.includes(snapshot.home) || !tariffs.includes(snapshot.voltage) ||
    !Number.isInteger(snapshot.month) || snapshot.month < 1 || snapshot.month > 12 ||
    !isRecord(snapshot.rows) || !Array.isArray(snapshot.custom)) return null;
  const { home, month, voltage, area, actualKwh, rows, custom, acManual } = snapshot;
  return {
    home, month, voltage,
    area: inRange(area, 3, 100),
    actualKwh: Number.isInteger(actualKwh) ? inRange(actualKwh, 0, 10000) : null,
    rows: sanitizeRows(rows),
    custom: sanitizeCustom(custom),
    acManual: acManual === true,
  };
}

export function readElectricitySettings(storage) {
  try {
    const saved = JSON.parse((storage ?? globalThis.localStorage)?.getItem(key) ?? 'null');
    return saved?.version === version ? sanitize(saved.snapshot) : null;
  } catch {
    return null;
  }
}

export function writeElectricitySettings(snapshot, storage) {
  try {
    const target = storage ?? globalThis.localStorage;
    const sanitized = sanitize(snapshot);
    if (!target || !sanitized) return false;
    target.setItem(key, JSON.stringify({ version, snapshot: sanitized }));
    return true;
  } catch {
    return false;
  }
}

export function clearElectricitySettings(storage) {
  try {
    const target = storage ?? globalThis.localStorage;
    if (!target) return false;
    target.removeItem(key);
    return true;
  } catch {
    return false;
  }
}
