// Local company marks. Source image and attribution URLs are public/media/company-marks/sources.json.
const mappedTickers = new Set([
  '000660', '005930', '055550', '105560', 'AAPL', 'ABBV', 'ADI', 'AMAT', 'AMD',
  'AMZN', 'APP', 'ASML', 'AVGO', 'BABA', 'BAC', 'BHP', 'BLK', 'BRK.B',
  'CAT', 'COP', 'COST', 'CRCL', 'CRWD', 'CSCO', 'CVX', 'DIS', 'GE',
  'GEV', 'GOOGL', 'HD', 'INTC', 'IONQ', 'JNJ', 'JPM', 'KLAC', 'KO',
  'LIN', 'LLY', 'LRCX', 'MA', 'META', 'MRK', 'MSFT', 'MU', 'NEM',
  'NFLX', 'NVDA', 'NVO', 'ORCL', 'PANW', 'PEP', 'PG', 'PLTR', 'PM',
  'QCOM', 'RIO', 'RTX', 'SCCO', 'SHEL', 'SNDK', 'SPCX', 'STT', 'STX',
  'TM', 'TMUS', 'TSLA', 'TSM', 'TTE', 'TXN', 'UNH', 'V', 'VZ',
  'WMT', 'XOM',
]);

export function companyMapMark(ticker: string): string | undefined {
  if (mappedTickers.has(ticker)) return `/media/company-marks/${ticker.toLowerCase()}.png`;
}
