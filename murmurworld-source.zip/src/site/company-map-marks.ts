// Each mark is a local copy of an image published on the company's own website.
// Original image and page URLs are recorded in public/media/company-marks/sources.json.
const mappedTickers = new Set([
  '000660', '005930', 'AAPL', 'AMD', 'AMZN', 'APP', 'ASML', 'AVGO', 'BAC',
  'BLK', 'COP', 'COST', 'CRCL', 'CRWD', 'CSCO', 'CVX', 'DIS', 'GE',
  'GEV', 'GOOGL', 'HD', 'INTC', 'IONQ', 'JNJ', 'JPM', 'KO', 'LLY',
  'LRCX', 'META', 'MRK', 'MSFT', 'MU', 'NEM', 'NFLX', 'NVDA', 'NVO',
  'ORCL', 'PANW', 'PG', 'PLTR', 'QCOM', 'RTX', 'SHEL', 'SNDK', 'STX',
  'TM', 'TMUS', 'TSLA', 'TSM', 'TXN', 'UNH', 'V', 'VZ', 'WMT',
  'XOM',
]);

export function companyMapMark(ticker: string): string | undefined {
  if (mappedTickers.has(ticker)) return `/media/company-marks/${ticker.toLowerCase()}.png`;
}
