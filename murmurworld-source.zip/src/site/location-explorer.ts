interface View { state:string; company:string; sector:string }
interface Company { ticker:string; name:string; sector:string; terms:string[]; sites:string[]; home:string; button:HTMLButtonElement }
const normalize = (text:string) => text.normalize('NFKC').toLowerCase().replace(/[\s.&-]/g, '');

export function setupLocationExplorer(root:HTMLElement) {
  if (root.hasAttribute('data-interactive')) return;
  const en = document.documentElement.lang === 'en';
  const statePicker = root.querySelector<HTMLSelectElement>('#market-state')!;
  const sectorPicker = root.querySelector<HTMLSelectElement>('#market-sector')!;
  const search = root.querySelector<HTMLInputElement>('#market-company-search')!;
  const form = search.form!;
  const matches = form.querySelector<HTMLElement>('.matches')!;
  const rail = root.querySelector<HTMLElement>('[data-region-rail]')!;
  const railNames = rail.querySelector<HTMLElement>('[data-region-companies]')!;
  const railReset = rail.querySelector<HTMLButtonElement>('[data-rail-reset]')!;
  const results = root.querySelector<HTMLElement>('[data-location-results]')!;
  const map = root.querySelector<HTMLElement>('[data-location-map]')!;
  const states = new Map(Array.from(statePicker.options, opt => [opt.value,opt.dataset.name!]));
  const sectors = new Set(Array.from(sectorPicker.options, opt => opt.value));
  const companies:Company[] = Array.from(form.querySelectorAll<HTMLButtonElement>('[data-company-option]'), button => {
    const d = button.dataset;
    return {ticker:d.companyOption!, name:d.name!, sector:d.sector!, sites:d.sites!.split(' '), home:d.home!,
      terms:[d.companyOption!,...d.names!.split('|')].filter(Boolean).map(normalize), button};
  });
  const byTicker = new Map(companies.map(c => [c.ticker,c]));
  const inState = new Map(Array.from(states.keys(), code => [code,companies.filter(c => c.sites.includes(code))]));
  let current:View = {state:'TX',company:'',sector:''};
  let queryHits:Company[] = [];

  const tally = (firms:number, sites:number) => en
    ? firms + (firms === 1 ? ' company' : ' companies') + ' · ' + sites + (sites === 1 ? ' site' : ' sites')
    : '기업 ' + firms + '곳 · 거점 ' + sites + '곳';
  function updateRail(view:View) {
    const rows = inState.get(view.state)!.filter(c => !view.sector || c.sector === view.sector);
    const selected = byTicker.get(view.company);
    const shown = selected ? [selected] : rows;
    const sites = shown.reduce((n,c) => n+c.sites.filter(s => s === view.state).length,0);
    const counts = tally(shown.length,sites);
    rail.querySelector('[data-region-code]')!.textContent = view.state;
    rail.querySelector('#region-name')!.textContent = states.get(view.state)!;
    rail.querySelector('[data-region-count]')!.textContent = counts;
    railReset.hidden = !selected && !view.sector;
    railReset.textContent = selected ? (en ? 'Back to state list' : '이 주의 기업 목록') : (en ? 'All industries' : '전체 업종 보기');
    railNames.replaceChildren(...shown.map(c => {
      const item = document.createElement(selected ? 'strong' : 'button');
      if (item instanceof HTMLButtonElement) {
        item.type = 'button';
        item.dataset.railCompany = c.ticker;
        item.title = c.name + ' · ' + c.ticker;
      }
      if (c.button.dataset.mark) {
        const mark = document.createElement('img');
        mark.src = c.button.dataset.mark;
        mark.alt = '';
        mark.width = mark.height = 16;
        item.append(mark);
      }
      item.append(selected ? c.name + ' · ' + c.ticker : c.name);
      return item;
    }));
    root.querySelector('.announce')!.textContent = [states.get(view.state),selected?.name,counts].filter(Boolean).join(' · ');
  }

  function render(view:View, focusMap:boolean, national = false) {
    current = view;
    statePicker.value = view.state;
    sectorPicker.value = view.sector;
    Object.assign(root.dataset,{mapState:view.state,mapCompany:view.company,mapSector:view.sector,
      mapCamera:national ? 'national' : focusMap ? 'state' : 'keep',
      locationState:view.state,locationCompany:view.company,locationSector:view.sector});
    updateRail(view);
    root.dispatchEvent(new CustomEvent('market-location-view',{detail:view}));
    map.dispatchEvent(new CustomEvent('location-map:update',{detail:{...view,focus:focusMap,national}}));
    root.dispatchEvent(new CustomEvent('market-company-change',{bubbles:true,detail:{company:view.company}}));
    root.dispatchEvent(new CustomEvent('market-sector-change',{bubbles:true,detail:{sector:view.sector}}));
    root.dispatchEvent(new CustomEvent('market-state-change',{bubbles:true,detail:{state:view.state}}));
  }
  function dismiss(clear = false) {
    matches.hidden = true;
    queryHits = [];
    form.querySelector('[data-search-status]')!.textContent = '';
    if (clear) search.value = '';
  }
  function choose(view:View, focusMap = true) {
    const url = new URL(location.href);
    for (const key of ['state','company','sector'] as const) {
      if (view[key]) url.searchParams.set(key,view[key]);
      else url.searchParams.delete(key);
    }
    if (view.company !== current.company || url.searchParams.has('peer')) url.searchParams.delete('case');
    url.searchParams.delete('peer');
    url.hash = 'us-map';
    if (url.href !== location.href) history.pushState(history.state,'',url);
    dismiss(true);
    render(view,focusMap);
  }
  function readLocation(focusMap:boolean) {
    const url = new URL(location.href);
    const selected = byTicker.get((url.searchParams.get('company') ?? '').toUpperCase());
    let sector = url.searchParams.get('sector') ?? '';
    if (!sectors.has(sector) || (selected && sector !== selected.sector)) sector = '';
    const hashState = /^#state-([a-z]{2})$/i.exec(url.hash)?.[1];
    let state = (hashState ?? url.searchParams.get('state') ?? '').toUpperCase();
    if (!states.has(state)) {
      state = selected?.home ?? 'TX';
      if (!selected && sector) {
        const count = (code:string) => inState.get(code)!.filter(c => c.sector === sector).length;
        state = [...states.keys()].reduce((best,code) => count(code) > count(best) ? code : best,state);
      }
    }
    const company = hashState ? '' : selected?.ticker ?? '';
    if (company && selected && !selected.sites.includes(state)) state = selected.home;
    if (hashState) sector = '';
    // Keep other stock activities and their URL parameters intact.
    if (url.hash === '#us-map' || hashState) {
      const view = {state,company,sector};
      const oldHref = url.href;
      for (const key of ['state','company','sector'] as const) {
        if (!url.searchParams.has(key) && key !== 'state') continue;
        if (key === 'state' && !url.searchParams.has(key) && !hashState) continue;
        if (view[key]) url.searchParams.set(key,view[key]);
        else url.searchParams.delete(key);
      }
      if (oldHref !== url.href) history.replaceState(history.state,'',url);
    }
    dismiss(true);
    const explicitView = Boolean(hashState || url.searchParams.has('state') || company || sector);
    render({state,company,sector},focusMap && explicitView,focusMap && !explicitView);
  }
  function revealProfile() {
    const heading = results.querySelector<HTMLElement>('[data-profile-title]')!;
    heading.focus({preventScroll:true});
    results.scrollIntoView({block:'start'});
  }
  function chooseCompany(ticker:string, preferred = current.state) {
    const c = byTicker.get(ticker);
    if (!c) return;
    const state = c.sites.includes(preferred) ? preferred : c.home;
    choose({state,company:ticker,sector:current.sector === c.sector ? current.sector : ''});
    revealProfile();
  }
  function searchOptions() {
    const query = normalize(search.value.trim());
    if (!query) { dismiss(); return; }
    const rank = (c:Company) => c.terms.includes(query) ? 0 : c.terms.some(t => t.startsWith(query)) ? 1 : 2;
    queryHits = companies.filter(c => c.terms.some(t => t.includes(query))).sort((a,b) => rank(a)-rank(b)).slice(0,8);
    // Results are ranked independently of the active state or industry.
    for (const c of companies) c.button.parentElement!.hidden = true;
    for (const c of queryHits) {
      const li = c.button.parentElement!;
      li.hidden = false;
      li.parentElement!.append(li);
    }
    form.querySelector<HTMLElement>('[data-search-empty]')!.hidden = queryHits.length > 0;
    form.querySelector('[data-search-status]')!.textContent = en
      ? queryHits.length + (queryHits.length === 1 ? ' suggestion' : ' suggestions')
      : '검색 후보 ' + queryHits.length + '곳';
    matches.hidden = false;
  }
  form.addEventListener('submit', e => { e.preventDefault(); if (!matches.hidden && queryHits[0]) chooseCompany(queryHits[0].ticker); });
  search.addEventListener('input', searchOptions);
  search.addEventListener('focus', searchOptions);
  form.addEventListener('keydown', e => {
    if (e.isComposing) return;
    if (e.key === 'Escape') { e.preventDefault(); search.focus(); dismiss(true); return; }
    if (matches.hidden || !queryHits.length || !['ArrowDown','ArrowUp'].includes(e.key)) return;
    e.preventDefault();
    const index = queryHits.findIndex(c => c.button === document.activeElement);
    const next = e.key === 'ArrowDown' ? (index+1) % queryHits.length : (index <= 0 ? queryHits.length-1 : index-1);
    queryHits[next].button.focus();
  });
  form.addEventListener('click', e => {
    const button = (e.target as Element).closest<HTMLButtonElement>('[data-company-option]');
    if (button) chooseCompany(button.dataset.companyOption!);
  });
  form.addEventListener('focusout', e => { if (!form.contains(e.relatedTarget as Node | null)) dismiss(); });
  document.addEventListener('pointerdown', e => { if (!form.contains(e.target as Node)) dismiss(); });
  statePicker.addEventListener('change', () => choose({state:statePicker.value,company:'',sector:''}));
  sectorPicker.addEventListener('change', () => choose({state:current.state,company:'',sector:sectorPicker.value},false));
  railNames.addEventListener('click', e => {
    const button = (e.target as Element).closest<HTMLButtonElement>('[data-rail-company]');
    if (button) chooseCompany(button.dataset.railCompany!);
  });
  railReset.addEventListener('click', () => {
    choose({state:current.state,company:'',sector:current.company ? current.sector : ''},false);
    (railNames.querySelector<HTMLElement>('button') ?? statePicker).focus({preventScroll:true});
  });
  root.addEventListener('location-map:select', e => {
    const {state,company} = (e as CustomEvent<{state:string;company?:string}>).detail;
    if (!states.has(state)) return;
    if (company) chooseCompany(company,state);
    else choose({state,company:'',sector:''});
  });
  root.addEventListener('market-location-pick', e => {
    const {state,company} = (e as CustomEvent<View>).detail;
    if (states.has(state) && (!company || byTicker.get(company)?.sites.includes(state)))
      choose({state,company,sector:current.sector},state !== current.state);
  });
  root.querySelector<HTMLElement>('[data-explorer-tools]')!.hidden = false;
  rail.hidden = false;
  root.dataset.interactive = '';
  readLocation(true);
  window.addEventListener('popstate', () => readLocation(true));
  window.addEventListener('hashchange', () => { if (/^#state-[a-z]{2}$/i.test(location.hash)) readLocation(true); });
  window.addEventListener('pageshow', e => { if (e.persisted) readLocation(true); });
  document.addEventListener('market-network-navigate', () => readLocation(true));
}
