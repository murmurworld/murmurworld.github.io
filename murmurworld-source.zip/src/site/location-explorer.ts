import { mountCompanyMap, readCompanyMapScene, type MapScene } from './company-map-view';

interface View { state:string; company:string; sector:string }
interface Company { ticker:string; name:string; sector:string; terms:string[]; sites:string[]; home:string; button:HTMLButtonElement }
interface SearchOption {terms:string[];button:HTMLButtonElement}
interface StateOption {code:string;name:string;ko:string;en:string;count:number}
const normalize = (text:string) => text.normalize('NFKC').toLowerCase().replace(/[\s.&-]/g, '');

export function setupLocationExplorer(root:HTMLElement) {
  if (root.hasAttribute('data-interactive')) return;
  const en = document.documentElement.lang === 'en';
  const search = root.querySelector<HTMLInputElement>('#market-company-search')!;
  const form = search.form!;
  const matches = form.querySelector<HTMLElement>('.matches')!;
  const rail = root.querySelector<HTMLElement>('[data-region-rail]')!;
  const railNames = rail.querySelector<HTMLElement>('[data-region-companies]')!;
  const railReset = rail.querySelector<HTMLButtonElement>('[data-rail-reset]')!;
  const results = root.querySelector<HTMLElement>('[data-location-results]')!;
  const stateGuide = root.querySelector<HTMLElement>('[data-state-guide]')!;
  const map = root.querySelector<HTMLElement>('[data-location-map]')!;
  const workspace = root.querySelector<HTMLElement>('.study-workspace')!;
  const mapPane = root.querySelector<HTMLElement>('[data-map-pane]')!;
  const companyPane = root.querySelector<HTMLElement>('[data-company-pane]')!;
  const reader = root.querySelector<HTMLElement>('[data-company-reader]')!;
  const readingPanes = root.querySelector<HTMLElement>('[data-reading-panes]')!;
  const researchPane = root.querySelector<HTMLElement>('[data-research-pane]')!;
  const paneActions = root.querySelector<HTMLElement>('[data-pane-actions]')!;
  const wideButton = paneActions.querySelector<HTMLButtonElement>('[data-reading-width]')!;
  const wide = matchMedia('(min-width:1600px)');
  // A direct language switch can restore its map before the component script runs.
  mountCompanyMap(map);
  const states = new Map(Array.from(map.querySelectorAll<SVGAElement>('[data-geo-state]'),
    link => [link.dataset.geoState!,link.dataset.name!]));
  const companies:Company[] = Array.from(form.querySelectorAll<HTMLButtonElement>('[data-company-option]'), button => {
    const d = button.dataset;
    return {ticker:d.companyOption!, name:d.name!, sector:d.sector!, sites:d.sites!.split(' '), home:d.home!,
      terms:[d.companyOption!,...d.names!.split('|')].filter(Boolean).map(normalize), button};
  });
  const byTicker = new Map(companies.map(c => [c.ticker,c]));
  const sectors = new Set(companies.map(c => c.sector));
  const inState = new Map(Array.from(states.keys(), code => [code,companies.filter(c => c.sites.includes(code))]));
  const nationalExamples = ['INTC','TXN','MU','MSFT','JPM','CAT'].map(ticker=>byTicker.get(ticker)).filter((c):c is Company=>Boolean(c));
  let current:View = {state:'US',company:'',sector:''};
  function readingWidth(expanded:boolean) {
    root.toggleAttribute('data-reading-expanded',expanded);
    wideButton.setAttribute('aria-pressed',String(expanded));
    wideButton.textContent=expanded?wideButton.dataset.restore!:wideButton.dataset.expand!;
  }
  wideButton.addEventListener('click',()=>readingWidth(!root.hasAttribute('data-reading-expanded')));
  // Anchors and history can point into a pane which the reader temporarily widened away.
  function revealHash(hash:string) {
    if(!root.hasAttribute('data-reading-expanded') || !hash)return;
    let id:string;
    try{id=decodeURIComponent(hash.slice(1))}catch{return}
    const target=document.getElementById(id);
    if(target && !companyPane.contains(target))readingWidth(false);
  }
  document.addEventListener('click',event=>{
    if(event.button!==0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey)return;
    const link=(event.target as Element).closest<HTMLAnchorElement>('a[href]');
    if(link && (!link.target || link.target==='_self') && link.origin===location.origin && link.pathname===location.pathname)revealHash(link.hash);
  },{capture:true});
  window.addEventListener('hashchange',()=>revealHash(location.hash));
  function arrangeReading() {
    paneActions.hidden=!(wide.matches && current.company);
    if(paneActions.hidden)readingWidth(false);
    if(wide.matches) {
      // Keep the geographic guide next to its controls while the manuscript scrolls independently.
      if(stateGuide.parentElement!==mapPane)mapPane.append(stateGuide);
      if(reader.nextElementSibling!==results)results.before(reader);
    } else {
      if(companyPane.lastElementChild!==reader)companyPane.append(reader);
      if(current.company && results.nextElementSibling!==stateGuide)results.after(stateGuide);
      if(!current.company && stateGuide.nextElementSibling!==results)results.before(stateGuide);
    }
  }
  let resizeFrame=0;
  function fitWorkspace(){
    if(!wide.matches || resizeFrame)return;
    resizeFrame=requestAnimationFrame(()=>{
      resizeFrame=0;
      const top=Math.max(12,Math.min(innerHeight*.45,workspace.getBoundingClientRect().top));
      workspace.style.setProperty('--study-space',Math.max(280,Math.floor(innerHeight-top-12))+'px');
    });
  }
  wide.addEventListener('change',()=>{arrangeReading();fitWorkspace()});
  new ResizeObserver(fitWorkspace).observe(root.closest('[data-stock-hub]')!.querySelector('.stock-heading')!);
  window.addEventListener('scroll',fitWorkspace,{passive:true});
  window.addEventListener('resize',fitWorkspace);
  const stateOptions:SearchOption[]=(JSON.parse(form.dataset.searchStates||'[]') as StateOption[]).map(place=>{
    const li=document.createElement('li'), button=document.createElement('button'), label=document.createElement('small');
    button.type='button';button.dataset.stateOption=place.code;
    label.textContent=en?`${place.code} · ${place.count} ${place.count===1?'company':'companies'}`:`${place.code} · 기업 ${place.count}곳`;
    button.append(place.name,label);li.append(button);
    return {terms:[place.code,place.en,place.ko,place.ko+'주',...(place.code==='DC'?['Washington DC','워싱턴 DC']:[])].map(normalize),button};
  });
  const options:SearchOption[]=[...companies,...stateOptions];
  let queryHits:SearchOption[] = [];

  const tally = (firms:number, sites:number) => en
    ? firms + (firms === 1 ? ' company' : ' companies') + ' · ' + sites + (sites === 1 ? ' site' : ' sites')
    : '기업 ' + firms + '곳 · 거점 ' + sites + '곳';
  function updateRail(view:View) {
    const national=view.state==='US';
    const rows = (inState.get(view.state) || []).filter(c => !view.sector || c.sector === view.sector);
    const selected = byTicker.get(view.company);
    const shown = selected ? [selected] : national ? nationalExamples : rows;
    const sites = rows.reduce((n,c) => n+c.sites.filter(s => s === view.state).length,0);
    const counts = national ? (en?`${companies.length} companies on the map`:`지도에 실린 기업 ${companies.length}곳`) : tally(rows.length,sites);
    rail.querySelector<HTMLElement>('[data-national-sectors]')!.hidden=!national;
    rail.querySelector<HTMLElement>('[data-national-states]')!.hidden=!national;
    const snapshots=rail.querySelectorAll<HTMLElement>('[data-rail-geography]');
    for(const card of snapshots) card.hidden=card.dataset.railGeography!==view.state;
    rail.querySelector('[data-region-code]')!.textContent = view.state;
    rail.querySelector('#region-name')!.textContent = states.get(view.state) || (en?'United States':'미국 전체');
    rail.querySelector<HTMLElement>('.rail-links')!.hidden=national;
    rail.querySelector('[data-region-count]')!.textContent = counts;
    railReset.hidden = !selected && !view.sector;
    railReset.textContent = selected ? (en ? 'Back to state list' : '이 주의 기업 목록') : (en ? 'All industries' : '전체 업종 보기');
    railNames.replaceChildren(...shown.map(c => {
      const item = document.createElement(selected ? 'strong' : 'button');
      if (item instanceof HTMLButtonElement) {
        item.type = 'button';
        item.dataset.railCompany = c.ticker;
        item.title = c.name + ' · ' + c.ticker;
      }
      if (c.button.dataset.mark) {
        const mark = document.createElement('img');
        mark.src = c.button.dataset.mark;
        mark.alt = '';
        mark.width = mark.height = 16;
        item.append(mark);
      }
      item.append(selected ? c.name + ' · ' + c.ticker : c.name);
      return item;
    }));
    root.querySelector(':scope > .announce')!.textContent = [states.get(view.state),selected?.name,counts].filter(Boolean).join(' · ');
  }

  function render(view:View, focusMap:boolean, national = false, scene?:MapScene) {
    const selectionChanged=current.company!==view.company || current.state!==view.state;
    current = view;
    Object.assign(root.dataset,{mapState:view.state,mapCompany:view.company,mapSector:view.sector,
      mapCamera:national ? 'national' : focusMap ? 'state' : 'keep',
      locationState:view.state,locationCompany:view.company,locationSector:view.sector});
    updateRail(view);
    arrangeReading();
    if(wide.matches && selectionChanged){
      companyPane.scrollTop=0;
      readingPanes.scrollTop=0;
      researchPane.scrollTop=0;
    }
    fitWorkspace();
    root.dispatchEvent(new CustomEvent('market-location-view',{detail:view}));
    map.dispatchEvent(new CustomEvent('location-map:update',{detail:{...view,focus:focusMap,national,scene}}));
    root.dispatchEvent(new CustomEvent('market-company-change',{bubbles:true,detail:{company:view.company}}));
    root.dispatchEvent(new CustomEvent('market-sector-change',{bubbles:true,detail:{sector:view.sector}}));
    root.dispatchEvent(new CustomEvent('market-state-change',{bubbles:true,detail:{state:view.state}}));
  }
  function dismiss(clear = false) {
    matches.hidden = true;
    queryHits = [];
    form.querySelector('[data-search-status]')!.textContent = '';
    if (clear) search.value = '';
  }
  function choose(view:View, focusMap = true, scene?:MapScene) {
    const url = new URL(location.href);
    for (const key of ['state','company','sector'] as const) {
      if (view[key]) url.searchParams.set(key,view[key]);
      else url.searchParams.delete(key);
    }
    if (view.company !== current.company || url.searchParams.has('peer')) {
      url.searchParams.delete('case');
      url.searchParams.delete('relation');
    }
    url.searchParams.delete('peer');
    url.hash = 'us-map';
    const previous = history.state?.marketMap;
    const scroll = {left:window.scrollX,top:window.scrollY};
    if (scene || previous?.href === location.href) {
      const leaving = readCompanyMapScene(map);
      if (leaving) history.replaceState({...history.state,marketMap:{href:location.href,scene:leaving,scroll}},'');
    }
    const nextHistory = {...history.state};
    if (scene) nextHistory.marketMap = {href:url.href,scene,scroll}; else delete nextHistory.marketMap;
    if (url.href !== location.href) history.pushState(nextHistory,'',url);
    else if (scene || previous) history.replaceState(nextHistory,'',url);
    dismiss(true);
    render(view,focusMap,false,scene);
  }
  function readLocation(focusMap:boolean, restoreScene = false) {
    const url = new URL(location.href);
    const selected = byTicker.get((url.searchParams.get('company') ?? '').toUpperCase());
    let sector = url.searchParams.get('sector') ?? '';
    if (!sectors.has(sector) || (selected && sector !== selected.sector)) sector = '';
    const hashState = /^#state-([a-z]{2})$/i.exec(url.hash)?.[1];
    let state = (hashState ?? url.searchParams.get('state') ?? '').toUpperCase();
    if (!states.has(state)) {
      const requestedCase=url.searchParams.get('case') || (/^#case-(.+)$/.exec(url.hash)?.[1] ?? '');
      const caseOption=requestedCase ? [...document.querySelectorAll<HTMLOptionElement>('[data-case-picker] option')].find(option=>option.value===requestedCase) : undefined;
      const caseHome=caseOption?.dataset.tickers?.split(' ').map(t=>byTicker.get(t)?.home).find(Boolean);
      state = selected?.home ?? caseHome ?? 'US';
      if (!selected && sector) {
        const count = (code:string) => (inState.get(code)||[]).filter(c => c.sector === sector).length;
        state = [...states.keys()].reduce((best,code) => count(code) > count(best) ? code : best,state);
      }
    }
    const company = hashState ? '' : selected?.ticker ?? '';
    if (company && selected && !selected.sites.includes(state)) state = selected.home;
    if (hashState) sector = '';
    // Keep other stock activities and their URL parameters intact.
    if (url.hash === '#us-map' || hashState) {
      const view = {state,company,sector};
      const oldHref = url.href;
      for (const key of ['state','company','sector'] as const) {
        if (!url.searchParams.has(key) && key !== 'state') continue;
        if (key === 'state' && !url.searchParams.has(key) && !hashState) continue;
        if (view[key] && !(key==='state' && view.state==='US')) url.searchParams.set(key,view[key]);
        else url.searchParams.delete(key);
      }
      if (oldHref !== url.href) history.replaceState(history.state,'',url);
    }
    dismiss(true);
    const saved = restoreScene && history.state?.marketMap;
    const scene = saved?.href === location.href ? saved.scene as MapScene : undefined;
    render({state,company,sector},false,focusMap,scene);
    if (scene && saved.scroll) {
      // Native history restoration can anchor to the outgoing panel's height after popstate.
      requestAnimationFrame(() => {
        if (saved.href===location.href) window.scrollTo({...saved.scroll,behavior:'instant'});
      });
    }
  }
  function chooseCompany(ticker:string, preferred = current.state, inMap = false) {
    const c = byTicker.get(ticker);
    if (!c) return;
    const state = c.sites.includes(preferred) ? preferred : c.home;
    const view = {state,company:ticker,sector:current.sector === c.sector ? current.sector : ''};
    const scene=readCompanyMapScene(map);
    // A company picked from a direct link may have narrowed the map to that issuer.
    // Preserve the camera, clearing filters that would hide the new selection.
    choose(view,false,scene && {...scene,region:'',company:scene.company ? ticker : '',sector:view.sector});
    if (!inMap) search.focus({preventScroll:true});
  }
  function searchOptions() {
    const query = normalize(search.value.trim());
    if (!query) { dismiss(); return; }
    const rank = (c:SearchOption) => c.terms.includes(query) ? 0 : c.terms.some(t => t.startsWith(query)) ? 1 : 2;
    queryHits = options.filter(c => c.terms.some(t => t.includes(query))).sort((a,b) => rank(a)-rank(b)).slice(0,8);
    // Results are ranked independently of the active state or industry.
    const list=form.querySelector<HTMLElement>('#market-company-results')!;
    for (const c of options) c.button.parentElement!.hidden = true;
    for (const c of queryHits) {
      const li = c.button.parentElement!;
      li.hidden = false;
      list.append(li);
    }
    form.querySelector<HTMLElement>('[data-search-empty]')!.hidden = queryHits.length > 0;
    form.querySelector('[data-search-status]')!.textContent = en
      ? queryHits.length + (queryHits.length === 1 ? ' suggestion' : ' suggestions')
      : '검색 후보 ' + queryHits.length + '곳';
    matches.hidden = false;
  }
  form.addEventListener('submit', e => { e.preventDefault(); if (!matches.hidden && queryHits[0]) queryHits[0].button.click(); });
  search.addEventListener('input', searchOptions);
  search.addEventListener('focus', searchOptions);
  form.addEventListener('keydown', e => {
    if (e.isComposing) return;
    if (e.key === 'Escape') { e.preventDefault(); search.focus(); dismiss(true); return; }
    if (matches.hidden || !queryHits.length || !['ArrowDown','ArrowUp'].includes(e.key)) return;
    e.preventDefault();
    const index = queryHits.findIndex(c => c.button === document.activeElement);
    const next = e.key === 'ArrowDown' ? (index+1) % queryHits.length : (index <= 0 ? queryHits.length-1 : index-1);
    queryHits[next].button.focus();
  });
  form.addEventListener('click', e => {
    const button = (e.target as Element).closest<HTMLButtonElement>('[data-company-option],[data-state-option]');
    if(button?.dataset.companyOption) chooseCompany(button.dataset.companyOption);
    if(button?.dataset.stateOption){
      chooseState(button.dataset.stateOption);
      search.focus({preventScroll:true});
    }
  });
  form.addEventListener('focusout', e => { if (!form.contains(e.relatedTarget as Node | null)) dismiss(); });
  document.addEventListener('pointerdown', e => { if (!form.contains(e.target as Node)) dismiss(); });
  railNames.addEventListener('click', e => {
    const button = (e.target as Element).closest<HTMLButtonElement>('[data-rail-company]');
    if (button) {
      const focusWasHere = document.activeElement === button;
      chooseCompany(button.dataset.railCompany!,current.state,true);
      if (focusWasHere && !button.isConnected) {
        const heading = rail.querySelector<HTMLElement>('#region-name')!;
        heading.tabIndex = -1;
        heading.focus({preventScroll:true});
      }
    }
  });
  rail.addEventListener('click', e=>{
    const link=(e.target as Element).closest<HTMLAnchorElement>('[data-rail-state]');
    if(!link || e.button!==0 || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey)return;
    e.preventDefault();
    chooseState(link.dataset.railState!);
    const heading=rail.querySelector<HTMLElement>('#region-name')!;
    heading.tabIndex=-1;
    heading.focus({preventScroll:true});
  });
  railReset.addEventListener('click', () => {
    const sector=current.company ? current.sector : '';
    const scene=readCompanyMapScene(map);
    choose({state:current.state,company:'',sector},false,scene && {...scene,region:'',company:'',sector});
    (railNames.querySelector<HTMLElement>('button') ?? search).focus({preventScroll:true});
  });
  root.addEventListener('location-map:select', e => {
    const {state,company} = (e as CustomEvent<{state:string;company?:string}>).detail;
    if (!states.has(state)) return;
    if (company) chooseCompany(company,state,true);
    else chooseState(state);
  });
  function chooseState(state:string){
    if(!states.has(state))return;
    const scene=readCompanyMapScene(map);
    choose({state,company:'',sector:''},false,scene && {...scene,region:'',company:'',sector:''});
  }
  root.addEventListener('market-location-pick', e => {
    const {state,company} = (e as CustomEvent<View>).detail;
    if (states.has(state) && (!company || byTicker.get(company)?.sites.includes(state))) {
      const scene=readCompanyMapScene(map);
      choose({state,company,sector:current.sector},false,scene && {...scene,region:'',company:scene.company ? company : ''});
    }
  });
  root.querySelector<HTMLElement>('[data-explorer-tools]')!.hidden = false;
  rail.hidden = false;
  root.dataset.interactive = '';
  const handoffKey='market-language-camera';
  function rememberCamera() {
    const scene=readCompanyMapScene(map);
    if(scene) {
      const saved=history.state?.marketMap;
      if(saved?.href!==location.href || JSON.stringify(saved.scene)!==JSON.stringify(scene)
        || saved.scroll?.top!==scrollY || saved.scroll?.left!==scrollX) {
        history.replaceState({...history.state,marketMap:{href:location.href,scene,scroll:{top:scrollY,left:scrollX}}},'');
      }
    }
    return scene;
  }
  // Keep the shareable URL independent of personal zoom. A language link in this
  // tab transfers its camera once. Back/Forward uses the entry's own camera.
  document.addEventListener('click',event=>{
    if(event.defaultPrevented || event.button!==0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const link=(event.target as Element).closest<HTMLAnchorElement>('a[data-language-switch]');
    if(!link || link.hasAttribute('download') || (link.target && link.target!=='_self') || link.origin!==location.origin) return;
    if(link.pathname!==(en?'/stocks/':'/en/stocks/')) return;
    const scene=rememberCamera();
    if(!scene) return;
    try {
      const from=new URL(location.href); from.hash='';
      sessionStorage.setItem(handoffKey,JSON.stringify({from:from.href,to:link.href,time:Date.now(),scene}));
    } catch { /* Storage can be disabled. The language link still works. */ }
  });
  const navigation=performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming|undefined;
  let restoring=navigation?.type==='back_forward';
  if(navigation?.type==='navigate') {
    try {
      const transfer=JSON.parse(sessionStorage.getItem(handoffKey)||'null');
      sessionStorage.removeItem(handoffKey);
      if(transfer?.to===location.href && transfer.from===document.referrer && Date.now()-transfer.time<60000
        && Number.isFinite(transfer.scene?.zoom) && Number.isFinite(transfer.scene?.center?.x) && Number.isFinite(transfer.scene?.center?.y)) {
        history.replaceState({...history.state,marketMap:{href:location.href,scene:transfer.scene}},'');
        restoring=true;
      }
    } catch { /* An unavailable or expired handoff leaves the initial national view. */ }
  }
  readLocation(true,restoring);
  // A browser can freeze a document before pagehide is allowed to write history.
  // Save completed camera gestures as part of their own existing history entry.
  for(const type of ['click','keyup','pointerup','touchend']) map.addEventListener(type,rememberCamera,{passive:true});
  let wheelTimer=0;
  map.addEventListener('wheel',()=>{
    window.clearTimeout(wheelTimer);
    wheelTimer=window.setTimeout(rememberCamera,150);
  },{passive:true});
  window.addEventListener('pagehide',rememberCamera);
  window.addEventListener('popstate', () => readLocation(true,true));
  window.addEventListener('hashchange', () => { if (/^#state-[a-z]{2}$/i.test(location.hash)) readLocation(true); });
  window.addEventListener('pageshow', e => { if (e.persisted) readLocation(true,true); });
  document.addEventListener('market-network-navigate', () => readLocation(true));
}
