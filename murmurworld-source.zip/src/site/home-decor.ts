export const homeAppliancesEntry = {
  href: '/blog/home/decor/appliances/',
  title: '신혼 가전, 결국 백화점에서 샀다',
  titleEn: 'Why We Bought Our Appliances at a Department Store',
  description: '브랜드를 섞어 고르다가 백화점에서 삼성 가전 다섯 가지를 한꺼번에 계약한 이야기.',
  descriptionEn: 'We started with a mix of brands and ended up buying five Samsung appliances together at a department store.',
  cover: '/media/covers/home-appliances.webp',
  focus: '50% 52%',
};

export const homeAppliancesSocialImage = {
  src: '/media/covers/home-appliances-share.jpg',
  type: 'image/jpeg',
  width: 720,
  height: 480,
};

export const homeRefrigeratorEntry = {
  href: '/blog/home/decor/refrigerator/',
  title: '냉장고, 834L를 알아보다 609L 키친핏을 고른 이유',
  titleEn: 'Why We Chose a 609 L Kitchen Fit Max Fridge After Considering an 834 L Model',
  description: '김치냉장고와 나란히 둘 자리를 생각하며 폭과 깊이, 냉동실 용량과 월 소비전력량을 비교했다.',
  descriptionEn: 'We compared depth, width, freezer capacity, and monthly electricity use with a kimchi refrigerator in mind.',
  cover: '/media/covers/home-refrigerator.jpg',
  focus: '50% 50%',
};

export const homeRefrigeratorSocialImage = {
  src: homeRefrigeratorEntry.cover,
  type: 'image/jpeg',
  width: 1200,
  height: 630,
};

export const homeWasherDryerEntry = {
  href: '/blog/home/decor/washer-dryer/',
  title: '세탁기 위에 건조기를 올리려다, 한 대로 바꿨다',
  titleEn: 'Why We Chose a Washer-Dryer Combo',
  description: '다용도실에 두 대를 쌓으려다 세탁과 건조를 한 통에서 하는 콤보를 골랐다.',
  descriptionEn: 'We planned to stack a washer and dryer, then chose an all-in-one machine for our laundry room.',
  cover: '/media/covers/home-washer-dryer.jpg',
  focus: '50% 50%',
};

export const homeWasherDryerSocialImage = {
  src: homeWasherDryerEntry.cover,
  type: 'image/jpeg',
  width: 1200,
  height: 630,
};

export const homeSofaEntry = {
  href: '/blog/home/decor/sofa/',
  title: '신혼집 소파는 왜 맞춤 제작으로 골랐을까',
  titleEn: 'How We Chose a Custom Sofa for Our First Home',
  description: '쇼룸에서 마음이 바뀌었다. 식탁과 로봇청소기가 들어갈 자리까지 생각해 소파를 맞춤으로 골랐다.',
  descriptionEn: 'A showroom visit changed the materials we wanted. Our dining table and robot vacuum helped us decide to go custom.',
  cover: '/media/covers/home-sofa.webp',
  focus: '50% 53%',
};

export const homeSofaSocialImage = {
  src: '/media/covers/home-sofa-share.jpg',
  type: 'image/jpeg',
  width: 720,
  height: 480,
};

export const homeDecorEntries = [
  homeAppliancesEntry,
  homeRefrigeratorEntry,
  homeWasherDryerEntry,
  homeSofaEntry,
  {
    href: '/blog/home/decor/energy/',
    title: '전기·에너지 비용',
    titleEn: 'Electricity & Energy Costs',
    description: '가전별 전력 사용량을 살펴보고, 가전을 하나 더 들이면 전기요금이 얼마나 달라지는지 계산해 봅니다.',
    descriptionEn: 'Compare what different appliances use and estimate how adding one might affect your electricity bill.',
    cover: '/media/covers/home-energy.webp',
    focus: '50% 50%',
  },
];
