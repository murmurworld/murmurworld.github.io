export const homeRefrigeratorEntry = {
  href: '/blog/home/decor/refrigerator/',
  title: '냉장고, 834L를 알아보다 609L 키친핏을 고른 이유',
  titleEn: 'Why We Chose a 609 L Kitchen Fit Max Fridge After Considering an 834 L Model',
  description: '김치냉장고와 나란히 둘 자리를 생각하며 폭과 깊이, 냉동실 용량과 월 소비전력량을 비교했다.',
  descriptionEn: 'We compared depth, width, freezer capacity, and monthly electricity use with a kimchi refrigerator in mind.',
  cover: '/media/covers/home-refrigerator.jpg',
  focus: '50% 50%',
};

export const homeRefrigeratorSocialImage = {
  src: homeRefrigeratorEntry.cover,
  type: 'image/jpeg',
  width: 1200,
  height: 630,
};

export const homeDecorEntries = [
  {
    href: '/blog/home/decor/appliances/',
    title: '신혼 가전, 결국 백화점에서 샀다',
    titleEn: 'Why We Bought Our Appliances at a Department Store',
    description: '온라인 가격을 비교하다 백화점에서 가전 다섯 가지를 함께 산 이야기.',
    descriptionEn: 'How comparing prices online led us to buy five appliances at a department store.',
    cover: '/media/covers/home-appliances.webp',
    focus: '50% 52%',
  },
  homeRefrigeratorEntry,
  {
    href: '/blog/home/decor/sofa/',
    title: '신혼집 소파는 왜 맞춤 제작으로 골랐을까',
    titleEn: 'How We Chose a Custom Sofa for Our First Home',
    description: '패브릭 모듈을 알아보다 쇼룸에서 직접 앉아본 뒤 달라진 선택. 소재와 통로를 함께 봤다.',
    descriptionEn: 'A showroom visit changed what we wanted from a sofa. Here’s what we considered at home and in the store.',
    cover: '/media/covers/home-sofa.webp',
    focus: '50% 53%',
  },
  {
    href: '/blog/home/decor/energy/',
    title: '전기·에너지 비용',
    titleEn: 'Electricity & Energy Costs',
    description: '가전별 전력 사용량을 살펴보고, 가전을 하나 더 들이면 전기요금이 얼마나 달라지는지 계산해 봅니다.',
    descriptionEn: 'Compare what different appliances use and estimate how adding one might affect your electricity bill.',
    cover: '/media/covers/home-energy.webp',
    focus: '50% 50%',
  },
];
