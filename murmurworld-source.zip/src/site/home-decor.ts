interface ArticleMetadata {
  title: string;
  description: string;
}

const articleMetadata = import.meta.glob<ArticleMetadata>('../articles/home-decor/*.md', {
  eager: true,
  import: 'frontmatter',
});

function readArticleMetadata(slug: string, language: 'ko' | 'en'): ArticleMetadata {
  const path = `../articles/home-decor/${slug}.${language}.md`;
  const metadata = articleMetadata[path];
  if (
    !metadata ||
    typeof metadata.title !== 'string' || !metadata.title.trim() ||
    typeof metadata.description !== 'string' || !metadata.description.trim()
  ) {
    throw new Error(`Set a title and description in ${slug}.${language}.md.`);
  }
  return metadata;
}

function localizedCopy(slug: string) {
  const korean = readArticleMetadata(slug, 'ko');
  const english = readArticleMetadata(slug, 'en');
  return {
    title: korean.title,
    titleEn: english.title,
    description: korean.description,
    descriptionEn: english.description,
  };
}

export const homeAppliancesEntry = {
  href: '/blog/home/decor/appliances/',
  ...localizedCopy('appliances'),
  cover: '/media/covers/home-appliances.webp',
  focus: '50% 52%',
};

export const homeAppliancesSocialImage = {
  src: '/media/covers/home-appliances-share.jpg',
  type: 'image/jpeg',
  width: 720,
  height: 480,
};

export const homeRefrigeratorEntry = {
  href: '/blog/home/decor/refrigerator/',
  ...localizedCopy('refrigerator'),
  cover: '/media/covers/home-refrigerator.jpg',
  focus: '50% 50%',
};

export const homeRefrigeratorSocialImage = {
  src: homeRefrigeratorEntry.cover,
  type: 'image/jpeg',
  width: 1200,
  height: 630,
};

export const homeWasherDryerEntry = {
  href: '/blog/home/decor/washer-dryer/',
  ...localizedCopy('washer-dryer'),
  cover: '/media/covers/home-washer-dryer.jpg',
  focus: '50% 50%',
};

export const homeWasherDryerSocialImage = {
  src: homeWasherDryerEntry.cover,
  type: 'image/jpeg',
  width: 1200,
  height: 630,
};

export const homeSofaEntry = {
  href: '/blog/home/decor/sofa/',
  ...localizedCopy('sofa'),
  cover: '/media/covers/home-sofa.webp',
  focus: '50% 53%',
};

export const homeSofaSocialImage = {
  src: '/media/covers/home-sofa-share.jpg',
  type: 'image/jpeg',
  width: 720,
  height: 480,
};

export const homeDecorEntries = [
  homeAppliancesEntry,
  homeRefrigeratorEntry,
  homeWasherDryerEntry,
  homeSofaEntry,
  {
    href: '/blog/home/decor/energy/',
    title: '전기·에너지 비용',
    titleEn: 'Electricity & Energy Costs',
    description: '가전별 전력 사용량을 살펴보고, 가전을 하나 더 들이면 전기요금이 얼마나 달라지는지 계산해 봅니다.',
    descriptionEn: 'Compare what different appliances use and estimate how adding one might affect your electricity bill.',
    cover: '/media/covers/home-energy.webp',
    focus: '50% 50%',
  },
];
