import { monthlyElectricityPath } from './monthly-electricity.mjs';

interface ArticleMetadata {
  title: string;
  description: string;
}

const articleMetadata = import.meta.glob<ArticleMetadata>('../articles/home-decor/*.md', {
  eager: true,
  import: 'frontmatter',
});

function readArticleMetadata(slug: string, language: 'ko' | 'en'): ArticleMetadata {
  const path = `../articles/home-decor/${slug}.${language}.md`;
  const metadata = articleMetadata[path];
  if (
    !metadata ||
    typeof metadata.title !== 'string' || !metadata.title.trim() ||
    typeof metadata.description !== 'string' || !metadata.description.trim()
  ) {
    throw new Error(`Set a title and description in ${slug}.${language}.md.`);
  }
  return metadata;
}

function localizedCopy(slug: string) {
  const korean = readArticleMetadata(slug, 'ko');
  const english = readArticleMetadata(slug, 'en');
  return {
    title: korean.title,
    titleEn: english.title,
    description: korean.description,
    descriptionEn: english.description,
  };
}

const applianceCategory = { category: '신혼 가전', categoryEn: 'Appliances' };

function newsroomPhoto(src: string, height: number, alt: string, altEn: string) {
  return { src: `/media/newsroom/${src}`, width: 1000, height, type: 'image/jpeg', alt, altEn };
}

function furnishingImage(file: string, alt: string, altEn: string) {
  return { src: `/media/covers/${file}.jpg`, width: 1200, height: 630, type: 'image/jpeg', alt, altEn };
}

export const homeLivingRoomSocialImage = furnishingImage(
  'sofa-living-room', '우리 집 거실 창가의 아이보리 르엘 소파와 둥근 러그',
  'Our ivory Leel sofa by the living room window with a round rug',
);

export const homeAppliancesSocialImage = newsroomPhoto(
  'samsung-kfm-showcase-couple.jpg', 735,
  '흰 냉장고의 푸드 쇼케이스 문 앞에 선 두 사람',
  'Two people in front of a white refrigerator with its Food Showcase door open',
);

export const homeRefrigeratorSocialImage = newsroomPhoto(
  'samsung-kfm-showcase-closed.jpg', 719,
  '흰 수납장 사이에 들어간 삼성 4도어 키친핏 맥스 냉장고 양옆에 두 사람이 서 있다',
  'Two people stand beside a white Samsung four-door Kitchen Fit Max refrigerator fitted between cabinets',
);

export const homeWasherDryerSocialImage = newsroomPhoto(
  'samsung-ai-combo-utility-2024.jpg', 563,
  '밝은 수납장 옆의 2024년형 삼성 비스포크 AI 콤보 세탁건조기',
  'A 2024 Samsung Bespoke AI Combo washer-dryer beside light cabinetry',
);

export const homeAppliancesEntry = {
  href: '/blog/home/decor/appliances/',
  ...localizedCopy('appliances'),
  ...applianceCategory,
  titleChunk: '백화점에서 샀다',
  cover: homeAppliancesSocialImage,
};

export const homeRefrigeratorEntry = {
  href: '/blog/home/decor/refrigerator/',
  ...localizedCopy('refrigerator'),
  ...applianceCategory,
  titleChunk: '609L 키친핏으로',
  cover: homeRefrigeratorSocialImage,
};

export const homeWasherDryerEntry = {
  href: '/blog/home/decor/washer-dryer/',
  ...localizedCopy('washer-dryer'),
  ...applianceCategory,
  titleChunk: '한 대로 바꿨다',
  cover: homeWasherDryerSocialImage,
};

export const homeSofaEntry = {
  href: '/blog/home/decor/sofa/',
  ...localizedCopy('sofa'),
  category: '가구',
  categoryEn: 'Furniture',
  titleChunk: '한쪽을 길게 맞춘 이유',
  cover: {
    src: '/media/monocus-sofa/leel-at-home.webp', width: 1440, height: 1080,
    alt: '우리 집 창가의 아이보리 르엘 소파와 둥근 러그', altEn: 'Our ivory Leel sofa by the window with a round rug',
  },
};

const applianceDetails = [
  {
    slug: 'water-purifier',
    cover: newsroomPhoto(
      'samsung-water-purifier-countertop.jpg', 562,
      '주방 상판 위에 놓인 삼성 비스포크 AI 정수기 카운터탑',
      'Samsung Bespoke AI water purifier on a kitchen countertop',
    ),
  },
  {
    slug: 'robot-vacuum',
    cover: newsroomPhoto(
      'samsung-robot-steam-kitchen-2026.jpg', 750,
      '주방 수납장 아래 도크에 들어간 삼성 비스포크 AI 스팀 일반형',
      'Standard Samsung Bespoke AI Steam robot vacuum docked beneath a kitchen cabinet',
    ),
  },
  {
    slug: 'air-purifier',
    cover: newsroomPhoto(
      'samsung-air-purifier-infinite-2024.jpg', 636,
      '크기와 색이 다른 삼성 비스포크 큐브 에어 인피니트 라인 공기청정기 네 대',
      'Four Samsung Bespoke Cube Air Infinite Line purifiers in different sizes and colors',
    ),
  },
];

const detailEntry = (slug: string) => ({
  slug, href: `/blog/home/decor/${slug}/`, ...localizedCopy(slug), titleChunk: undefined,
});

const applianceEntries = applianceDetails.map(({ slug, cover }) => ({
  ...detailEntry(slug),
  ...applianceCategory,
  publishedOn: '2026-11-24',
  cover,
}));

const furnishingEntries = [
  { slug: 'motion-desk', category: '가구', categoryEn: 'Furniture', label: '책상', labelEn: 'Desk',
    socialImage: furnishingImage('motion-desk-diagram', '높이 조절 다리와 조작 버튼을 그린 모션데스크 그림',
      'Illustration of a standing desk with telescoping legs and height controls') },
  { slug: 'mattress', category: '침실', categoryEn: 'Bedroom', label: '매트리스', labelEn: 'Mattress',
    socialImage: furnishingImage('mattress-diagram', '윗면과 스프링층을 나누어 그린 매트리스 단면 그림',
      'Cutaway illustration showing the surface and spring layer of a mattress') },
  { slug: 'trash-can', category: '집 관리', categoryEn: 'Home care', label: '쓰레기통', labelEn: 'Waste bin',
    socialImage: furnishingImage('trash-can-diagram', '페달 쓰레기통과 뚜껑을 열어 안쪽 봉투를 보여 주는 그림',
      'Illustration of a pedal bin and an open bin showing the inner liner') },
].map(({ slug, category, categoryEn, label, labelEn, socialImage }) => ({
  ...detailEntry(slug),
  category,
  categoryEn,
  publishedOn: '2026-11-26',
  cover: { label, labelEn },
  socialImage,
}));

export const homeDetailEntries = [...applianceEntries, ...furnishingEntries];

export const editableHomeDecorEntries = [
  homeAppliancesEntry,
  homeRefrigeratorEntry,
  homeWasherDryerEntry,
  ...applianceEntries,
  homeSofaEntry,
  ...furnishingEntries,
];

export const homeEnergyEntry = {
  href: monthlyElectricityPath,
  title: '우리 집 월 전기요금 계산기',
  titleEn: 'Monthly Home Electricity Bill Calculator',
  description: '집 크기와 가전 사용량으로 한 달 전기요금을 계산합니다. 고지서 금액으로 사용량도 추정할 수 있습니다.',
  descriptionEn: 'Estimate your monthly electricity bill in South Korea or work backward from a billed amount to find your usage.',
  category: '유지비',
  categoryEn: 'Running costs',
  titleChunk: undefined,
  cover: { label: '전기', labelEn: 'Energy' },
};

export const homeDecorEntries = [...editableHomeDecorEntries, homeEnergyEntry];
