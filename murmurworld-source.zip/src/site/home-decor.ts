interface ArticleMetadata {
  title: string;
  description: string;
}

const articleMetadata = import.meta.glob<ArticleMetadata>('../articles/home-decor/*.md', {
  eager: true,
  import: 'frontmatter',
});

function readArticleMetadata(slug: string, language: 'ko' | 'en'): ArticleMetadata {
  const path = `../articles/home-decor/${slug}.${language}.md`;
  const metadata = articleMetadata[path];
  if (
    !metadata ||
    typeof metadata.title !== 'string' || !metadata.title.trim() ||
    typeof metadata.description !== 'string' || !metadata.description.trim()
  ) {
    throw new Error(`Set a title and description in ${slug}.${language}.md.`);
  }
  return metadata;
}

function localizedCopy(slug: string) {
  const korean = readArticleMetadata(slug, 'ko');
  const english = readArticleMetadata(slug, 'en');
  return {
    title: korean.title,
    titleEn: english.title,
    description: korean.description,
    descriptionEn: english.description,
  };
}

const applianceCategory = { category: '신혼 가전', categoryEn: 'Appliances' };

function newsroomPhoto(src: string, height: number, alt: string, altEn: string) {
  return { src: `/media/newsroom/${src}`, width: 1000, height, type: 'image/jpeg', alt, altEn };
}

export const homeAppliancesSocialImage = newsroomPhoto(
  'samsung-kfm-showcase-couple.jpg', 735,
  '흰 냉장고의 푸드 쇼케이스 문 앞에 선 두 사람',
  'Two people in front of a white refrigerator with its Food Showcase door open',
);

export const homeRefrigeratorSocialImage = newsroomPhoto(
  'samsung-kfm-showcase-closed.jpg', 719,
  '흰 수납장 사이에 들어간 삼성 4도어 키친핏 맥스 냉장고',
  'A white Samsung four-door Kitchen Fit Max refrigerator fitted between cabinets',
);

export const homeWasherDryerSocialImage = newsroomPhoto(
  'samsung-ai-combo-utility-2024.jpg', 563,
  '밝은 수납장 옆의 2024년형 삼성 비스포크 AI 콤보 세탁건조기',
  'A 2024 Samsung Bespoke AI Combo washer-dryer beside light cabinetry',
);

export const homeAppliancesEntry = {
  href: '/blog/home/decor/appliances/',
  ...localizedCopy('appliances'),
  ...applianceCategory,
  titleChunk: '백화점에서 샀다',
  cover: homeAppliancesSocialImage,
};

export const homeRefrigeratorEntry = {
  href: '/blog/home/decor/refrigerator/',
  ...localizedCopy('refrigerator'),
  ...applianceCategory,
  titleChunk: '609L 키친핏이 됐다',
  cover: homeRefrigeratorSocialImage,
};

export const homeWasherDryerEntry = {
  href: '/blog/home/decor/washer-dryer/',
  ...localizedCopy('washer-dryer'),
  ...applianceCategory,
  titleChunk: '한 대로 바꿨다',
  cover: homeWasherDryerSocialImage,
};

export const homeSofaEntry = {
  href: '/blog/home/decor/sofa/',
  ...localizedCopy('sofa'),
  category: '가구',
  categoryEn: 'Furniture',
  titleChunk: '맞춤 제작으로',
  cover: { label: '소파', labelEn: 'Sofa' },
};

export const homeDecorEntries = [
  homeAppliancesEntry,
  homeRefrigeratorEntry,
  homeWasherDryerEntry,
  homeSofaEntry,
  {
    href: '/blog/home/decor/energy/',
    title: '전기·에너지 비용',
    titleEn: 'Electricity & Energy Costs',
    description: '가전별 전력 사용량을 살펴보고, 가전을 하나 더 들이면 전기요금이 얼마나 달라지는지 계산해 봅니다.',
    descriptionEn: 'Compare what different appliances use and estimate how adding one might affect your electricity bill.',
    category: '유지비',
    categoryEn: 'Running costs',
    titleChunk: undefined,
    cover: { label: '전기', labelEn: 'Energy' },
  },
];
