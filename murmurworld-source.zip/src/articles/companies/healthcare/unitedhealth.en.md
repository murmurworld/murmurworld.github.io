---
title: "UnitedHealth Group"
description: "UnitedHealthcare provides coverage, while Optum includes care delivery, information services and pharmacy benefit management. Employers, public programs and individuals buy health benefits. Providers, payers and plan sponsors also contract for Optum services."
---

UnitedHealthcare provides coverage, while Optum includes care delivery, information services and pharmacy benefit management. Employers, public programs and individuals buy health benefits. Providers, payers and plan sponsors also contract for Optum services.

| Basic information | Details |
| --- | --- |
| Principal office | Eden Prairie,, Minnesota |
| Operations | Health plans, care delivery facilities, pharmacy and healthcare technology operations |
| Listing and symbol | NYSE · UNH |
| Reported business lines | UnitedHealthcare · OptumRx · OptumHealth · OptumInsight · Corporate Non · Intersegment Elimination |
| Annual reporting date | 2025-12-31 |
| Annual consolidated revenue | 2025-12-31 · 447.567 USD billion |
| Fiscal year-to-date consolidated revenue | 2026-01-01 – 2026-09-30 · 336.447 USD billion |
| Shares issued | 896,000,000 · 2026-09-30 · [Filing](https://www.sec.gov/Archives/edgar/data/731766/000073176626000266/0000731766-26-000266-index.htm) |
| Shares outstanding | 896,022,611 · 2026-10-30 · [Filing](https://www.sec.gov/Archives/edgar/data/731766/000073176626000266/0000731766-26-000266-index.htm) |
| Filing | [10-K](https://www.sec.gov/Archives/edgar/data/731766/000073176626000062/unh-20251231.htm) |

## What it sells

| Product or service | Use and users |
| --- | --- |
| UnitedHealthcare | Health benefit plans receive premiums or service fees. Claims and medical costs determine how much of premium revenue is available for other uses. |
| Optum Health | Provider and care-delivery businesses serve patients under fee-based and risk-bearing arrangements. |
| Optum Rx | Pharmacy benefit management, dispensing and related services support health plans and plan sponsors. |
| Optum Insight | Data, software, analytics and administrative services support healthcare organizations. Intersegment sales must be eliminated at the consolidated level. |

| Reporting period | Company operating update |
| --- | --- |
| 2026 Q3 | The medical care ratio was 88.4%. It measures medical costs as a share of premium revenue. [Company results or filing](https://www.sec.gov/Archives/edgar/data/731766/000073176626000255/earningsrelease3q26unh.htm) |

## Who buys it

Employers, public programs and individuals buy health benefits. Providers, payers and plan sponsors also contract for Optum services.

## The numbers

### Annual consolidated results

| USD billion | 2023-12-31 | 2024-12-31 | 2025-12-31 |
| --- | --- | --- | --- |
| Revenue | 371.622 | 400.278 | 447.567 |
| Operating income | 32.358 | 32.287 | 18.964 |
| Operating margin (calculated) | 8.7% | 8.1% | 4.2% |
| Net income attributable to the parent | 22.381 | 14.405 | 12.056 |

### Reported business lines

| USD billion | 2023-12-31 | 2024-12-31 | 2025-12-31 |
| --- | --- | --- | --- |
| UnitedHealthcare | 281.36 | 298.208 | 344.903 |
| OptumRx | 116.087 | 133.231 | 154.726 |
| OptumHealth | 95.319 | 105.358 | 101.957 |
| OptumInsight | 18.932 | 18.757 | 19.417 |
| Corporate Non | -136.373 | -150.887 | -167.956 |
| Intersegment Elimination | -3.703 | -4.389 | -5.48 |

### Revenue by product or service

| USD billion | 2023-12-31 | 2024-12-31 | 2025-12-31 |
| --- | --- | --- | --- |
| Product | 42.583 | 50.226 | 53.38 |
| Service | 34.123 | 36.04 | 38.038 |

[10-K](https://www.sec.gov/Archives/edgar/data/731766/000073176626000062/unh-20251231.htm)

### Consolidated results for individual quarters

| USD billion | 2025-06-30 | 2025-09-30 | 2025-12-31 | 2026-03-31 | 2026-06-30 | 2026-09-30 |
| --- | --- | --- | --- | --- | --- | --- |
| Revenue | 111.616 | 113.161 | 113.215* | 111.721 | 112.032 | 112.694 |
| Operating income | 5.15 | 4.315 | 0.38* | 8.99 | 7.991 | 6.563 |
| Operating margin (calculated) | 4.6% | 3.8% | 0.3% | 8.0% | 7.1% | 5.8% |
| Net income attributable to the parent | 3.406 | 2.348 | 0.01* | 6.28 | 5.484 | 4.11 |

\* A marked quarter was calculated by subtracting the earlier cumulative amount.

### Annual consolidated cash flow

| USD billion | 2023-12-31 | 2024-12-31 | 2025-12-31 |
| --- | --- | --- | --- |
| Cash from operations | 29.068 | 24.204 | 19.697 |
| Purchases of property, plant and equipment | 3.386 | 3.499 | 3.622 |
| Share repurchases | 8 | 9 | 5.545 |
| Cash dividends | 6.761 | 7.533 | 7.916 |

### Consolidated year-to-date comparison

| USD billion | 2025-01-01 – 2025-09-30 | 2026-01-01 – 2026-09-30 |
| --- | --- | --- |
| Revenue | 334.352 | 336.447 |
| Operating income | 18.584 | 23.544 |
| Net income attributable to the parent | 12.046 | 15.874 |
| Cash from operations | 18.589 | 25.087 |
| Purchases of property, plant and equipment | 2.674 | 2.421 |
| Share repurchases | 5.545 | 5.031 |
| Cash dividends | 5.914 | 6.17 |

## Its place in the sector

UnitedHealthcare provides coverage. Optum Rx administers pharmacy networks and formularies. These are distinct roles inside the same group.

## Where to look in the filing

Item 1 of Form 10-K describes the business and its customers. Item 7 explains changes in results. Item 8 contains the consolidated statements and segment notes. In Form 10-Q, the starting and ending dates distinguish a quarter from fiscal year to date.

A subtotal can include the product lines beneath it. Segment, product and geographic views may describe the same underlying sales.

## Sources

- [10-K](https://www.sec.gov/Archives/edgar/data/731766/000073176626000062/unh-20251231.htm) · 2026-03-02
- [10-Q](https://www.sec.gov/Archives/edgar/data/731766/000073176626000266/0000731766-26-000266-index.htm) · 2026-11-03
- [Company results or filing](https://www.sec.gov/Archives/edgar/data/731766/000073176626000255/earningsrelease3q26unh.htm) · 2026-10-13
- [Filing cover](https://www.sec.gov/Archives/edgar/data/731766/000073176626000197/unh-20260630.htm) · 2026-08-10
- [10-K](https://www.sec.gov/Archives/edgar/data/731766/000073176626000062/0000731766-26-000062-index.htm) · 2026-03-02
- [10-Q](https://www.sec.gov/Archives/edgar/data/731766/000073176626000197/0000731766-26-000197-index.htm) · 2026-08-10
- [10-Q](https://www.sec.gov/Archives/edgar/data/731766/000073176626000127/0000731766-26-000127-index.htm) · 2026-05-05
- [SEC company facts (XBRL)](https://data.sec.gov/api/xbrl/companyfacts/CIK0000731766.json)

Original sources checked November 26, 2026 · [1](https://www.sec.gov/Archives/edgar/data/731766/000073176626000062/unh-20251231.htm) · [2](https://www.sec.gov/Archives/edgar/data/731766/000073176626000197/unh-20260630.htm) · [3](https://www.sec.gov/Archives/edgar/data/731766/000073176626000255/earningsrelease3q26unh.htm)
