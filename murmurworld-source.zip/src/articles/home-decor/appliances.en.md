We ended up buying five Samsung appliances together at a department store, with help from appliance specialist Seo Gyeong-deok (서경덕 명장). We bought a refrigerator, a washer-dryer, a water purifier, a robot vacuum, and an air purifier. The store’s quote came in well below the combination I’d priced online. The washer-dryer also opens its door when the drying cycle ends. I liked the idea of having one less thing to remember. [Samsung washer-dryer product guide](https://www.samsung.com/sec/laundry-combo/combo-wd90h25ahy-d2c/WD90H25AHY/)

## What the department store quote made me reconsider

I started with a mix of brands. I was looking at an LG refrigerator, a Samsung washer-dryer and water purifier, and a robot vacuum from another brand. Different products caught my eye, so I kept a shortlist for each appliance. Once the department store gave me a quote for all five, I could compare that total with what I’d pay for the appliances I’d picked individually.

I began thinking in terms of **what it costs to get each appliance installed and ready to use at home**. When comparing prices for the same appliance, I match the whole model number, including the suffix. When the models differ, I put the features I’ll actually use side by side. It helps to note what delivery and installation cover, which requirements apply to card or gift certificate offers, and whether a subscription adds a separate monthly payment.

## How far the refrigerator sticks out matters as much as its capacity

The first refrigerator I considered was an 834 L LG. We ended up going with a 609 L Samsung Kitchen Fit. The grade 1 LG was rated at 37.95 kWh per month, and the grade 2 Samsung at 38.5 kWh per month. I’d expected the ratings to translate into a bigger gap, but the difference on the labels was just 0.55 kWh a month. After that, I started writing down the monthly energy figure alongside the grade. [Korea Energy Agency listing for the LG refrigerator](https://eep.energy.or.kr/certification/certi_view_252.aspx?no=252250342&page=1) · [Samsung refrigerator specifications](https://www.samsung.com/sec/support/model/RM80H64S2A/)

Figuring out whether it would fit meant getting out the tape measure. I needed the width, height, and depth of the cabinet opening and enough space to open the refrigerator doors fully. The Kitchen Fit gave us a shallower option, and the one we chose was still 912 mm wide. Before settling on a model, it was worth checking the front door and elevator as well as the cabinet. [Refrigerator installation guide](https://www.lge.co.kr/story/setup-guide/refrigerator-installation-guide)

## I started with the laundry room when choosing the washer

We couldn’t easily stack a dryer over the washing machine in our home, so we chose a machine that does both. Our model washes up to 25 kg and dries up to 20 kg. The two limits can differ on the same machine. Both are worth checking if you wash bedding often or do your laundry in big loads. If the automatic door matters to you, look it up by model number. Products that share the combo name can have different features. [Samsung washer-dryer specifications](https://www.samsung.com/sec/support/model/WD90H25AHY/)

Even with plenty of floor space, a machine has to fit through the laundry room door. It’s easier to compare models if you write down the threshold and narrowest point along the delivery route, along with the water inlet, the drain, and the space behind the machine for hoses. [Washer and dryer installation guide](https://www.lge.co.kr/story/setup-guide/washer-installation-guide)

## We checked the air conditioners that were already there

Our home came with two ceiling-mounted air conditioners, so we left them out of the appliance quote. Before moving in, we wanted to see which rooms had a unit, whether they worked, and what needed cleaning.

If I were buying new units, I’d start with the floor area of each room I actually want to cool. I’d also check where the outdoor unit can go, whether the lines are already in place, and how much drilling or extending those lines would add to the quote. [Air conditioner buying guide](https://www.lge.co.kr/story/buying-guide/lg-air-conditioner) · [Air conditioner installation guide](https://www.lge.co.kr/story/user-guide/air-conditioners-install-guide)

## A closer look at each appliance

The refrigerator post covers how we went from considering 834 L to choosing the 609 L Kitchen Fit and which measurements are easy to miss. After that, I’ll write about choosing between separate laundry appliances and a combo. Finally, I’ll cover what to check when you move into a home with air conditioning already installed, and what to check when you need to install it yourself.

[Why We Chose a 609 L Kitchen Fit Max Fridge After Considering an 834 L Model](/en/blog/home/decor/refrigerator/)

[Estimate monthly electricity use for the appliances we chose](/en/blog/home/decor/power-draft/)
