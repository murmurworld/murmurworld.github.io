We ended up choosing a custom sofa for our first home. We started out looking at light-colored modular fabric sofas. Then we sat on the Monocus Leel at the I’Park Mall showroom, and the feel of the leather and goose-feather cushions stayed with me. We still wanted a light color, and now we had a different material in mind. [Monocus Leel](https://monocus.co.kr/product/?idx=3)

## Working Around the Dining Table

We were keeping our dining table, so imagining the sofa on its own made the living room seem more spacious than it was. At first, we looked for sofas about two meters wide. Even at the same width, a deep seat or a chaise that extended into the room could cut into the space we needed to pull out a dining chair.

A sofa also needs a clear route into the living room. For a modular sofa, it helps to write down **the packaged dimensions of the largest module** alongside the overall width. Measure the front door and elevator openings, and check whether the box can make it around any tight corners in the hallway. If you use a robot vacuum, ask how much clearance there is at the lowest point underneath the sofa as well as how tall the legs are. [IKEA’s guide to bringing large furniture home](https://www.ikea.com/kr/ko/customer-service/knowledge/articles/01101dc3-3458-40ef-g74c-c7g653ddd6f6.html)

## Fabric and Leather Raised Different Questions

One fabric option we liked was IKEA’s JÄTTEBO. The off-white bouclé cover comes off for washing, and replacement covers are sold separately for some modules. At first, I pictured how a light sofa would look in the room. As we compared options, I started thinking about how I’d clean up a spilled drink. [IKEA’s off-white JÄTTEBO cover](https://www.ikea.com/kr/ko/p/jaettebo-cover-1-5-seat-module-with-storage-axvall-off-white-50622370/)

With ivory leather, I wanted to know how to handle dye transfer from jeans and how different leather types and finishes would behave in the same color. If you like the feel of goose-feather cushions, it’s worth asking how to care for them once they compress with use and what repairs or warranty coverage are available.

## What I’d Put in Writing for a Custom Order

If we were choosing a sofa again, I’d pull the dining chairs back far enough to sit in them and measure the walkway before visiting a store. At the showroom, I’d spend a little time sitting the way I normally do at home. Once I found a sofa I liked, I’d check these details on the order form.

- **Size and orientation.** Confirm the overall width and depth, which side the chaise goes on if there is one, and the actual clearance underneath.
- **Materials and care.** Record the name and color of the leather or fabric, how to clean stains, how to care for the cushions, and what repairs are covered.
- **Delivery and production.** Find out whether it can come in sections, how large the biggest package is, when it will arrive, what delivery costs, and how long you have to change the order.

Trying the sofa helped me understand why I wanted a different material. Picturing it at home reminded me why the tape measure mattered. I’m glad we did both.
