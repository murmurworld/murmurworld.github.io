**After our next move, we want to put a kimchi refrigerator next to our main fridge.** We started by looking at an 834 L LG. Once we pictured the two appliances side by side in our next kitchen, the shallower 609 L Samsung Kitchen Fit Max made more sense to us. We asked for one quote for five appliances at the Samsung counter in a department store and ordered the fridge with the rest.

## Why 834 L appealed to us at first

The LG **S834MQQ111** was the side-by-side refrigerator we liked best early on. It came in the light finish we wanted, had a roomy freezer, and earned grade 1 under Korea’s energy efficiency rating system. The Korea Energy Agency lists it at 834 L, while LG’s product page says 832 L. With two different numbers for the same fridge, it was easier to look it up by the full model number.

## The biggest change was the depth

| What we compared | LG S834MQQ111 | Samsung RM80H64S2A |
| --- | --- | --- |
| Total capacity (manufacturer / agency) | 832 L / 834 L | 609 L / 611.5 L |
| Freezer capacity | 308 L | 233 L |
| Width × height × depth | 913 × 1,790 × 913 mm | 912 × 1,853 × 683 mm |
| Korean energy efficiency grade | Grade 1 | Grade 2 |
| Monthly electricity use (manufacturer) | 40.2 kWh | 38.5 kWh |
| Monthly electricity use (agency listing) | 37.95 kWh | 36.13 kWh |

Dimensions are from the manufacturers. Samsung’s measurements exclude the rear handle. [LG specifications](https://www.lge.co.kr/product/refrigerators/s834mqq111) · [Samsung specifications](https://www.samsung.com/sec/support/model/RM80H64S2A/) · [Korea Energy Agency listing for LG](https://eep.energy.or.kr/certification/certi_view_252.aspx?no=252250342&page=1) · [Korea Energy Agency listing for Samsung](https://eep.energy.or.kr/certification/certi_view_252.aspx?no=252260150&page=1)

The Samsung was **23 cm shallower**, only **1 mm narrower**, and 63 mm taller. The depth mattered most to us when we pictured how far the fridge would stick out with a kimchi refrigerator beside it.

Samsung’s example for this model on its own shows **4 mm on each side and 20 mm above**. Add 4 mm on either side of the 912 mm fridge, and the opening in that example works out to 920 mm wide. Once we pick a kimchi refrigerator, we’ll check the space for both models and their required clearances, along with the location of the outlets. We’ll also need room to open both appliances and pull their drawers all the way out. [Samsung Kitchen Fit Max product and installation details](https://www.samsung.com/sec/refrigerators/french-door-rm80h64s2a-d2c/RM80H64S2A/)

## Storage and electricity use

Going smaller took us from **308 L of freezer space to 233 L**, a drop of 75 L. If you tend to stock up on frozen food or store big containers, it’s worth comparing freezer capacity on its own and checking the width inside the drawers at the store.

The two fridges were **less than 2 kWh a month apart** when we compared the manufacturers’ figures and, separately, the agency figures. For us, the depth mattered more. The calculator below uses Samsung’s figure of 38.5 kWh per month. Electricity use at home can vary with the temperature setting and how the fridge is used.

[Try our monthly appliance electricity calculator draft](/en/blog/home/decor/power-draft/)

## What I’d take to the store next time

- **Cabinet opening** — The narrowest width, the height to the overhead cabinet, and the depth once you account for the outlet behind the fridge.
- **Space in front** — Check whether the door clears the wall or cabinets and whether you can remove the drawers and shelves with the door open.
- **Delivery route** — Measure the front door, the elevator door and interior, and any tight turns in the hallway.
- **The quote** — Ours covered five appliances. If I were shopping for just a fridge, I’d ask for the price on its own and what delivery and installation would cost.

If I were starting over, I’d sketch out where the fridge and kimchi refrigerator would go before searching by capacity.

[Previous post · Why We Bought Our Appliances at a Department Store](https://murmurworld.github.io/en/blog/home/decor/appliances/)
