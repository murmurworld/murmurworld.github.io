import datetime as dt
import importlib.util
from pathlib import Path
from unittest import TestCase

from publisher_news import article_metadata, feed_articles, search_articles

script=Path(__file__).with_name("refresh-market-news.py")
spec=importlib.util.spec_from_file_location("market_news",script)
news=importlib.util.module_from_spec(spec)
spec.loader.exec_module(news)
scope=news.scopes(script.parents[1])
now=dt.datetime(2026,11,28,tzinfo=dt.timezone.utc)
cutoff=now-dt.timedelta(days=28)


class NewsSelectionTest(TestCase):
    def test_confusable_names_prices_and_unrelated_incidents(self):
        cases={
            "c:SCCO":["Great Southern Copper plc (LON: GSCU) Corporate Presentation","CAE earmarks three southern copper-gold targets"],
            "c:005930":["Samsung Electro-Mechanics, Nvidia to expand cooperation on AI chip components"],
            "c:LRCX":["Is Lam Research Corporation (LRCX) Oversold as Strong AI Drives Capex?"],
            "c:AVGO":["Broadcom plunges nearly 8% amid an AI selloff",
                      "Broadcom Loses $191 Billion After Report Of Google TPU Order Cuts"],
            "s:ME":["Cal-Maine halts egg production at Florida plant after bird flu outbreak"],
            "s:GA":["Man kidnapped in South Carolina slipped note to Georgia workers asking for help, police say",
                    "Georgia-Pacific expands manufacturing in Alabama","Tbilisi hopes to grow Georgia’s trade"],
            "s:DC":["New DC power equipment helps expand data centers"],
        }
        for key,titles in cases.items():
            for title in titles:
                with self.subTest(key=key,title=title):
                    self.assertFalse(news.relevant(key,scope[key],title,"Industry News"))

    def test_precise_named_business_events_remain(self):
        examples={"c:SCCO":"Southern Copper Kicks Off Early Works at El Pilar Copper Project",
                  "c:005930":"Samsung Electronics names new heads of memory, mobile businesses",
                  "c:LRCX":"Lam Research expands semiconductor production facility",
                  "c:AVGO":"Broadcom and VMware introduce networking platform for private cloud",
                  "s:ME":"Maine state government expects to see modest tax revenue growth",
                  "s:GA":"Georgia Ports Authority Backs Union Pacific-Norfolk Southern Merger"}
        for key,title in examples.items():
            with self.subTest(key=key):
                self.assertTrue(news.relevant(key,scope[key],title,"Industry News"))

    def test_only_current_dated_direct_publisher_articles_survive(self):
        xml=b"""<rss><channel><item><title>Texas factory expands production</title><link>https://www.cnbc.com/2026/11/25/factory.html</link><pubDate>Wed, 25 Nov 2026 11:00:00 GMT</pubDate></item></channel></rss>"""
        rows=feed_articles(xml,"CNBC","cnbc.com",cutoff,now)
        self.assertEqual(len(rows),1)
        self.assertEqual(news.merge(rows,cutoff,now,"s:TX",scope["s:TX"]),rows)
        for replacement in ["news.google.com","www.cnbc.com.example.org","user@www.cnbc.com","127.0.0.1"]:
            self.assertEqual(feed_articles(xml.replace(b"www.cnbc.com",replacement.encode()),"CNBC","cnbc.com",cutoff,now),[])
        self.assertEqual(feed_articles(xml.replace(b"25 Nov",b"25 Oct"),"CNBC","cnbc.com",cutoff,now),[])
        self.assertEqual(feed_articles(xml.replace(b"pubDate",b"updated"),"CNBC","cnbc.com",cutoff,now),[])
        self.assertEqual(news.merge([{**rows[0],"source":"Another newspaper"}],cutoff,now,"s:TX",scope["s:TX"]),[])

    def test_secondary_search_requires_original_matching_date_title_and_url(self):
        title="Texas factory expands production"
        direct="https://www.cnbc.com/2026/11/25/factory.html"
        r=(f'<rss><channel><item><title>{title}</title><link>https://www.bing.com/news/apiclick.aspx?url={direct}</link>'
           '<pubDate>Wed, 25 Nov 2026 11:00:00 GMT</pubDate></item></channel></rss>').encode()
        query,direct,reported=list(search_articles(r))[0]
        html=(f'<meta property="og:title" content="{title}"><meta property="article:published_time" content="2026-11-25T07:15:00-05:00">'
              f'<link rel="canonical" href="{direct}">').encode()
        self.assertEqual(article_metadata(html,direct,query,reported,cutoff,now)["date"],"2026-11-25T12:15:00Z")
        for bad in (html.replace(b"published_time",b"modified_time"),html.replace(b"Texas factory",b"Football championship"),
                    html.replace(b"2026-11-25T",b"2018-11-25T"),html.replace(b"www.cnbc.com",b"example.com")):
            self.assertIsNone(article_metadata(bad,direct,query,reported,cutoff,now))
