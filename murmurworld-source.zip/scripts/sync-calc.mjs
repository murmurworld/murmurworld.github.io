// 계산기 정본(C:\dev\elec-calc)을 복사한다. 실행: pnpm sync-calc
import { cpSync, mkdirSync } from 'node:fs';
import { resolve } from 'node:path';
const src = resolve('C:/dev/elec-calc');
const dst = resolve('public/calc');
mkdirSync(dst, { recursive: true });
const page = resolve('src/calc');
mkdirSync(page, { recursive: true });
cpSync(resolve(src, 'index.html'), resolve(page, 'index.html'));
for (const f of ['app.js', 'style.css']) cpSync(resolve(src, f), resolve(dst, f));
mkdirSync(resolve(dst, 'data'), { recursive: true });
for (const f of ['tariff.json', 'appliances.json', 'appliances.csv']) cpSync(resolve(src, 'data', f), resolve(dst, 'data', f));
console.log('calc synced ->', dst);
