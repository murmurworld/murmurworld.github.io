// 계산기 정본(C:\dev\elec-calc)을 복사한다. 실행: pnpm sync-calc
import { cpSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { addHouseholdAppliances, householdAppliances } from '../src/site/household-power.mjs';

const src = resolve('C:/dev/elec-calc');
const dst = resolve('public/calc');
mkdirSync(dst, { recursive: true });
const page = resolve('src/calc');
mkdirSync(page, { recursive: true });
cpSync(resolve(src, 'index.html'), resolve(page, 'index.html'));
for (const f of ['app.js', 'style.css']) cpSync(resolve(src, f), resolve(dst, f));
mkdirSync(resolve(dst, 'data'), { recursive: true });
cpSync(resolve(src, 'data/tariff.json'), resolve(dst, 'data/tariff.json'));

const database = JSON.parse(readFileSync(resolve(src, 'data/appliances.json'), 'utf8'));
const combined = addHouseholdAppliances(database);
writeFileSync(resolve(dst, 'data/appliances.json'), JSON.stringify(combined, null, 1) + '\n');

const csv = readFileSync(resolve(src, 'data/appliances.csv'), 'utf8').trimEnd();
const columns = csv.split(/\r?\n/, 1)[0].replace(/^\uFEFF/, '').split(',');
const addedIds = new Set(householdAppliances.map(({ id }) => id));
const csvCell = (value) => `"${String(value ?? '').replaceAll('"', '""')}"`;
const addedRows = combined.items
  .filter(({ id }) => addedIds.has(id))
  .map((row) => columns.map((column) => csvCell(row[column])).join(','));
writeFileSync(resolve(dst, 'data/appliances.csv'), [csv, ...addedRows].join('\n') + '\n');

console.log('calc synced ->', dst);
