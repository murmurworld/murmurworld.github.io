"""Collect original headline, publisher, date and outbound link for each map selection."""
import argparse
import concurrent.futures
import datetime as dt
import email.utils
import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import urllib.error
import xml.etree.ElementTree as ET
from pathlib import Path
from publisher_news import FEEDS, article_metadata, as_date, feed_articles, publisher, search_articles

UTC = dt.timezone.utc
MAX_AGE = 28
MAX_ITEMS = 3
PUBLIC_URL = "https://murmurworld.github.io/data/market-news.json"
INDUSTRY = re.compile(
    r"\b(?:econom(?:y|ic)|manufactur|factor(?:y|ies)|plants?\b|jobs?\b|employment|hiring|hired|"
    r"unemployment|layoffs?|workers?|workforce|business|compan(?:y|ies)|industrial|industry|industries|"
    r"exports?|trade|tariffs?|ports?\b|labor|labour|commerce|invest(?:s|ment|ing)?|expan(?:d|sion)|"
    r"semiconductors?|chips?\b|data cent(?:er|re)|energy|electricity|utilities|retail|housing|"
    r"construction|farms?\b|farmers?|agriculture|mining|tourism|airlines?|airport|highway|railroads?|"
    r"hospital|health care|healthcare|bank(?:s|ing)?\b|tax(?:es)?\b|small firms?|broadband|logistics|"
    r"power grid|transportation|affordab|labor force|supply chain|shipyard|production|revenue|"
    r"insurance|gas prices?|oil prices?|renewables?|steel|warehouse|budget|electric vehicles?|export)")
NOISE = re.compile(r"\b(?:target price|price targets?|stocks? to (?:buy|sell|watch)|buy the dip|"
    r"should you buy|stock forecasts?|stock predictions?|motley fool|earnings per share estimate|"
    r"unusual options|wall street thinks|stocks? (?:soars?|surges?|sinks?|plunges?|jumps?|rises?|"
    r"falls?|slides?|drops?|tumbles?)|shares? (?:soars?|surges?|sinks?|plunges?|jumps?|rises?|falls?|"
    r"slides?|drops?|tumbles?)|invests? in .* shares|buy ratings?|stock alerts?|stock movers?|"
    r"black friday deals?|cyber monday deals?|predictions? and (?:picks|odds)|fantasy football|"
    r"parlay|ncaa|touchdown|giveaway|promo code|coupon code|stream the game|horoscope)\b")
LOW_SIGNAL = re.compile(r"\b(?:zacks|marketbeat|tipranks|ticker report|stock titan|marketscreener|"
    r"gurufocus|stocktwits|simply wall st|benzinga|investingchannel|stockscan|tradingview|"
    r"ainvest|barchart|finviz|defense world|insider monkey|marketwatch guides|seeking alpha|motley fool|"
    r"24/7 wall st|trefis|investing\.com|sports illustrated|sporting news|instagram|facebook|msn|"
    r"pinterest|tiktok|threads|youtube|tradingnews|tip ranks|stock analysis|yahoo sports|kalkine|wisevoter|"
    r"spotrac|fansided|dawn of the dawg|newsbreak|music mayhem|superpower daily|streetinsider|tokenpost|"
    r"finimize|proactive financial news|onesafe|the dis|defense world|globe and mail investing)\b")
ESTABLISHED = re.compile(r"\b(?:reuters|ap news|associated press|bloomberg|financial times|wall street journal|"
    r"new york times|washington post|the economist|nikkei|cnbc|bbc|npr|pbs|public radio|stateline|business journals|"
    r"semiconductor engineering|ieee|ee times|fierce pharma|fierce biotech|utility dive|industry dive|"
    r"reuters|s&p global|american banker|banking dive|retail dive|supply chain dive|techcrunch|the verge|"
    r"korea herald|korea times|yonhap|channel newsasia|economic development|department of|bureau of|"
    r"federal reserve|sec\.gov|census\.gov|governor|office of|public media|government|newsroom)\b")
EXTRA_NOISE = re.compile(r"\b(?:price prediction|predictions?|etfs?|funds? (?:bought|sold)|shareholders?|"
    r"analyst targets?|target despite|selloff|sell-off|on watch|upgrade[sd]?|downgrade[sd]?|market cap|"
    r"market value|remains a buy|at buy|beat the market|earnings report\?|why is .* (?:up|down)|"
    r"attractive investment|investment could be worth|ten ?bagger|trims? .*loss|taking profits|perpetual contracts|"
    r"^(?:what’s|what's) next for|\bform [34]\b|rally|year-to-date|halftime|playbooks?|"
    r"gophers|glenn schumann|recruiting class|unfinished business|order of business|kickoff|kick-off|"
    r"surf cam|personnel file|tee times|draft picks?|enters transfer portal|in the portal)\b")
EDITORIAL_NOISE = re.compile(r"\b(?:stocks?|shares?|investors?|dividends?|traders?|ratings?|ticker|valuation|undervalued|overvalued|"
    r"upside|downside|fair value|pre[- ]market|wall street|nasdaq|nyse|surprise earnings|ipo buy|insider (?:sale|buy)|"
    r"earnings call transcript|bargain|black friday|cyber monday|best deals|gift guide|shopping list|store hours|"
    r"saved? up to|last chance|promo codes?|vs\.?|price prediction|price forecast|surf report|surf forecast|"
    r"net worth|career paths?|job postings?|job seekers?|now hiring|onlyfans|small business saturday|"
    r"game day|football|basketball|key match|win streak|head coach|quarterback|playoff|touchdown|sportsbook)\b")
COMPANY_EVENT = re.compile(r"\b(?:manufactur|produ(?:ct|ce)|suppl|customer|contract|agreem|deal|"
    r"partne|collab|acqui|merg|sell|sold|sale|buy(?:s|ing)?\b|invest|spend|launch|releas|introduc|"
    r"operat|facilit|open|clos(?:e|ing|ur)|expand|expans|approv|regulat|antitrust|competi|test|trial|"
    r"research|licens|lawsuit|sue[ds]?\b|settle|court|judg|investigat|ban\b|reject|permit|"
    r"delay|disrupt|secur|train|traini|workforce|hire|hiring|layoff|lay off|job cut|worker|union|employee|"
    r"chair|chief|ceo|appoint|resign|leadership|restructur|recall|shortage|profit|revenu|earnings|"
    r"financing|order|outage|breach|cyber|seiz|deploy|ship|construct|build|project|repair|"
    r"plant\b|factory|chip|semiconductor|foundry|hbm\b|dram\b|cloud|drug\b|clinical|fda\b|"
    r"pipeline|refiner|mine\b|copper|steel|lithium|aircraft|airline|carrier|credit card|payment|"
    r"oil field|banking|data cent|advertis|network|subscrib|customer|electric vehicle|production|storage|"
    r"program|programme|funding|approach|service|announc|business|factory|bottl|smartphone)")
COMPANY_QUERY = "production OR business OR launch OR supply OR contract OR acquires OR partnership OR sales"
NEGATIVE_QUERY = " -stock -stocks -shares -dividend -nasdaq"
ALIASES = {
    "TSM": ["TSMC", "Taiwan Semiconductor Manufacturing"], "005930": ["Samsung Electronics", "Samsung"],
    "000660": ["SK hynix", "SK Hynix"], "META": ["Meta Platforms", "Meta"],
    "GOOGL": ["Alphabet", "Google"], "PM": ["Philip Morris"], "BRK.B": ["Berkshire Hathaway"],
    "JPM": ["JPMorgan", "JP Morgan", "JPMorgan Chase"], "CRCL": ["Circle Internet Group", "Circle"],
    "PG": ["Procter and Gamble", "Procter & Gamble", "P&G"], "V": ["Visa"],
    "055550": ["Shinhan Financial", "Shinhan Bank"], "105560": ["KB Financial", "Kookmin Bank"],
    "TMUS": ["T-Mobile"], "MRK": ["Merck"], "UNH": ["UnitedHealth", "UnitedHealthcare"],
    "LLY": ["Eli Lilly", "Lilly"], "XOM": ["ExxonMobil", "Exxon Mobil", "Exxon"],
    "SHEL": ["Shell"], "KLAC": ["KLA Corporation", "KLA"], "RTX": ["RTX", "Raytheon"],
    "JNJ": ["Johnson & Johnson", "Johnson and Johnson", "J&J"], "TXN": ["Texas Instruments"],
    "BHP": ["BHP", "BHP Group"], "ORCL": ["Oracle"], "SPCX": ["SpaceX"],
}
QUALIFIER = {
    "V": "payments OR card OR Visa Inc", "CRCL": "stablecoin OR USDC OR fintech",
    "SHEL": "oil OR energy OR LNG", "CAT": "machinery OR Caterpillar Inc OR equipment",
    "META": "technology OR Facebook OR AI", "RTX": "aerospace OR defense OR Raytheon",
    "AAPL": "Apple Inc OR iPhone OR technology", "KLAC": "semiconductor OR chip",
    "STT": "bank OR asset management OR State Street Corporation", "005930": "electronics OR chip OR phone",
    "MRK": "Merck & Co OR Keytruda OR MSD", "ORCL": "cloud OR database OR software",
}
AMBIGUOUS = {
    "V": r"pay(?:ment)?|card|merchant|transaction|debit|credit|visa inc|fintech|mastercard",
    "CRCL": r"stablecoin|usdc|fintech|token|crypto|circle internet|digital asset",
    "SHEL": r"oil|energy|gas|lng|refin|petrol|wind|fuel|drill|pipeline|shell plc|offshore|renewable",
    "CAT": r"machin|equipment|construct|excavator|mining|engine|caterpillar inc|truck|factory|power",
    "META": r"facebook|whatsapp|instagram|zuckerberg|meta platforms|quest|data cent|\bai\b|ads?\b|tech|social media|smart glasses|oversight|reality labs",
    "RTX": r"defen[cs]e|aerospace|raytheon|pratt|missile|aircraft|engine|aviation|collins|radar",
    "AAPL": r"iphone|ipad|macbook|imac|app store|tech|siri|ios|apple inc|tim cook|airpods|vision pro|smartphone|apple watch|apple pay|apple tv|apple music|ipados|macos|apple intelligence|\bai\b",
    "KLAC": r"chip|semiconductor|wafer|process control|kla corp",
    "STT": r"bank|asset|etf|custod|fund|state street corp|invest",
    "005930": r"electronics|chip|smartphone|galaxy|semiconductor|memory|foundry|display|phone|hbm|nand|appliance",
    "MRK": r"merck & co|merck and co|keytruda|msd|gardasil|rahway|pembrolizumab|sotatercept|winrevair",
    "ORCL": r"oracle corp|oracle cloud|database|software|cloud|data cent|larry ellison|\boci\b|\bai\b",
}
STATE_QUERY = {"WA": '"Washington state" OR "Washington economy"', "DC": '"Washington D.C." OR "District of Columbia"', "GA": '"Georgia" -Tbilisi -Caucasus -Georgian', "NY": '"New York"'}
STATE_ALIASES = {"WA": ["Washington state", "state of Washington", "Washington economy", "Seattle", "Tacoma", "Spokane"],
    "DC": ["Washington D.C.", "Washington DC", "District of Columbia", "D.C.", "DC"],
    "NY": ["New York", "NYC"], "GA": ["Georgia", "Atlanta", "Port of Savannah"]}
TOPIC_WORDS = "economy OR jobs OR manufacturers OR industry OR business OR energy OR employment OR factory"


def norm(s):
    return " ".join(re.sub(r"[^\w]+", " ", unicodedata.normalize("NFKC", s).casefold()).split())


def scopes(site):
    directory = site / "src/site"
    groups = json.loads((directory / "market-directory.json").read_text("utf-8"))
    shapes = json.loads((directory / "market-us-shapes.json").read_text("utf-8"))
    result = {}
    for state in shapes:
        code, name = state["code"], state["en"]
        result["s:" + code] = (f'({STATE_QUERY.get(code, chr(34)+name+chr(34))}) ({TOPIC_WORDS})', STATE_ALIASES.get(code, [name]), True)
    for group in groups:
        if group["section"] != "companies":
            continue
        for item in group["items"]:
            ticker, name = item["ticker"], item["nameEn"]
            names = list(dict.fromkeys(ALIASES.get(ticker, [name])))
            phrase = " OR ".join(f'"{a}"' for a in names[:2])
            query = f"({phrase}) ({QUALIFIER.get(ticker,COMPANY_QUERY)})"+NEGATIVE_QUERY
            result["c:" + ticker] = (query, names, False)
    return result


def relevant(key, scope, title, source):
    _, aliases, state = scope
    raw, folded = title.casefold(), norm(title)
    if not any(" "+norm(a)+" " in " "+folded+" " for a in aliases):
        return False
    if NOISE.search(raw) or EDITORIAL_NOISE.search(raw) or EXTRA_NOISE.search(raw) or LOW_SIGNAL.search(source.casefold()):
        return False
    if re.search(r"\b(?:oversold|overbought|sell[ -]?off|short squeeze|bear market|bull run|dead.cat bounce|"
                 r"technical indicator|relative strength index|record (?:high|low)|new highs?|"
                 r"price action|bearish|bullish|options flow|bargain hunting|market rout|52.week|"
                 r"pullback|share price|stock price|slump(?:s|ed)?|crash(?:es|ed)?|plung(?:e|es|ed)|"
                 r"(?:market|price|index) (?:tumbles?|drops?|surges?))\b",raw):
        return False
    if re.search(r"\b(?:loses?|lost|sheds?|shed|erases?|wipes?)\s+(?:over |nearly |about )?\$[\d,.]+\s*"
                 r"(?:bn|billion|trillion)\s+(?:after|as|amid|in (?:a day|one day|market value))\b",raw):
        return False
    if re.search(r"\b(?:kidnap\w*|abduct\w*|murder\w*|homicide|stabb(?:ed|ing)|rap(?:e|ed|ist)|"
                 r"missing (?:child|woman|man|teen)|shooting|serial killer|armed robbery)\b",raw):
        return False
    if key=="c:SCCO" and (re.search(r"\b(?:great southern copper|gscu|southern copper[- /]gold|southern copper targets?)\b",raw)
            or not re.search(r"\b(?:southern copper (?:corporation|corp)|scco)\b|\bsouthern copper(?:['’]s|\s+(?:to |plans |reports |opens |expands |starts |begins |kicks off |mine\b))",raw)):
        return False
    if key=="c:005930" and re.search(r"\bsamsung (?:electro[- ]?mechanics|sdi|sds|biologics|life insurance|fire|heavy industries|c&t|display|securities)\b",raw) and "samsung electronics" not in raw:
        return False
    if key=="s:ME" and "maine" not in re.sub(r"\bcal[- ]maine(?: foods)?\b","",raw):
        return False
    if key=="s:NY" and not re.search(r"\b(?:new york|nyc)\b", re.sub(r"\bnew york (?:times|post|life|stock exchange)\b","",raw)):
        return False
    if key=="s:GA" and re.search(r"\bgeorgia[- ]pacific\b",raw) and not any(w in raw for w in ("state of georgia","atlanta","savannah")):
        return False
    if key=="s:GA" and (re.search(r"\b(?:atlanta|savannah|georgia governor|state of georgia|georgia ports|peach state|georgia[- ]based)\b",raw)
            is None and source not in ("Georgia Public Broadcasting","The Atlanta Journal-Constitution","Office of the Georgia Governor")):
        return False
    if len(title)>185 or re.search(r"\b(?:investor presentation|target revisions?|early retirement|surf cam|game preview|upcoming conference)\b|^transcript:",raw):
        return False
    if re.search(r"\b(?:gift guide|holiday season|buying guide|review roundup|gadget deals|shopping deals|give back this|small business saturday)\b",raw):
        return False
    if key == "s:VA" and "west virginia" in raw and "virginia" not in raw.replace("west virginia",""):
        return False
    if key == "s:FL" and re.search(r"\b(?:rb|qb|gators|seminoles|recruit|linebacker)\b",raw):
        return False
    if key == "s:GA" and re.search(r"tbilisi|caucasus|georgian (?:government|dream|parliament)|eurasian", raw):
        return False
    if key == "s:WA" and re.search(r"washington,? d\.?c\.?|district of columbia", raw):
        return False
    if key == "s:DC" and re.search(r"washington state|washington commanders", raw):
        return False
    if key=="s:DC" and not re.search(r"\b(?:district of columbia|washington[ ,]+d\.?\s?c\.?|d\.?c\.? (?:mayor|council|metro|residents))\b",raw):
        return False
    if key == "c:V" and re.search(r"visa (?:applications?|rules?|status|sponsorship|holders?|processing|policy|restrictions?)|immigration|e-visa|travel visa|work visa|student visa|h-1b", raw):
        return False
    # Visa's mirrored archive has resurfaced its 2018 YellowPepper release with a new feed date.
    if key == "c:V" and re.search(r"visa (?:makes strategic investment in|to acquire|completes acquisition of) yellowpepper",raw):
        return False
    if key == "c:MRK" and re.search(r"merck kgaa|darmstadt|emd serono", raw):
        return False
    if key == "c:LIN" and re.search(r"material handling|kion group|forklift|warehouse|intralogistics|linde (?:hotel|lindstrom)",raw):
        return False
    if key == "c:CSCO" and re.search(r"andre cisco|cisco ave|cisco bay",raw):
        return False
    if state:
        return bool(INDUSTRY.search(raw))
    guard = AMBIGUOUS.get(key[2:])
    return bool(COMPANY_EVENT.search(raw)) and (not guard or bool(re.search(guard, raw)))


def merge(entries, cutoff, now, key, scope):
    unique, outlets, rows = set(), set(), []
    valid = []
    for row in entries:
        if not isinstance(row, dict) or not all(isinstance(row.get(k), str) for k in ("date","title","source","url")):
            continue
        try:
            date = dt.datetime.fromisoformat(row["date"].replace("Z", "+00:00"))
            within = cutoff <= date <= now
        except (TypeError, ValueError):
            continue
        outlet=publisher(row["url"])
        if (within and outlet and (row.get("publisherHost"),row["source"])==outlet
                and relevant(key,scope,row["title"],row["source"])):
            valid.append(row)
    def quality(row):
        outlet, title = row["source"].casefold(), row["title"].casefold()
        official = not scope[2] and any(norm(a)==norm(row["source"]) or norm(a)+" newsroom" == norm(row["source"]) for a in scope[1])
        # Give direct and established reports first pick; display the resulting items by date.
        days = (now - dt.datetime.fromisoformat(row["date"].replace("Z","+00:00"))).total_seconds()/86400
        return (5 if official else 3 if ESTABLISHED.search(outlet) else 0)+(1 if COMPANY_EVENT.search(title) else 0)-days/5
    for row in sorted(valid, key=quality, reverse=True):
        title, outlet = norm(row["title"]), norm(row["source"])
        words=set(title.split())
        if outlet in outlets or any(len(words & w)/max(len(words | w),1)>.75 for w in unique):
            continue
        unique.add(frozenset(words)); outlets.add(outlet); rows.append(row)
        if len(rows) == MAX_ITEMS:
            break
    return sorted(rows,key=lambda r:r["date"],reverse=True)


def urlencode_news(phrase,terms):
    return urllib.parse.urlencode({"q":"("+phrase+") ("+terms+")","format":"rss","qft":'interval="8"',
                                   "mkt":"en-US","setlang":"en-us","cc":"us"})


class PublisherRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if not publisher(newurl) or publisher(newurl)!=publisher(req.full_url):
            raise ValueError("Article redirected outside its publisher")
        return super().redirect_request(req,fp,code,msg,headers,newurl)


def request(url, limit=2_500_000, article=False):
    if article and not publisher(url):raise ValueError("Unrecognized article publisher")
    req = urllib.request.Request(url, headers={"User-Agent": "MurmurworldNews/1.0 (+https://murmurworld.github.io/stocks/)", "Accept": "application/rss+xml,application/json,*/*"})
    opener=urllib.request.build_opener(PublisherRedirect) if article else urllib.request.build_opener()
    with opener.open(req, timeout=10) as resp:
        body = resp.read(limit + 1)
    if len(body) > limit:
        raise ValueError("oversized response")
    return body


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--published-cache", action="store_true")
    ap.add_argument("--cache-only", action="store_true")
    args = ap.parse_args()
    site, now = args.site, dt.datetime.now(UTC)
    definitions, cutoff = scopes(site), now - dt.timedelta(days=MAX_AGE)
    dest = site / "public/data/market-news.json"
    caches = []
    def accept_cache(cache):
        if isinstance(cache,dict) and cache.get("version")==2 and isinstance(cache.get("topics"),dict):
            caches.append(cache)
    if dest.exists():
        accept_cache(json.loads(dest.read_text("utf-8")))
    if args.published_cache:
        try:
            accept_cache(json.loads(request(PUBLIC_URL)))
        except Exception as err:
            print(f"::warning::Published news snapshot unavailable ({type(err).__name__}). Using bundled publisher-verified headlines.")
    retrieved={}
    failed=[]
    if not args.cache_only:
        # Headlines from the publisher already carry its direct link and original RSS publication date.
        def collect(feed):
            label,host,feed_url=feed
            try: return feed_articles(request(feed_url),label,host,cutoff,now)
            except (OSError,ValueError,ET.ParseError) as err:
                reason="HTTP "+str(err.code) if isinstance(err,urllib.error.HTTPError) else type(err).__name__
                return label+" ("+reason+")"
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            feeds=list(pool.map(collect,FEEDS))
        # This publisher exposes separate state sections. Reuse the direct RSS dates and
        # links, and still demand a matching geographic name and an economic event.
        state_names=json.loads((site/"src/site/market-us-shapes.json").read_text("utf-8"))
        regional=sorted((s for s in state_names if s["code"]!="DC"),key=lambda s:s["code"])
        # National and industry feeds run daily. A regional section runs weekly so we
        # make at most eight additional requests a day to the same publisher.
        limited=any(isinstance(f,str) and f in ("The Center Square (HTTP 429)","The Center Square (HTTP 403)") for f in feeds)
        for state in ([] if limited else regional[now.date().toordinal()%7::7]):
            category=state["en"].lower().replace(" ","_")
            url="https://www.thecentersquare.com/search/?"+urllib.parse.urlencode(
                {"c":category,"f":"rss","t":"article","s":"start_time","sd":"desc"})
            result=collect(("The Center Square","thecentersquare.com",url))
            if isinstance(result,str):
                feeds.append(state["code"]+": "+result)
                if result.endswith(("(HTTP 429)","(HTTP 403)")):break
            else:feeds.append(result)
            time.sleep(1)
        direct=[item for rows in feeds if isinstance(rows,list) for item in rows]
        failed.extend(f for f in feeds if isinstance(f,str))
        checked_publisher=any(isinstance(rows,list) for rows in feeds)
        for key,scope in definitions.items():
            matches=[item for item in direct if relevant(key,scope,item["title"],item["source"])]
            if checked_publisher: retrieved[key]=matches

        def discover(pair):
            key,scope=pair
            if len({r["source"] for r in retrieved.get(key,[])})>=MAX_ITEMS:
                return key,[]
            # Discovery is separate from verification: search dates/URLs alone never become cards.
            phrase=" OR ".join('"'+name+'"' for name in scope[1][:2])
            terms=TOPIC_WORDS if scope[2] else COMPANY_QUERY
            options=urlencode_news(phrase,terms)
            try: results=list(search_articles(request("https://www.bing.com/news/search?"+options)))
            except (OSError,ValueError,ET.ParseError) as err:
                return key,type(err).__name__
            matches=[]
            checked=set()
            for search_title,direct_url,search_date in results:
                if len(checked)>=4 or len(matches)>=MAX_ITEMS:break
                if not search_date or not cutoff<=search_date<=now or direct_url in checked:continue
                if not relevant(key,scope,search_title,publisher(direct_url)[1]):continue
                checked.add(direct_url)
                try:
                    article=article_metadata(request(direct_url,article=True),direct_url,search_title,search_date,cutoff,now)
                except (OSError,ValueError,ET.ParseError):continue
                if article and relevant(key,scope,article["title"],article["source"]):matches.append(article)
            return key,matches
        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
            for key,found in pool.map(discover,definitions.items()):
                if isinstance(found,list):retrieved.setdefault(key,[]).extend(found)
                else:failed.append(key+" ("+found+")")
    result = {}
    for key,scope in definitions.items():
        candidates=list(retrieved.get(key,[]))
        checked=[]
        for cache in caches:
            previous=cache["topics"].get(key,{})
            if not isinstance(previous,dict):
                continue
            if isinstance(previous.get("items"),list):
                candidates.extend(previous["items"])
            if isinstance(previous.get("checked"),str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z",previous["checked"]):
                checked.append(previous["checked"])
        result[key]={"query":scope[0],"checked":now.strftime("%Y-%m-%dT%H:%M:%SZ") if key in retrieved else max(checked,default=None),
                     "items":merge(candidates,cutoff,now,key,scope)}
    stories=sum(len(v["items"]) for v in result.values())
    stamp=max((v['checked'] or '' for v in result.values()),default="")
    if not retrieved and not stories and not stamp:
        sys.exit("All feeds unavailable and/or no usable input. Leaving the published site in place.")
    if failed:
        print(f"::warning::{len(failed)} news sources or searches unavailable; used verified alternatives. "+", ".join(failed))
    covered=sum(bool(v['items']) for v in result.values())
    message=(f"Market news: {len(retrieved)} subjects checked; {len(result)} subjects; {stories} dated headlines, "
             f"{covered} subjects with relevant coverage.")
    print(message)
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"],"a",encoding="utf-8") as summary:
            summary.write(f"{message}\n\nFailed feed requests: {len(failed)}. Latest successful check: {stamp or 'none'}.\n")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp=dest.with_suffix(".tmp")
    tmp.write_text(json.dumps({"version":2,"maxAgeDays":MAX_AGE,"lastChecked":stamp,"topics":result},ensure_ascii=False,separators=(",",":"))+"\n","utf-8")
    tmp.replace(dest)


if __name__ == "__main__":
    main()
