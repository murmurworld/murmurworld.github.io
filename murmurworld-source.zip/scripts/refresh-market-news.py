"""Collect original headline, publisher, date and outbound link for each map selection."""
import argparse
import concurrent.futures
import datetime as dt
import email.utils
import json
import os
import re
import sys
import time
import unicodedata
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from pathlib import Path

UTC = dt.timezone.utc
MAX_AGE = 28
MAX_ITEMS = 3
GOOGLE = "https://news.google.com/"
PUBLIC_URL = "https://murmurworld.github.io/data/market-news.json"
INDUSTRY = re.compile(
    r"\b(?:econom(?:y|ic)|manufactur|factor(?:y|ies)|plants?\b|jobs?\b|employment|hiring|hired|"
    r"unemployment|layoffs?|workers?|workforce|business|compan(?:y|ies)|industrial|industry|industries|"
    r"exports?|trade|tariffs?|ports?\b|labor|labour|commerce|invest(?:s|ment|ing)?|expan(?:d|sion)|"
    r"semiconductors?|chips?\b|data cent(?:er|re)|energy|electricity|utilities|retail|housing|"
    r"construction|farms?\b|farmers?|agriculture|mining|tourism|airlines?|airport|highway|railroads?|"
    r"hospital|health care|healthcare|bank(?:s|ing)?\b|tax(?:es)?\b|small firms?|broadband|logistics|"
    r"power grid|transportation|affordab|labor force|supply chain|shipyard|production|revenue|"
    r"insurance|gas prices?|oil prices?|renewables?|steel|warehouse|budget|electric vehicles?|export)")
NOISE = re.compile(r"\b(?:target price|price targets?|stocks? to (?:buy|sell|watch)|buy the dip|"
    r"should you buy|stock forecasts?|stock predictions?|motley fool|earnings per share estimate|"
    r"unusual options|wall street thinks|stocks? (?:soars?|surges?|sinks?|plunges?|jumps?|rises?|"
    r"falls?|slides?|drops?|tumbles?)|shares? (?:soars?|surges?|sinks?|plunges?|jumps?|rises?|falls?|"
    r"slides?|drops?|tumbles?)|invests? in .* shares|buy ratings?|stock alerts?|stock movers?|"
    r"black friday deals?|cyber monday deals?|predictions? and (?:picks|odds)|fantasy football|"
    r"parlay|ncaa|touchdown|giveaway|promo code|coupon code|stream the game|horoscope)\b")
LOW_SIGNAL = re.compile(r"\b(?:zacks|marketbeat|tipranks|ticker report|stock titan|marketscreener|"
    r"gurufocus|stocktwits|simply wall st|benzinga|investingchannel|stockscan|tradingview|"
    r"ainvest|barchart|finviz|defense world|insider monkey|marketwatch guides|seeking alpha|motley fool|"
    r"24/7 wall st|trefis|investing\.com|sports illustrated|sporting news|instagram|facebook|msn|"
    r"pinterest|tiktok|threads|youtube|tradingnews|tip ranks|stock analysis|yahoo sports|kalkine|wisevoter|"
    r"spotrac|fansided|dawn of the dawg|newsbreak|music mayhem|superpower daily|streetinsider|tokenpost|"
    r"finimize|proactive financial news|onesafe|the dis|defense world|globe and mail investing)\b")
ESTABLISHED = re.compile(r"\b(?:reuters|ap news|associated press|bloomberg|financial times|wall street journal|"
    r"new york times|washington post|the economist|nikkei|cnbc|bbc|npr|pbs|public radio|stateline|business journals|"
    r"semiconductor engineering|ieee|ee times|fierce pharma|fierce biotech|utility dive|industry dive|"
    r"reuters|s&p global|american banker|banking dive|retail dive|supply chain dive|techcrunch|the verge|"
    r"korea herald|korea times|yonhap|channel newsasia|economic development|department of|bureau of|"
    r"federal reserve|sec\.gov|census\.gov|governor|office of|public media|government|newsroom)\b")
EXTRA_NOISE = re.compile(r"\b(?:price prediction|predictions?|etfs?|funds? (?:bought|sold)|shareholders?|"
    r"analyst targets?|target despite|selloff|sell-off|on watch|upgrade[sd]?|downgrade[sd]?|market cap|"
    r"market value|remains a buy|at buy|beat the market|earnings report\?|why is .* (?:up|down)|"
    r"attractive investment|investment could be worth|ten ?bagger|trims? .*loss|taking profits|perpetual contracts|"
    r"^(?:what’s|what's) next for|\bform [34]\b|rally|year-to-date|halftime|playbooks?|"
    r"gophers|glenn schumann|recruiting class|unfinished business|order of business|kickoff|kick-off|"
    r"surf cam|personnel file|tee times|draft picks?|enters transfer portal|in the portal)\b")
EDITORIAL_NOISE = re.compile(r"\b(?:stocks?|shares?|investors?|dividends?|traders?|ratings?|ticker|valuation|undervalued|overvalued|"
    r"upside|downside|fair value|pre[- ]market|wall street|nasdaq|nyse|surprise earnings|ipo buy|insider (?:sale|buy)|"
    r"earnings call transcript|bargain|black friday|cyber monday|best deals|gift guide|shopping list|store hours|"
    r"saved? up to|last chance|promo codes?|vs\.?|price prediction|price forecast|surf report|surf forecast|"
    r"net worth|career paths?|job postings?|job seekers?|now hiring|onlyfans|small business saturday|"
    r"game day|football|basketball|key match|win streak|head coach|quarterback|playoff|touchdown|sportsbook)\b")
COMPANY_EVENT = re.compile(r"\b(?:manufactur|produ(?:ct|ce)|suppl|customer|contract|agreem|deal|"
    r"partne|collab|acqui|merg|sell|sold|sale|buy(?:s|ing)?\b|invest|spend|launch|releas|introduc|"
    r"operat|facilit|open|clos(?:e|ing|ur)|expand|expans|approv|regulat|antitrust|competi|test|trial|"
    r"research|licens|lawsuit|sue[ds]?\b|settle|court|judg|investigat|ban\b|reject|permit|"
    r"delay|disrupt|secur|train|traini|workforce|hire|hiring|layoff|lay off|job cut|worker|union|employee|"
    r"chair|chief|ceo|appoint|resign|leadership|restructur|recall|shortage|profit|revenu|earnings|"
    r"financing|order|outage|breach|cyber|seiz|deploy|ship|construct|build|project|repair|"
    r"plant\b|factory|chip|semiconductor|foundry|hbm\b|dram\b|cloud|drug\b|clinical|fda\b|"
    r"pipeline|refiner|mine\b|copper|steel|lithium|aircraft|airline|carrier|credit card|payment|"
    r"oil field|banking|data cent|advertis|network|subscrib|customer|electric vehicle|production|storage|"
    r"program|programme|funding|approach|service|announc|business|factory|bottl|smartphone)")
COMPANY_QUERY = "production OR business OR launch OR supply OR contract OR acquires OR partnership OR sales"
NEGATIVE_QUERY = " -stock -stocks -shares -dividend -nasdaq"
ALIASES = {
    "TSM": ["TSMC", "Taiwan Semiconductor Manufacturing"], "005930": ["Samsung Electronics", "Samsung"],
    "000660": ["SK hynix", "SK Hynix"], "META": ["Meta Platforms", "Meta"],
    "GOOGL": ["Alphabet", "Google"], "PM": ["Philip Morris"], "BRK.B": ["Berkshire Hathaway"],
    "JPM": ["JPMorgan", "JP Morgan", "JPMorgan Chase"], "CRCL": ["Circle Internet Group", "Circle"],
    "PG": ["Procter and Gamble", "Procter & Gamble", "P&G"], "V": ["Visa"],
    "055550": ["Shinhan Financial", "Shinhan Bank"], "105560": ["KB Financial", "Kookmin Bank"],
    "TMUS": ["T-Mobile"], "MRK": ["Merck"], "UNH": ["UnitedHealth", "UnitedHealthcare"],
    "LLY": ["Eli Lilly", "Lilly"], "XOM": ["ExxonMobil", "Exxon Mobil", "Exxon"],
    "SHEL": ["Shell"], "KLAC": ["KLA Corporation", "KLA"], "RTX": ["RTX", "Raytheon"],
    "JNJ": ["Johnson & Johnson", "Johnson and Johnson", "J&J"], "TXN": ["Texas Instruments"],
    "BHP": ["BHP", "BHP Group"], "ORCL": ["Oracle"], "SPCX": ["SpaceX"],
}
QUALIFIER = {
    "V": "payments OR card OR Visa Inc", "CRCL": "stablecoin OR USDC OR fintech",
    "SHEL": "oil OR energy OR LNG", "CAT": "machinery OR Caterpillar Inc OR equipment",
    "META": "technology OR Facebook OR AI", "RTX": "aerospace OR defense OR Raytheon",
    "AAPL": "Apple Inc OR iPhone OR technology", "KLAC": "semiconductor OR chip",
    "STT": "bank OR asset management OR State Street Corporation", "005930": "electronics OR chip OR phone",
    "MRK": "Merck & Co OR Keytruda OR MSD", "ORCL": "cloud OR database OR software",
}
AMBIGUOUS = {
    "V": r"pay(?:ment)?|card|merchant|transaction|debit|credit|visa inc|fintech|mastercard",
    "CRCL": r"stablecoin|usdc|fintech|token|crypto|circle internet|digital asset",
    "SHEL": r"oil|energy|gas|lng|refin|petrol|wind|fuel|drill|pipeline|shell plc|offshore|renewable",
    "CAT": r"machin|equipment|construct|excavator|mining|engine|caterpillar inc|truck|factory|power",
    "META": r"facebook|whatsapp|instagram|zuckerberg|meta platforms|quest|data cent|\bai\b|ads?\b|tech|social media|smart glasses|oversight|reality labs",
    "RTX": r"defen[cs]e|aerospace|raytheon|pratt|missile|aircraft|engine|aviation|collins|radar",
    "AAPL": r"iphone|ipad|macbook|imac|app store|tech|siri|ios|apple inc|tim cook|airpods|vision pro|smartphone|apple watch|apple pay|apple tv|apple music|ipados|macos|apple intelligence|\bai\b",
    "KLAC": r"chip|semiconductor|wafer|process control|kla corp",
    "STT": r"bank|asset|etf|custod|fund|state street corp|invest",
    "005930": r"electronics|chip|smartphone|galaxy|semiconductor|memory|foundry|display|phone|hbm|nand|appliance",
    "MRK": r"merck & co|merck and co|keytruda|msd|gardasil|rahway|pembrolizumab|sotatercept|winrevair",
    "ORCL": r"oracle corp|oracle cloud|database|software|cloud|data cent|larry ellison|\boci\b|\bai\b",
}
STATE_QUERY = {"WA": '"Washington state" OR "Washington economy"', "DC": '"Washington D.C." OR "District of Columbia"', "GA": '"Georgia" -Tbilisi -Caucasus -Georgian', "NY": '"New York"'}
STATE_ALIASES = {"WA": ["Washington state", "Washington’s", "Washington economy", "Seattle", "Tacoma", "Spokane"],
    "DC": ["Washington D.C.", "Washington DC", "District of Columbia", "D.C.", "DC"],
    "NY": ["New York", "NYC"], "GA": ["Georgia", "Atlanta"]}
TOPIC_WORDS = "economy OR jobs OR manufacturers OR industry OR business OR energy OR employment OR factory"


def norm(s):
    return " ".join(re.sub(r"[^\w]+", " ", unicodedata.normalize("NFKC", s).casefold()).split())


def scopes(site):
    directory = site / "src/site"
    groups = json.loads((directory / "market-directory.json").read_text("utf-8"))
    shapes = json.loads((directory / "market-us-shapes.json").read_text("utf-8"))
    result = {}
    for state in shapes:
        code, name = state["code"], state["en"]
        result["s:" + code] = (f'({STATE_QUERY.get(code, chr(34)+name+chr(34))}) ({TOPIC_WORDS})', STATE_ALIASES.get(code, [name]), True)
    for group in groups:
        if group["section"] != "companies":
            continue
        for item in group["items"]:
            ticker, name = item["ticker"], item["nameEn"]
            names = list(dict.fromkeys(ALIASES.get(ticker, [name])))
            phrase = " OR ".join(f'"{a}"' for a in names[:2])
            query = f"({phrase}) ({QUALIFIER.get(ticker,COMPANY_QUERY)})"+NEGATIVE_QUERY
            result["c:" + ticker] = (query, names, False)
    return result


def relevant(key, scope, title, source):
    _, aliases, state = scope
    raw, folded = title.casefold(), norm(title)
    if not any(" "+norm(a)+" " in " "+folded+" " for a in aliases):
        return False
    if NOISE.search(raw) or EDITORIAL_NOISE.search(raw) or EXTRA_NOISE.search(raw) or LOW_SIGNAL.search(source.casefold()):
        return False
    if len(title)>185 or re.search(r"\b(?:investor presentation|target revisions?|early retirement|surf cam|game preview)\b",raw):
        return False
    if key == "s:VA" and "west virginia" in raw and "virginia" not in raw.replace("west virginia",""):
        return False
    if key == "s:FL" and re.search(r"\b(?:rb|qb|gators|seminoles|recruit|linebacker)\b",raw):
        return False
    if key == "s:GA" and re.search(r"tbilisi|caucasus|georgian (?:government|dream|parliament)|eurasian", raw):
        return False
    if key == "s:WA" and re.search(r"washington,? d\.?c\.?|district of columbia", raw):
        return False
    if key == "s:DC" and re.search(r"washington state|washington commanders", raw):
        return False
    if key == "c:V" and re.search(r"visa (?:applications?|rules?|status|sponsorship|holders?|processing|policy|restrictions?)|immigration|e-visa|travel visa|work visa|student visa|h-1b", raw):
        return False
    # Visa's mirrored archive has resurfaced its 2018 YellowPepper release with a new feed date.
    if key == "c:V" and re.search(r"visa (?:makes strategic investment in|to acquire|completes acquisition of) yellowpepper",raw):
        return False
    if key == "c:MRK" and re.search(r"merck kgaa|darmstadt|emd serono", raw):
        return False
    if key == "c:LIN" and re.search(r"material handling|kion group|forklift|warehouse|intralogistics|linde (?:hotel|lindstrom)",raw):
        return False
    if key == "c:CSCO" and re.search(r"andre cisco|cisco ave|cisco bay",raw):
        return False
    if state:
        return bool(INDUSTRY.search(raw))
    guard = AMBIGUOUS.get(key[2:])
    return bool(COMPANY_EVENT.search(raw)) and (not guard or bool(re.search(guard, raw)))


def is_google_article(url):
    try:
        p = urllib.parse.urlsplit(url)
        return p.scheme == "https" and p.netloc == "news.google.com" and p.path.startswith(("/rss/articles/", "/articles/", "/read/"))
    except (ValueError, TypeError):
        return False


def items_from_rss(data, key, scope, cutoff, now):
    root = ET.fromstring(data)
    if root.tag != "rss" or root.find("channel") is None:
        raise ValueError("unexpected feed format")
    items = []
    for item in root.findall("./channel/item"):
        outlet = (item.findtext("source") or "").strip()
        headline = (item.findtext("title") or "").strip().removesuffix(" - "+outlet)
        link = (item.findtext("link") or "").strip()
        if not (2 <= len(outlet) <= 120 and 10 <= len(headline) <= 350 and is_google_article(link)):
            continue
        if not relevant(key, scope, headline, outlet):
            continue
        try:
            date = email.utils.parsedate_to_datetime(item.findtext("pubDate")).astimezone(UTC)
        except (TypeError, ValueError, OverflowError, AttributeError):
            continue
        if cutoff <= date <= now:
            items.append(dict(title=headline, source=outlet, url=link, date=date.strftime("%Y-%m-%dT%H:%M:%SZ")))
    return items


def merge(entries, cutoff, now, key, scope):
    unique, outlets, rows = set(), set(), []
    valid = []
    for row in entries:
        if not isinstance(row, dict) or not all(isinstance(row.get(k), str) for k in ("date","title","source","url")):
            continue
        try:
            date = dt.datetime.fromisoformat(row["date"].replace("Z", "+00:00"))
            within = cutoff <= date <= now
        except (TypeError, ValueError):
            continue
        if within and is_google_article(row["url"]) and relevant(key,scope,row["title"],row["source"]):
            valid.append(row)
    def quality(row):
        outlet, title = row["source"].casefold(), row["title"].casefold()
        official = not scope[2] and any(norm(a)==norm(row["source"]) or norm(a)+" newsroom" == norm(row["source"]) for a in scope[1])
        # Give direct and established reports first pick; display the resulting items by date.
        days = (now - dt.datetime.fromisoformat(row["date"].replace("Z","+00:00"))).total_seconds()/86400
        return (5 if official else 3 if ESTABLISHED.search(outlet) else 0)+(1 if COMPANY_EVENT.search(title) else 0)-days/5
    for row in sorted(valid, key=quality, reverse=True):
        title, outlet = norm(row["title"]), norm(row["source"])
        words=set(title.split())
        if outlet in outlets or any(len(words & w)/max(len(words | w),1)>.75 for w in unique):
            continue
        unique.add(frozenset(words)); outlets.add(outlet); rows.append(row)
        if len(rows) == MAX_ITEMS:
            break
    return sorted(rows,key=lambda r:r["date"],reverse=True)


def request(url, limit=2_500_000):
    req = urllib.request.Request(url, headers={"User-Agent": "MurmurworldNews/1.0 (+https://murmurworld.github.io/stocks/)", "Accept": "application/rss+xml,application/json,*/*"})
    with urllib.request.urlopen(req, timeout=15) as resp:
        body = resp.read(limit + 1)
    if len(body) > limit:
        raise ValueError("oversized response")
    return body


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--site", type=Path, default=Path(__file__).resolve().parents[1])
    ap.add_argument("--published-cache", action="store_true")
    ap.add_argument("--cache-only", action="store_true")
    args = ap.parse_args()
    site, now = args.site, dt.datetime.now(UTC)
    definitions, cutoff = scopes(site), now - dt.timedelta(days=MAX_AGE)
    dest = site / "public/data/market-news.json"
    caches = []
    def accept_cache(cache):
        if isinstance(cache,dict) and cache.get("version")==1 and isinstance(cache.get("topics"),dict):
            caches.append(cache)
    if dest.exists():
        accept_cache(json.loads(dest.read_text("utf-8")))
    if args.published_cache:
        try:
            accept_cache(json.loads(request(PUBLIC_URL)))
        except Exception as err:
            print(f"::warning::Published news snapshot unavailable ({type(err).__name__}). Using bundled copy.")
    def fetch(pair):
        key, scope = pair
        query = urllib.parse.urlencode(dict(q=scope[0]+f" when:{MAX_AGE}d",hl="en-US",gl="US",ceid="US:en"))
        for attempt in range(2):
            try:
                raw = request(GOOGLE+"rss/search?"+query)
                return key, items_from_rss(raw,key,scope,cutoff,now)
            except Exception as err:
                if attempt:
                    return key, type(err).__name__
                time.sleep(1)
    retrieved, failed = {}, []
    if not args.cache_only:
        with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
            for key, result in executor.map(fetch, definitions.items()):
                if isinstance(result,list):
                    retrieved[key]=result
                else:
                    failed.append(key)
    result = {}
    for key,scope in definitions.items():
        candidates=list(retrieved.get(key,[]))
        checked=[]
        for cache in caches:
            previous=cache["topics"].get(key,{})
            if not isinstance(previous,dict):
                continue
            if isinstance(previous.get("items"),list):
                candidates.extend(previous["items"])
            if isinstance(previous.get("checked"),str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z",previous["checked"]):
                checked.append(previous["checked"])
        result[key]={"query":scope[0],"checked":now.strftime("%Y-%m-%dT%H:%M:%SZ") if key in retrieved else max(checked,default=None),
                     "items":merge(candidates,cutoff,now,key,scope)}
    stories=sum(len(v["items"]) for v in result.values())
    stamp=max((v['checked'] or '' for v in result.values()),default="")
    if (not args.cache_only and (not retrieved or not stories)) or (not stories and not stamp):
        sys.exit("All feeds unavailable and/or no usable input. Leaving the published site in place.")
    if failed:
        print(f"::warning::{len(failed)} feeds unavailable; retained eligible cached headlines for "+", ".join(failed))
    covered=sum(bool(v['items']) for v in result.values())
    message=(f"Market news: {len(retrieved)} feeds checked; {len(result)} subjects; {stories} dated headlines, "
             f"{covered} subjects with relevant coverage.")
    print(message)
    if covered<len(result)*.75:
        print("::warning::Fewer than three quarters of subjects have a recent, matching headline.")
    if os.environ.get("GITHUB_STEP_SUMMARY"):
        with open(os.environ["GITHUB_STEP_SUMMARY"],"a",encoding="utf-8") as summary:
            summary.write(f"{message}\n\nFailed feed requests: {len(failed)}. Latest successful check: {stamp or 'none'}.\n")
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp=dest.with_suffix(".tmp")
    tmp.write_text(json.dumps({"version":1,"maxAgeDays":MAX_AGE,"lastChecked":stamp,"topics":result},ensure_ascii=False,separators=(",",":"))+"\n","utf-8")
    tmp.replace(dest)


if __name__ == "__main__":
    main()
