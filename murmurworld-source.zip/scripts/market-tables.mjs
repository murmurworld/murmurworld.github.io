// Give each standalone Markdown table its own keyboard-scrollable region.
export default function marketTables() {
  return (tree, file) => {
    const path = String(file.path ?? '').replaceAll('\\', '/');
    if (!/\/articles\/(companies|funds)\//.test(path)) return;
    const english = path.endsWith('.en.md');
    const flatten = node => node.value ?? (node.children ?? []).map(flatten).join('');
    function wrap(nodes) {
      let label = english ? 'Article table' : '본문 표';
      for (let i = 0; i < nodes.length; i++) {
        const node = nodes[i];
        if (/^h[1-6]$/.test(node.tagName ?? '')) label = flatten(node);
        if (node.tagName === 'table') {
          nodes[i] = { type:'element', tagName:'div', properties:{
            className:['tw'], role:'region', tabIndex:0, ariaLabel:label
          }, children:[node] };
        } else if (node.children && !node.properties?.className?.includes('tw')) wrap(node.children);
      }
    }
    wrap(tree.children);
  };
}
