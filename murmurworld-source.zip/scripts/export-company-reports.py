"""Rebuild public company notes from the local Pro Report releases and published articles.

Usage: python scripts/export-company-reports.py --source-root /path/to/public_research_versions
An optional --business-file / --explainer-file pins an alternate, reviewed release.
Uses only the specified business/product structures; investment models and account data
are never loaded. The generated site requires no connection to the local research archive.
"""
import argparse
from datetime import date, timedelta
import json
from math import isclose, isfinite
import os
from pathlib import Path
import re
from urllib.parse import urlsplit


SITE = Path(__file__).resolve().parents[1]
FILINGS = re.compile(r"\[([^\]\n]+)\]\((https://[^\s)]+)\)(?:\s*·\s*(\d{4}-\d{2}-\d{2}))?")
UNITS = {"백만 달러": ("USD","USD million"), "십억 달러": ("USD","USD billion"),
         "천 달러": ("USD","USD thousand"), "백만 위안": ("CNY","CNY million"),
         "십억 위안": ("CNY","CNY billion"), "백만 엔": ("JPY","JPY million"),
         "조 엔": ("JPY","JPY trillion"), "조 원": ("KRW","KRW trillion"),
         "억원": ("KRW","KRW 100 million"), "백만 NT$": ("TWD","TWD million"),
         "십억 대만 달러": ("TWD","TWD billion"), "백만 DKK": ("DKK","DKK million"),
         "십억 덴마크 크로네": ("DKK","DKK billion"), "십억 유로": ("EUR","EUR billion")}
TITLES = {"segments":"Reportable business segments", "segments_net":"Net income by segment",
          "products":"Products and services", "markets":"End markets", "geography":"Geographical breakdown",
          "technology":"Manufacturing process", "channels":"Sales channels"}
KINDS = {"leaf","group","aggregate","adjustment","residual","gap"}


def read(path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def release(root, pattern):
    files = sorted(root.glob(pattern))
    if not files:
        raise FileNotFoundError(f"Missing source release matching {pattern}")
    return files[-1]


def lookup(assets, ticker):
    return next((assets[k] for k in [ticker, f"US_{ticker}", f"KR_{ticker}"] if k in assets), None)


def cash_values(raw, divisor, size):
    if len(raw) != size or divisor <= 0:
        raise ValueError("Unexpected number of periods or invalid unit")
    result = []
    for amount in raw:
        if amount is None:
            result.append(None)
            continue
        if not isinstance(amount, (int, float)) or not isfinite(amount):
            raise ValueError("Invalid monetary amount")
        scaled = amount / divisor
        result.append(int(scaled) if scaled.is_integer() else round(scaled, 9))
    return result


def safe_url(url):
    return bool(url and urlsplit(url).scheme == "https" and urlsplit(url).hostname and
                not urlsplit(url).username and not re.search(r"localhost|127\.0\.0\.1", url, re.I))


def narrative(explainer, terms, additional):
    if not explainer or explainer.get("kind") != "company":
        raise ValueError("Company product explainer missing")
    products = [{"name": p["name"], "plain": p["plain"],
                 "terms":list(dict.fromkeys([*p.get("terms", []), *additional.get(p["name"],[])]))}
                for p in explainer["products"]]
    ids = list(dict.fromkeys([*explainer["terms"], *(k for p in products for k in p["terms"])]))
    public_terms = [{"id": key, **{k: terms[key][k] for k in ["name","plain","aka","like","where"]
                                  if terms[key].get(k)}} for key in ids]
    return {"line": explainer["line"], "products": products, "terms": public_terms}


def report_citation(record, cik, ticker):
    accession, url = record.get("accession"), record.get("url")
    if not url and re.fullmatch(r"\d{14}", accession or ""):
        url = f"https://dart.fss.or.kr/dsaf001/main.do?rcpNo={accession}"
    if not url and cik and re.fullmatch(r"\d{10}-\d{2}-\d{6}", accession or ""):
        url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{accession.replace('-', '')}/{accession}-index.htm"
    if not safe_url(url):
        raise ValueError(f"{ticker}: filing URL cannot be determined")
    return {"label":record["form"], "url":url, "filed":record.get("filed"),
            "periodEnd":record.get("period_end")}


def first_comparable(periods, history):
    for p in reversed(periods):
        if p["label"] in {x["at"] for x in history.get("marks", [])} | {history.get("basis_from"),history.get("cagr_from")}:
            return p["label"]
    return periods[0]["label"]


def set_composition(table, partition=None):
    table["compositionKeys"], table["compositionPeriods"] = [], []
    if table["measure"] != "revenue" or table["total"] is None or partition in {"partial","approx","derived"}:
        return
    start = next((i for i,p in enumerate(table["periods"]) if p["label"]==table["comparableFrom"]), 0)
    candidates = [r for r in table["rows"] if r["level"]==0 and not r["parent"] and
                  not r.get("legacy") and r["kind"] in {"leaf","aggregate","group"}]
    if len(candidates) < 2:
        return
    for i,p in enumerate(table["periods"]):
        total = table["total"][i]
        vals = [r["values"][i] for r in candidates]
        if i<start or not total or any(v is None or v<0 for v in vals):
            continue
        if isclose(sum(vals), total, rel_tol=0.000005, abs_tol=1e-8):
            table["compositionPeriods"].append(p["label"])
    if table["compositionPeriods"]:
        table["compositionKeys"] = [r["key"] for r in candidates]


def alphabet_reconciliation(table):
    """Refer only to the three businesses. Alphabet-level hedging is in a separate row."""
    keys = ["GoogleServicesMember","GoogleCloudMember","AllOtherSegmentsMember"]
    rows = {r["key"]:r for r in table["rows"]}
    if not all(key in rows for key in keys) or table["id"] not in {"segments","segments-nine-months","segments-quarter"}:
        return
    if table["source"]["periodEnd"]=="2026-06-30" and "__hedges" not in rows:
        expected = ["2025-06-30","2026-06-30"]
        if [p["end"] for p in table["periods"]]==expected:
            # Note 2, June 2026 Form 10-Q, six months ended June 30.
            table["rows"].append({"key":"__hedges","ko":"헤지 손익","en":"Hedging gains (losses)","kind":"adjustment",
                                  "level":0,"parent":None,"values":[148,-74]})
    correction = next((r for r in table["rows"] if r["key"] in {"__residual","__hedges"}),None)
    if not correction:
        return
    subtotals = [sum(rows[k]["values"][i] for k in keys) for i in range(len(table["periods"]))]
    if not all(isclose(s+adj,total,abs_tol=1e-7) for s,adj,total in zip(subtotals,correction["values"],table["total"],strict=True)):
        return
    table.update(compositionKeys=keys, compositionBasis="before-adjustments", compositionTotals=subtotals,
                 compositionPeriods=[p["label"] for p in table["periods"]])
    table["notes"].append("세 사업의 매출을 합한 뒤 헤지 등 본사 조정을 반영하면 연결 매출이 된다.")
    table["notesEn"].append("The three businesses are shown before corporate adjustments such as hedging gains or losses. The reconciliation row bridges their sum to consolidated revenue.")


def report_table(view, annual_view, record, doc_source, vocab):
    unit = record["table_unit"]
    periods = [{k:p.get(k) for k in ("label","start","end")} for p in view["periods"]]
    if not periods or not view.get("lines") or view.get("hidden"):
        return None
    history = view.get("history") or {}
    rows = []
    annual_rows = {r["key"]: r for r in annual_view.get("lines", [])}
    keys = {r["key"] for r in view["lines"]}
    for line in view["lines"]:
        key = line["key"]
        yearly = annual_rows.get(key, {})
        parent = line.get("parent",yearly.get("parent"))
        ko, en = line["label_ko"], line["label_en"]
        row = {"key":key,"ko":ko,"en":vocab["rowEn"].get(en,en), "kind":line["kind"],
               "level":line.get("level", yearly.get("level",0)) if parent in keys else 0,
               "parent":parent if parent in keys else None,
               "values":cash_values(line["values"],unit["divisor"],len(periods))}
        if row["kind"] not in KINDS:
            raise ValueError(f"Unknown source row kind: {row['kind']}")
        if line.get("legacy"):
            row["legacy"] = True
        if line.get("derived"):
            row["derivedPeriods"] = line["derived"]
        rows.append(row)
    title, view_id = view["title_ko"], view["id"]
    basis = view.get("basis_ko") or annual_view.get("basis_ko") or ""
    measure = "operating-income" if "영업이익" in title+basis else "net-income" if "순이익" in title+basis else "revenue"
    note = view.get("note_ko") or annual_view.get("note_ko")
    notes, notes_en = [], []
    if note:
        notes.append(note)
        if note in vocab["notesEn"]:
            notes_en.append(vocab["notesEn"][note])
    if len(periods)>3 and not doc_source["label"].startswith("6-K"):
        notes.append("과거 금액은 해당 연도를 포함한 후속 연차 공시의 재작성 수치를 반영한다.")
        notes_en.append("Historical amounts use later annual filings’ restated comparatives where available.")
    if any(r.get("derivedPeriods") for r in rows):
        notes.append("일부 기간의 소계는 공시된 하위 항목을 더해 구했다.")
        notes_en.append("Some subtotals were reconstructed from the disclosed components.")
    table = {"id":view_id, "titleKo":title, "titleEn":vocab["titleEn"].get(title,TITLES.get(view_id,title)),
             "currency":record["currency"], "unitKo":unit["label_ko"], "unitEn":UNITS[unit["label_ko"]][1],
             "measure":measure,"basisKo":basis,"basisEn":vocab["basisEn"].get(basis,""),
             "periods":periods, "rows":rows, "total":cash_values(view["total"],unit["divisor"],len(periods)),
             "notes":notes, "notesEn":notes_en, "marks":[{"at":m["at"],"kind":m["kind"]} for m in history.get("marks",[])],
             "comparableFrom":first_comparable(periods,history), "source":doc_source}
    set_composition(table, view.get("partition"))
    return table


def section(markdown, heading):
    match = re.search(r"^### "+re.escape(heading)+r"\s*\n(.+?)(?=^##|\Z)", markdown, re.M|re.S)
    return match.group(1) if match else ""


def markdown_cells(section_text):
    return [[c.strip() for c in line.strip().strip("|").split("|")]
            for line in section_text.splitlines() if line.startswith("|") and "---" not in line]


def fiscal_period(label, year_ends):
    if re.fullmatch(r"\d{4}",label):
        end = year_ends.get(label)
        return {"label":f"FY{label}", "start":None, "end":end}
    dates = re.findall(r"\d{4}-\d{2}-\d{2}",label)
    if not dates:
        raise ValueError(f"Unexpected period: {label}")
    return {"label":label,"start":dates[0] if len(dates)>1 else None,"end":dates[-1]}


def parsed_cells(cells):
    amounts, derived = [], []
    for i,cell in enumerate(cells):
        value = cell.replace(",","").replace("−","-").replace("*","").strip()
        amounts.append(None if value in {"—","–","-",""} else float(value))
        if "*" in cell:
            derived.append(i)
    return amounts, derived


def same_filing(a,b):
    if a == b:
        return True
    # Issuer-hosted full statements and report-note pages retain the SEC accession.
    def accession(s):
        match = re.search(r"(?:/|^)(\d{10}-?\d{2}-?\d{6})(?:/|-index)",s)
        return match[1].replace("-","") if match else ""
    first = accession(a)
    return bool(first and first==accession(b))


def published_table(ko, en, titles, group, ticker, row_names, fiscal_dates):
    src_ko, src_en = section(ko,titles[0]), section(en,titles[1])
    grid, grid_en = markdown_cells(src_ko), markdown_cells(src_en)
    if not grid:
        return None
    if len(grid)!=len(grid_en) or len(grid[0])!=len(grid_en[0]):
        raise ValueError(f"{ticker}: source article translations have different table shapes")
    unit = grid[0][0]
    currency, unit_en = UNITS[unit]
    # A year number alone is a fiscal year, not a December 31 date.
    annual_grid = markdown_cells(section(ko,"연결 손익 · 연간"))
    ends = {s[:4]:s for s in (annual_grid[0][1:] if annual_grid else []) if re.fullmatch(r"\d{4}-\d\d-\d\d",s)}
    periods = [fiscal_period(label,ends) for label in grid[0][1:]]
    if group=="consolidated-quarter":
        for i,period in enumerate(periods):
            period["start"] = fiscal_dates.get(period["end"])
            if not period["start"] and i:
                previous, end = date.fromisoformat(periods[i-1]["end"]), date.fromisoformat(period["end"])
                if 77 <= (end-previous).days <= 100:
                    period["start"] = (previous+timedelta(days=1)).isoformat()
    references = FILINGS.findall(ko.split("## 출처")[-1])
    inline = FILINGS.findall(src_ko)
    interim = group.startswith("consolidated-")
    if inline and not interim:
        label,url,_ = inline[-1]
        filed = next((d for _,u,d in references if d and same_filing(u,url)), None)
        if ticker=="TTE" and url.endswith("totalenergies_form-20-f-2025_2026_en.pdf"):
            filed = next((d for form,u,d in references if form=="20-F" and "/000110465926035876/" in u),filed)
    else:
        acceptable = {"10-Q","Interim results","10-K","20-F","6-K","분기","반기","DART 연결 분기보고서"}
        eligible = [(l,u,d) for l,u,d in references if l in acceptable and d and
                    (not periods[-1]["end"] or d>=periods[-1]["end"])]
        if not eligible:
            return None
        # The first periodic filing following the latest period is the anchor for the comparison.
        label,url,filed = min(eligible, key=lambda x:x[2])
    if not safe_url(url):
        raise ValueError(f"{ticker}: unsafe or missing article citation")
    notes = []
    notes_en = []
    if not interim:
        for text, arr in [(src_ko,notes),(src_en,notes_en)]:
            for line in text.splitlines():
                if not line.startswith("|"):
                    note = FILINGS.sub("",line).strip()
                    if note:
                        arr.append(note)
    rows = []
    for n,(cols, cols_en) in enumerate(zip(grid[1:], grid_en[1:])):
        if len(cols)!=len(periods)+1:
            raise ValueError(f"{ticker}: inconsistent article row")
        if ("%" in "".join(cols[1:]) or "률" in cols[0] or "margin" in cols_en[0].lower()):
            continue  # The monetary table must never mix percentages with currency.
        values, derived = parsed_cells(cols[1:])
        if len(cols_en[1:])!=len(values) or parsed_cells(cols_en[1:])[0]!=values:
            raise ValueError(f"{ticker}: Korean/English source amounts disagree")
        key = f"row-{n+1}"
        row = {"key":key, "ko": row_names.get(cols[0],cols[0]),"en":cols_en[0],"kind":"leaf",
               "level":0,"parent":None,"values":values}
        if derived:
            row["derivedPeriods"] = [periods[i]["end"] for i in derived]
        rows.append(row)
    if any(r.get("derivedPeriods") for r in rows):
        notes.append("일부 분기는 누계의 차이로 계산했다.")
        notes_en.append("Some individual quarters are derived by subtracting earlier cumulative amounts.")
    # Product subtotals and their children appear together in these two issuer notes.
    by_en = {r["en"].lower(): r for r in rows}
    for parent,children in {
        "ASML":{"product":[r["en"].lower() for r in rows if r["en"].lower() not in {"product","service and field options"}]},
        "ORCL":{"software revenues":["software license","software support"],"cloud revenues":["cloud applications","cloud infrastructure"]},
    }.get(ticker,{}).items():
        if parent in by_en:
            by_en[parent]["kind"] = "aggregate"
            for child in children:
                if child in by_en:
                    by_en[child]["level"],by_en[child]["parent"] = 1,by_en[parent]["key"]
    table = {"id":group,"titleKo":titles[0],"titleEn":titles[1],"currency":currency,"unitKo":unit,"unitEn":unit_en,
             "measure":"financial-results" if interim else "revenue","basisKo":"","basisEn":"","periods":periods,
             "rows":rows,"total":None,"notes":notes,"notesEn":notes_en,"marks":[],
             "comparableFrom":periods[0]["label"],"source":{"label":label,"url":url,"filed":filed,"periodEnd":periods[-1]["end"]}}
    if not interim:
        attach_consolidated_total(table, annual_grid)
    set_composition(table)
    return table


def attach_consolidated_total(table, annual_grid):
    """Use the independently reported consolidated total only for a reconciled partition."""
    if not annual_grid or not table["rows"] or table["notes"]:
        return
    revenue = next((row[1:] for row in annual_grid[1:] if row[0]=="매출"),None)
    if not revenue:
        return
    unit_currency, from_unit = UNITS[annual_grid[0][0]]
    multipliers = {"million":1e6, "billion":1e9, "trillion":1e12, "thousand":1e3}
    if table["currency"]!=unit_currency:
        return
    factor = multipliers[from_unit.split()[-1]] / multipliers[table["unitEn"].split()[-1]]
    amounts = dict(zip(annual_grid[0][1:],parsed_cells(revenue)[0],strict=True))
    totals = [amounts.get(p["end"]) for p in table["periods"]]
    if any(v is None for v in totals):
        return
    totals = [round(v*factor,9) for v in totals]
    for i, total in enumerate(totals):
        vals = [r["values"][i] for r in table["rows"] if r["parent"] is None]
        if any(v is None or v<0 for v in vals) or not isclose(sum(vals),total,abs_tol=1e-7,rel_tol=0.000005):
            return
    table["total"] = totals


def export_company(company, article, business, explainer, additions, fiscal_dates):
    ticker, slug = company["ticker"], company["slug"]
    fiscal_dates = {**additions.get("additionalQuarterStarts",{}).get(ticker,{}), **fiscal_dates}
    packet = {"ticker":ticker,"slug":slug,"easy":narrative(lookup(explainer["assets"], ticker),
              explainer["terms"], additions.get("supplementalTerms",{}).get(ticker,{})),
              "annual":[], "interim":[]}
    ko, en = [article.with_suffix(f".{lang}.md").read_text(encoding="utf-8") for lang in ["ko","en"]]
    record = lookup(business["assets"],ticker)
    if record:
        cik_match = re.search(r"https://www.sec.gov/Archives/edgar/data/(\d+)/",ko)
        cik = cik_match[1] if cik_match else None
        yearly = {v["id"]:v for v in record["views"]}
        for period,views,reference in [
            ("annual",record["views"],record.get("source_annual")),
            ("interim",(record.get("interim") or {}).get("views",[]),record.get("source_interim"))]:
            if not views:
                continue
            source = report_citation(reference,cik,ticker)
            for view in views:
                table = report_table(view,yearly.get(view["id"],{}),record,source,additions)
                if table:
                    packet[period].append(table)
    if not packet["annual"]:
        for group,titles in [("segments",("사업부문별 매출","Revenue by reported business segment")),
                             ("products",("제품·서비스별 매출","Revenue by product or service"))]:
            table = published_table(ko,en,titles,group,ticker,additions["fallbackRowKo"],fiscal_dates)
            if table:
                packet["annual"].append(table)
    if not packet["interim"]:
        if ticker in additions["interim"]:
            table = additions["interim"][ticker]
            set_composition(table)
            packet["interim"].append(table)
        else:
            for group,titles in [("consolidated-ytd",("같은 기간 누계 · 연결","Consolidated year-to-date comparison")),
                                 ("consolidated-quarter",("연결 손익 · 분기 3개월","Consolidated results for individual quarters"))]:
                table = published_table(ko,en,titles,group,ticker,additions["fallbackRowKo"],fiscal_dates)
                if table:
                    packet["interim"].append(table)
    if ticker in additions.get("extraInterim",{}):
        for table in additions["extraInterim"][ticker]:
            set_composition(table)
            packet["interim"].append(table)
        packet["interim"].sort(key=lambda t:t["source"]["periodEnd"] or "",reverse=True)
    for table in packet["annual"]+packet["interim"]:
        ref = table["source"]
        ref["labelEn"] = additions["sourceEn"].get(ref["label"],ref["label"])
        if ticker=="GOOGL":
            alphabet_reconciliation(table)
        for p in table["periods"]:
            p["labelEn"] = p["label"]
            if re.search(r"[가-힣]",p["label"]) and p["start"] and p["end"]:
                p["labelEn"] = f'{p["start"]} – {p["end"]}'
    for key in ["annual", "interim"]:
        if not packet[key]:
            raise ValueError(f"{ticker}: no valid {key} disclosure available; review the source before replacing snapshots")
    return packet


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root",type=Path,default=os.environ.get("PRO_RESEARCH_ROOT"))
    parser.add_argument("--business-file",type=Path)
    parser.add_argument("--explainer-file",type=Path)
    parser.add_argument("--supplement-file",type=Path,help="Optional source of exact fiscal quarter boundaries")
    parser.add_argument("--site-root",type=Path,default=SITE)
    parser.add_argument("--check",action="store_true",help="Validate content and compare to published output without writing")
    args = parser.parse_args()
    if not args.source_root and not (args.business_file and args.explainer_file):
        parser.error("Pass --source-root or set PRO_RESEARCH_ROOT")
    business = read(args.business_file or release(args.source_root,"*-business-structure*/*.json"))
    explainer = read(args.explainer_file or release(args.source_root,"*-product-explainer*/product_explainer.json"))
    additions = read(Path(__file__).with_name("company-report-annotations.json"))
    additions["notesEn"].update(read(Path(__file__).with_name("company-report-notes-en.json")))
    supplemental = args.supplement_file
    if not supplemental and args.source_root:
        paths = sorted(args.source_root.glob("*-stock-profiles*/supplement.json"))
        supplemental = paths[-1] if paths else None
    # Only explicit period start/end fields are carried into published data.
    calendars = {}
    if supplemental:
        for key,asset in read(supplemental)["assets"].items():
            core = asset.get("financial_core") or {}
            quarterly = core.get("quarterly") or {}
            calendars[key] = {p["end"]:p["start"] for p in quarterly.get("periods",[]) if p.get("start") and p.get("end")}
    directory = read(args.site_root/"src/site/market-directory.json")
    results = {}
    for sector in directory:
        if sector["section"] != "companies":
            continue
        for company in sector["items"]:
            slug = company["slug"]
            if not re.fullmatch(r"[a-z0-9-]+",slug) or slug in results:
                raise ValueError(f"Invalid or repeated company slug: {slug}")
            article = args.site_root/"src/articles/companies"/sector["slug"]/slug
            packet = export_company(company,article,business,explainer,additions,lookup(calendars,company["ticker"]) or {})
            results[slug] = json.dumps(packet,ensure_ascii=False,allow_nan=False,separators=(",",":"))+"\n"
    output = args.site_root/"public/data/company-reports"
    if not args.check:
        output.mkdir(parents=True,exist_ok=True)
    # Assemble and validate the entire set before replacing any prior snapshot.
    from tempfile import NamedTemporaryFile
    for slug,content in results.items():
        filename = output/f"{slug}.json"
        if filename.exists() and filename.read_text(encoding="utf-8")==content:
            continue
        if args.check:
            raise SystemExit(f"Stale or missing snapshot: {slug}")
        with NamedTemporaryFile(mode="w",encoding="utf-8",newline="\n",dir=output,delete=False) as tmp:
            tmp.write(content)
        Path(tmp.name).replace(filename)
    print(f"{len(results)} company reports {'verified' if args.check else 'exported'}.")


if __name__ == "__main__":
    main()
