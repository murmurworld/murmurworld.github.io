"""Article links and original publication dates from publisher feeds and publisher pages."""
import datetime as dt
import email.utils
import html
from html.parser import HTMLParser
import json
import re
import urllib.parse as url
import xml.etree.ElementTree as ET


# The channel URL may differ from the outlet's canonical article hostname.
FEEDS = [
    ("NPR","npr.org","https://feeds.npr.org/1006/rss.xml"),
    ("BBC News","bbc.com","https://feeds.bbci.co.uk/news/business/rss.xml"),
    ("CNBC","cnbc.com","https://www.cnbc.com/id/10001147/device/rss/rss.html"),
    ("The New York Times","nytimes.com","https://www.nytimes.com/services/xml/rss/nyt/Business.xml"),
    ("Axios","axios.com","https://www.axios.com/feeds/feed.rss"),
    ("Semiconductor Digest","semiconductordigest.com","https://www.semiconductordigest.com/feed/"),
    ("Semiconductor Engineering","semiengineering.com","https://semiengineering.com/feed/"),
    ("Site Selection","siteselection.com","https://siteselection.com/feed/"),
    ("NVIDIA","blogs.nvidia.com","https://blogs.nvidia.com/feed/"),
    ("Apple Newsroom","apple.com","https://www.apple.com/newsroom/rss-feed.rss"),
    ("Samsung Newsroom","news.samsung.com","https://news.samsung.com/global/feed"),
    ("Microsoft Source","news.microsoft.com","https://news.microsoft.com/source/feed/"),
    ("Google","blog.google","https://blog.google/rss/"),
    ("IBM Newsroom","newsroom.ibm.com","https://newsroom.ibm.com/announcements?pagetemplate=rss"),
    ("The Texas Tribune","texastribune.org","https://www.texastribune.org/feeds/main/"),
    ("CalMatters","calmatters.org","https://calmatters.org/feed/"),
    ("NJ Spotlight News","njspotlightnews.org","https://www.njspotlightnews.org/feed/"),
    ("New York Focus","nysfocus.com","https://www.nyfocus.com/feed/"),
    ("MinnPost","minnpost.com","https://www.minnpost.com/feed/"),
    ("VTDigger","vtdigger.org","https://vtdigger.org/feed/"),
    ("Mississippi Today","mississippitoday.org","https://mississippitoday.org/feed/"),
    ("Oregon Business","oregonbusiness.com","https://oregonbusiness.com/feed/"),
    ("Georgia Ports Authority","gaports.com","https://gaports.com/feed/"),
    ("Delaware Business Times","delawarebusinesstimes.com","https://www.delawarebusinesstimes.com/feed/"),
    ("Delaware LIVE","delawarelive.com","https://delawarelive.com/feed/"),
    ("The Waterways Journal","waterwaysjournal.net","https://www.waterwaysjournal.net/feed/"),
    ("SK hynix Newsroom","news.skhynix.com","https://news.skhynix.com/feed/"),
    ("AMD","newsroom.amd.com","https://newsroom.amd.com/rss"),
    ("Lam Research Newsroom","newsroom.lamresearch.com","https://newsroom.lamresearch.com/bin/lamresearch/rss/feed?feedType=pressrelease"),
    ("About Amazon","aboutamazon.com","https://www.aboutamazon.com/news/rss"),
    ("Light Reading","lightreading.com","https://www.lightreading.com/rss.xml"),
    ("The Center Square","thecentersquare.com","https://www.thecentersquare.com/search/?f=rss&t=article&s=start_time&sd=desc"),
    *[(label,host,f"https://www.{host}/feeds/news/") for label,host in (
      ("Manufacturing Dive","manufacturingdive.com"),("Retail Dive","retaildive.com"),
      ("Utility Dive","utilitydive.com"),("Banking Dive","bankingdive.com"),
      ("BioPharma Dive","biopharmadive.com"),("Supply Chain Dive","supplychaindive.com"),
      ("Construction Dive","constructiondive.com"),("Agriculture Dive","agriculturedive.com"),
      ("Healthcare Dive","healthcaredive.com"))],
]

# Secondary discovery may suggest a direct article on these additional publisher domains.
# Publish it only after the original page independently provides the headline and date.
PUBLISHERS = {host:label for label,host,_ in FEEDS}
PUBLISHERS.update({
    "reuters.com":"Reuters","apnews.com":"Associated Press","ft.com":"Financial Times",
    "bloomberg.com":"Bloomberg","wsj.com":"The Wall Street Journal","theguardian.com":"The Guardian",
    "theverge.com":"The Verge","techcrunch.com":"TechCrunch","arstechnica.com":"Ars Technica",
    "businesskorea.co.kr":"BusinessKorea","koreaherald.com":"The Korea Herald","mk.co.kr":"Maeil Business Newspaper",
    "koreajoongangdaily.joins.com":"Korea JoongAng Daily","en.yna.co.kr":"Yonhap News Agency",
    "census.gov":"U.S. Census Bureau","bls.gov":"U.S. Bureau of Labor Statistics",
    "pressherald.com":"Portland Press Herald","mainebiz.biz":"Mainebiz","ajc.com":"The Atlanta Journal-Constitution",
    "gpb.org":"Georgia Public Broadcasting","opb.org":"Oregon Public Broadcasting",
    "wbur.org":"WBUR","wusf.org":"WUSF","kut.org":"KUT","mainepublic.org":"Maine Public",
    "governor.texas.gov":"Office of the Texas Governor","governor.georgia.gov":"Office of the Georgia Governor",
    "gov.ca.gov":"Office of the California Governor","mass.gov":"Commonwealth of Massachusetts",
    "abcnews.com":"ABC News","abcnews.go.com":"ABC News","cbsnews.com":"CBS News","cnn.com":"CNN",
    "nbcnews.com":"NBC News","pbs.org":"PBS","statnews.com":"STAT","fiercepharma.com":"Fierce Pharma",
    "datacenterdynamics.com":"DatacenterDynamics","tomshardware.com":"Tom’s Hardware",
    "nasdaq.com":"Nasdaq","aboutamazon.com":"About Amazon","newsroom.intel.com":"Intel Newsroom",
    "ir.amd.com":"AMD Investor Relations","newsroom.lamresearch.com":"Lam Research Newsroom",
    "news.broadcom.com":"Broadcom Newsroom","newsroom.sk.com":"SK Newsroom","news.skhynix.com":"SK hynix Newsroom",
    "ir.micron.com":"Micron Investor Relations","pr.tsmc.com":"TSMC","investor.ti.com":"Texas Instruments",
    "bizjournals.com":"The Business Journals","marketplace.org":"Marketplace","inc.com":"Inc.",
    "fortune.com":"Fortune","fastcompany.com":"Fast Company","nola.com":"NOLA.com",
    "delawarepublic.org":"Delaware Public Media","ncpolicywatch.org":"NC Newsline","pilotonline.com":"The Virginian-Pilot",
    "wisconsinwatch.org":"Wisconsin Watch","iowapublicradio.org":"Iowa Public Radio","kcur.org":"KCUR",
    "usnews.com":"U.S. News & World Report","denverpost.com":"The Denver Post","seattletimes.com":"The Seattle Times",
    "spokesman.com":"The Spokesman-Review","inquirer.com":"The Philadelphia Inquirer","latimes.com":"Los Angeles Times",
    "startribune.com":"The Minnesota Star Tribune","nebraskapublicmedia.org":"Nebraska Public Media",
    "wyomingpublicmedia.org":"Wyoming Public Media","ket.org":"Kentucky Educational Television","ideastream.org":"Ideastream Public Media",
    "nhpr.org":"New Hampshire Public Radio","vermontpublic.org":"Vermont Public","radioiowa.com":"Radio Iowa",
    "investor.lamresearch.com":"Lam Research Investor Relations","broadcom.com":"Broadcom",
})


def publisher(article):
    try:
        p=url.urlsplit(article)
        if p.scheme!="https" or p.username or p.password or p.port or len(p.path.strip("/"))<4:
            return None
        return next(((host,label) for host,label in PUBLISHERS.items()
                     if p.hostname in (host,"www."+host)),None)
    except (ValueError,TypeError,AttributeError):
        return None


def as_date(value):
    """Accept an explicit original date; never default a missing date to now."""
    if not isinstance(value,str) or not value.strip():
        return None
    try:
        result=dt.datetime.fromisoformat(value.replace("Z","+00:00"))
    except (TypeError,ValueError):
        try: result=email.utils.parsedate_to_datetime(value)
        except (TypeError,ValueError,OverflowError): return None
    if not result.tzinfo: return None
    return result.astimezone(dt.timezone.utc)


def article_row(title,article,published,source):
    return dict(title=html.unescape(" ".join(title.split())),url=article,date=published.strftime("%Y-%m-%dT%H:%M:%SZ"),
                source=source,publisherHost=publisher(article)[0])


def children(item):
    return {node.tag.split("}")[-1]:node for node in item}


def text_item(nodes,key):
    node=nodes.get(key)
    return "".join(node.itertext()).strip() if node is not None else ""


def feed_articles(xml, label, host, cutoff, now):
    tree=ET.fromstring(xml)
    if tree.tag.split("}")[-1] not in ("rss","feed","RDF"):
        raise ValueError("Publisher did not return a news feed")
    rows=[]
    for item in tree.iter():
        if item.tag.split("}")[-1] not in ("item","entry"):continue
        nodes=children(item)
        title=text_item(nodes,"title")
        article=text_item(nodes,"link") or next((n.get("href","") for n in item
            if n.tag.split("}")[-1]=="link" and n.get("rel","alternate")=="alternate"),"")
        published=as_date(text_item(nodes,"pubDate") or text_item(nodes,"published") or text_item(nodes,"date"))
        if not (published and cutoff<=published<=now and 10<=len(title)<=250 and publisher(article)==(host,label)):continue
        rows.append(article_row(title,article,published,label))
    return rows


def search_articles(xml):
    tree=ET.fromstring(xml)
    if tree.tag!="rss" or tree.find("channel") is None:raise ValueError("Unexpected search feed")
    for item in tree.findall("./channel/item"):
        nodes=children(item)
        direct=text_item(nodes,"link")
        parts=url.urlsplit(direct)
        if parts.hostname in ("bing.com","www.bing.com") and parts.path=="/news/apiclick.aspx":
            direct=url.parse_qs(parts.query).get("url",[""])[0]
        if publisher(direct):
            yield text_item(nodes,"title"),direct,as_date(text_item(nodes,"pubDate"))


class ArticleMetadata(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.meta={};self.jsonld=[];self.script=None;self.canonical=None

    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=="meta" and a.get("content"):self.meta[a.get("property") or a.get("name")]=a["content"]
        if tag=="link" and "canonical" in (a.get("rel") or "").lower().split():self.canonical=a.get("href")
        if tag=="script" and (a.get("type") or "").split(";")[0].strip()=="application/ld+json":self.script=[]

    def handle_data(self,data):
        if self.script is not None:self.script.append(data)

    def handle_endtag(self,tag):
        if tag=="script" and self.script is not None:
            try:self.jsonld.append(json.loads("".join(self.script)))
            except (ValueError,TypeError):pass
            self.script=None


def article_metadata(raw,article,search_title,search_date,cutoff,now):
    parsed=ArticleMetadata()
    parsed.feed(raw.decode("utf-8",errors="replace"))
    link=url.urljoin(article,parsed.canonical) if parsed.canonical else article
    if publisher(link)!=publisher(article):return None
    metadata=parsed.meta
    headline=metadata.get("og:title") or ""
    published=as_date(metadata.get("article:published_time"))
    candidates=[]
    for entry in parsed.jsonld:
        if isinstance(entry,list):candidates.extend(entry)
        elif isinstance(entry,dict):
            graph=entry.get("@graph")
            candidates.extend(graph if isinstance(graph,list) and graph else [entry])
    for item in candidates:
        if not isinstance(item,dict):continue
        types=item.get("@type",[])
        if isinstance(types,str):types=[types]
        if not isinstance(types,list) or not any(t in ("NewsArticle","ReportageNewsArticle","AnalysisNewsArticle","Article","BlogPosting") for t in types):continue
        identity=item.get("mainEntityOfPage") or item.get("url")
        if isinstance(identity,dict):identity=identity.get("@id")
        if isinstance(identity,str) and url.urlsplit(url.urljoin(link,identity)).path.rstrip("/")!=url.urlsplit(link).path.rstrip("/"):continue
        headline=headline or (item["headline"] if isinstance(item.get("headline"),str) else "")
        published=published or as_date(item.get("datePublished"))
        if headline and published:break
    words=lambda s:set(re.findall(r"\w+",html.unescape(s).casefold()))
    a,b=words(headline),words(search_title)
    if (not published or not cutoff<=published<=now or not a or not b or len(a & b)/len(a | b)<.58
            or abs((published-search_date).total_seconds())>3*86400):return None
    return article_row(headline,link,published,publisher(link)[1])
