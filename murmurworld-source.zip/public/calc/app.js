/* app.js — 전기요금 역산 계산기. elec_calc.py 를 그대로 옮긴 계산부 + 화면.
   수치는 data/tariff.json 하나가 정본이다. */
(function () {
  "use strict";

  // ---------- 계산부 (elec_calc.py 포팅) ----------
  const roundWon = (x) => Math.floor(x + 0.5);
  const floor10 = (x) => Math.floor(x / 10) * 10;
  const tierOf = (kwh, bounds) => (kwh <= bounds[0] ? 1 : kwh <= bounds[1] ? 2 : 3);

  function bill(kwh, season, contract, T) {
    const s = T.seasons[season], c = T.contracts[contract];
    const [b1, b2] = s.bounds, [r1, r2, r3] = c.rate;
    const t = tierOf(kwh, s.bounds);
    const energy = Math.floor(Math.min(kwh, b1) * r1 + Math.max(0, Math.min(kwh, b2) - b1) * r2 + Math.max(0, kwh - b2) * r3);
    const surcharge = Math.floor(kwh * (T.surcharge_per_kwh.climate + T.surcharge_per_kwh.fuel_adj));
    const base = c.base[t - 1];
    const subtotal = base + energy + surcharge;
    const vat = roundWon(subtotal * T.vat_rate);
    const fund = floor10(subtotal * T.fund_rate);
    const total = floor10(subtotal + vat + fund);
    return { kwh, season, contract, tier: t, base, energy, surcharge, subtotal, vat, fund, total };
  }
  function marginalRate(tier, contract, T) {
    const c = T.contracts[contract], mult = 1 + T.vat_rate + T.fund_rate;
    return (c.rate[tier - 1] + T.surcharge_per_kwh.climate + T.surcharge_per_kwh.fuel_adj) * mult;
  }
  function boundaryJump(fromTier, contract, T) {
    const c = T.contracts[contract], mult = 1 + T.vat_rate + T.fund_rate;
    return (c.base[fromTier] - c.base[fromTier - 1]) * mult + marginalRate(fromTier + 1, contract, T);
  }
  function inverse(total, season, contract, T, tvIncluded, maxKwh = 5000) {
    const target = total - (tvIncluded ? T.tv_license_fee : 0);
    const bounds = T.seasons[season].bounds;
    if (target <= bill(0, season, contract, T).total) return { kwh: 0, tier: 1, flag: "below_minimum", target };
    let lo = 0, hi = maxKwh;
    while (lo < hi) { const mid = Math.floor((lo + hi + 1) / 2); if (bill(mid, season, contract, T).total <= target) lo = mid; else hi = mid - 1; }
    const k = lo, bk = bill(k, season, contract, T).total, bn = bill(k + 1, season, contract, T).total;
    let flag = "ok", kwh = k;
    if (target > bk && target < bn) { if (bounds.includes(k)) flag = "boundary_gap"; else kwh = k + (target - bk) / (bn - bk); }
    else if (k >= maxKwh) flag = "above_range";
    kwh = Math.round(kwh * 10) / 10;
    const t = tierOf(kwh, bounds);
    const nxt = bounds.find((b) => kwh < b) ?? null;
    return { kwh, tier: t, flag, target, next_boundary: nxt, headroom: nxt === null ? null : Math.round((nxt - kwh) * 10) / 10,
      marginal: Math.round(marginalRate(t, contract, T) * 100) / 100, jump_if_cross: t === 3 ? null : Math.round(boundaryJump(t, contract, T)) };
  }
  function increment(baseKwh, addKwh, season, contract, T) {
    const before = bill(baseKwh, season, contract, T), after = bill(baseKwh + addKwh, season, contract, T);
    return { season, before_kwh: baseKwh, after_kwh: baseKwh + addKwh, before_total: before.total, after_total: after.total,
      delta: after.total - before.total, from_tier: before.tier, to_tier: after.tier, crossed: after.tier > before.tier,
      per_kwh: addKwh === 0 ? null : Math.round(((after.total - before.total) / addKwh) * 10) / 10 };
  }
  function applianceKwh(row, hoursPerDay, timesPerWeek) {
    const w = num(row["대표스펙_W"]), per = num(row["회당_kWh"]), rep = num(row["월kWh_대표"]) || 0;
    const p = row["패턴"];
    if (p === "상시" && w) return r1(w * 24 * 30 / 1000);
    if (p === "일일시간" && w && hoursPerDay != null) return r1(w * hoursPerDay * 30 / 1000);
    if (p === "회당" && per && timesPerWeek != null) return r1(per * timesPerWeek * 30 / 7);
    return rep;
  }
  const num = (v) => (v === null || v === undefined || v === "" ? null : Number(v));
  const r1 = (x) => Math.round(x * 10) / 10;

  // ---------- 상태·DOM ----------
  const $ = (id) => document.getElementById(id);
  const fmt = (n) => Math.round(n).toLocaleString("ko-KR");
  const SEASON_LABEL = { normal: "기타계절", summer: "하계(7·8월)" };
  let T = null, DB = null;
  const state = { rows: [{ amount: "", season: "normal" }, { amount: "", season: "normal" }, { amount: "", season: "normal" }],
    inverse: null, baseKwh: null, appliances: [] };

  function parseHoursDefault(row) {
    const m = String(row["기본사용"] || "").match(/([\d.]+)\s*(h|시간)/);
    if (m) return Number(m[1]);
    const mm = String(row["기본사용"] || "").match(/([\d.]+)\s*분/);
    if (mm) return Number(mm[1]) / 60;
    return 8;
  }
  function parseTimesDefault(row) {
    const s = String(row["기본사용"] || "");
    const w = s.match(/주\s*([\d.]+)\s*회/); if (w) return Number(w[1]);
    const d = s.match(/(매일|([\d.]+)\s*회\s*\/\s*일)/); if (d) return (d[2] ? Number(d[2]) : 1) * 7;
    return 3;
  }

  function renderBillRows() {
    const box = $("billRows"); box.innerHTML = "";
    state.rows.forEach((r, i) => {
      const div = document.createElement("div"); div.className = "row cols-2";
      div.innerHTML = `<div><label>${i + 1}번째 달 전기요금(원)</label><input type="number" min="0" step="10" inputmode="numeric" placeholder="예: 38,440" value="${r.amount}" data-i="${i}" class="amt"></div>
        <div><label>계절</label><select data-i="${i}" class="season"><option value="normal"${r.season === "normal" ? " selected" : ""}>기타계절(1~6·9~12월)</option><option value="summer"${r.season === "summer" ? " selected" : ""}>하계(7·8월)</option></select></div>`;
      box.appendChild(div);
    });
    box.querySelectorAll(".amt").forEach((el) => el.addEventListener("input", (e) => { state.rows[e.target.dataset.i].amount = e.target.value; }));
    box.querySelectorAll(".season").forEach((el) => el.addEventListener("change", (e) => { state.rows[e.target.dataset.i].season = e.target.value; }));
  }

  function runInverse() {
    const contract = $("contract").value, tv = $("tv").checked;
    const rows = state.rows.filter((r) => r.amount !== "" && Number(r.amount) > 0);
    if (!rows.length) { alert("고지서 금액을 하나 이상 넣어 주세요."); return; }
    const results = rows.map((r) => ({ ...r, inv: inverse(Number(r.amount), r.season, contract, T, tv) }));
    const body = $("inverseBody"); body.innerHTML = "";
    results.forEach((r, i) => {
      const inv = r.inv, note = inv.flag === "boundary_gap" ? `경계 직전(${inv.kwh}kWh)으로 봄` : inv.flag === "below_minimum" ? "기본요금 미만 금액" : inv.flag === "above_range" ? "범위 초과" : "";
      body.insertAdjacentHTML("beforeend", `<tr><td>${i + 1}</td><td class="num">${fmt(r.amount)}</td><td>${SEASON_LABEL[r.season]}</td><td class="num">${inv.kwh.toLocaleString("ko-KR")}</td><td>${inv.tier}단계</td><td>${note}</td></tr>`);
    });
    const avg = results.reduce((a, r) => a + r.inv.kwh, 0) / results.length;
    const avgR = Math.round(avg * 10) / 10;
    const nb = T.seasons.normal.bounds, t = tierOf(avgR, nb);
    const nxt = nb.find((b) => avgR < b) ?? null;
    $("kAvg").textContent = `${avgR.toLocaleString("ko-KR")} kWh`;
    $("kTier").textContent = `${t}단계`;
    $("kHead").textContent = nxt === null ? "3단계(경계 없음)" : `${Math.round((nxt - avgR) * 10) / 10} kWh (${nxt}kWh)`;
    $("kMarg").textContent = `${Math.round(marginalRate(t, contract, T)).toLocaleString("ko-KR")}원`;
    const jump = t === 3 ? null : Math.round(boundaryJump(t, contract, T));
    $("inverseNote").innerHTML = (jump ? `다음 경계를 1kWh 넘기면 기본요금이 바뀌어 약 <b>${fmt(jump)}원</b>이 한꺼번에 늘어납니다. ` : "이미 3단계라 경계 점프는 없고 1kWh마다 같은 값이 늘어납니다. ")
      + `역산은 근사이며 복지할인·개정 전후 혼합 청구가 있으면 어긋납니다.`;
    $("inverseOut").classList.remove("hidden");
    state.inverse = { contract, tv, results, avg: avgR };
    if (!$("baseKwh").value) { $("baseKwh").value = Math.round(avgR); }
    state.baseKwh = Number($("baseKwh").value);
    runDelta(); renderCard();
  }

  // ---------- 2단 ----------
  function renderCats() {
    const cat = $("cat"); cat.innerHTML = DB.categories.map((c) => `<option value="${c}">${c}</option>`).join("");
    renderAppl();
  }
  function renderAppl() {
    const c = $("cat").value, sel = $("appl");
    const items = DB.items.filter((r) => r["분류"] === c);
    sel.innerHTML = items.map((r) => `<option value="${r.id}">${r["제품"]} — 월 약 ${r["월kWh_대표"]}kWh (${r["근거등급"]})</option>`).join("");
    showHint();
  }
  function showHint() {
    const row = DB.items.find((r) => String(r.id) === $("appl").value); if (!row) return;
    $("applHint").textContent = `${row["패턴"]} · 기본 ${row["기본사용"] || "—"} · 범위 ${row["월kWh_하한"]}~${row["월kWh_상한"]}kWh · ${row["산정메모"]}`;
  }
  function addAppl() {
    const row = DB.items.find((r) => String(r.id) === $("appl").value); if (!row) return;
    const item = { id: row.id, row, hours: parseHoursDefault(row), times: parseTimesDefault(row), kwh: null };
    item.kwh = computeKwh(item);
    state.appliances.push(item); renderApplList(); runDelta(); renderCard();
  }
  function computeKwh(item) {
    const p = item.row["패턴"];
    if (item.override != null) return item.override;
    if (p === "일일시간") return applianceKwh(item.row, item.hours, null);
    if (p === "회당") return applianceKwh(item.row, null, item.times);
    return applianceKwh(item.row, null, null);
  }
  function renderApplList() {
    const box = $("applList"); box.innerHTML = "";
    state.appliances.forEach((it, i) => {
      const p = it.row["패턴"];
      let ctrl = "";
      if (p === "일일시간") ctrl = `하루 <input type="number" step="0.5" min="0" max="24" value="${it.hours}" data-i="${i}" class="hrs"> 시간`;
      else if (p === "회당") ctrl = `주 <input type="number" step="0.5" min="0" max="50" value="${it.times}" data-i="${i}" class="tms"> 회`;
      else ctrl = `<span class="meta">${p === "상시" ? "24시간 상시" : "복합(대표값)"}</span>`;
      ctrl += ` · 직접 입력 <input type="number" step="0.1" min="0" placeholder="월 kWh" value="${it.override ?? ""}" data-i="${i}" class="ovr">`;
      const div = document.createElement("div"); div.className = "appl-row";
      div.innerHTML = `<div><div class="name">${it.row["제품"]}</div><div class="meta">${it.row["분류"]} · 근거 ${it.row["근거등급"]} · 범위 ${it.row["월kWh_하한"]}~${it.row["월kWh_상한"]}kWh</div><div class="ctrl">${ctrl}</div></div>
        <div><div class="kwh">${it.kwh.toLocaleString("ko-KR")} kWh/월</div><button class="secondary small" data-i="${i}" data-act="rm">빼기</button></div>`;
      box.appendChild(div);
    });
    box.querySelectorAll(".hrs").forEach((el) => el.addEventListener("input", (e) => { const it = state.appliances[e.target.dataset.i]; it.hours = Number(e.target.value); it.override = null; it.kwh = computeKwh(it); refreshList(); }));
    box.querySelectorAll(".tms").forEach((el) => el.addEventListener("input", (e) => { const it = state.appliances[e.target.dataset.i]; it.times = Number(e.target.value); it.override = null; it.kwh = computeKwh(it); refreshList(); }));
    box.querySelectorAll(".ovr").forEach((el) => el.addEventListener("input", (e) => { const it = state.appliances[e.target.dataset.i]; it.override = e.target.value === "" ? null : Number(e.target.value); it.kwh = computeKwh(it); refreshList(); }));
    box.querySelectorAll("[data-act=rm]").forEach((el) => el.addEventListener("click", (e) => { state.appliances.splice(Number(e.target.dataset.i), 1); renderApplList(); runDelta(); renderCard(); }));
  }
  function refreshList() {
    document.querySelectorAll("#applList .appl-row").forEach((div, i) => { const k = div.querySelector(".kwh"); if (k && state.appliances[i]) k.textContent = `${state.appliances[i].kwh.toLocaleString("ko-KR")} kWh/월`; });
    runDelta(); renderCard();
  }
  function runDelta() {
    const base = Number($("baseKwh").value); state.baseKwh = isNaN(base) ? null : base;
    const add = Math.round(state.appliances.reduce((a, it) => a + it.kwh, 0) * 10) / 10;
    $("kAdd").textContent = `${add.toLocaleString("ko-KR")} kWh`;
    if (state.baseKwh === null || !$("baseKwh").value) { $("kDeltaN").textContent = $("kDeltaS").textContent = $("kAnnual").textContent = "기준 사용량 필요"; $("deltaTable").classList.add("hidden"); $("crossOut").innerHTML = ""; state.delta = null; return; }
    const contract = $("contract").value;
    const n = increment(state.baseKwh, add, "normal", contract, T), s = increment(state.baseKwh, add, "summer", contract, T);
    const annual = n.delta * 10 + s.delta * 2;
    $("kDeltaN").textContent = `+${fmt(n.delta)}원`; $("kDeltaS").textContent = `+${fmt(s.delta)}원`; $("kAnnual").textContent = `+${fmt(annual)}원`;
    const body = $("deltaBody"); body.innerHTML = "";
    [n, s].forEach((r) => body.insertAdjacentHTML("beforeend", `<tr><td>${SEASON_LABEL[r.season]}</td><td class="num">${r.before_kwh.toLocaleString("ko-KR")}</td><td class="num">${fmt(r.before_total)}</td><td class="num">${r.after_kwh.toLocaleString("ko-KR")}</td><td class="num">${fmt(r.after_total)}</td><td class="num">+${fmt(r.delta)}</td><td>${r.from_tier}→${r.to_tier}단계${r.crossed ? ' <span class="badge danger">경계 넘음</span>' : ""}</td></tr>`));
    $("deltaTable").classList.toggle("hidden", add === 0);
    let msg = "";
    if (add > 0) {
      const mN = Math.round(marginalRate(n.from_tier, contract, T));
      if (n.crossed) msg += `<div class="alert danger">기타계절: 이 가전들로 ${n.from_tier}단계에서 ${n.to_tier}단계로 넘어갑니다. 기본요금 점프가 포함돼 kWh당 평균 ${fmt(n.per_kwh)}원꼴입니다(구간 안이면 ${fmt(mN)}원).</div>`;
      else msg += `<div class="alert ok">기타계절: 구간이 바뀌지 않습니다. kWh당 약 ${fmt(mN)}원, 월 +${fmt(n.delta)}원.</div>`;
      if (s.crossed) msg += `<div class="alert warn">하계(7·8월): ${s.from_tier}단계에서 ${s.to_tier}단계로 넘어갑니다. 월 +${fmt(s.delta)}원.</div>`;
    }
    $("crossOut").innerHTML = msg;
    state.delta = { n, s, annual, add };
  }

  // ---------- 3단 ----------
  function renderCard() {
    const lines = [];
    const contract = $("contract").value;
    lines.push(`[전기요금 역산 계산기] ${T.contracts[contract].label}`);
    if (state.inverse) {
      state.inverse.results.forEach((r, i) => lines.push(`${i + 1}번째 달 ${fmt(r.amount)}원(${SEASON_LABEL[r.season]}) → 약 ${r.inv.kwh}kWh, ${r.inv.tier}단계`));
      const t = tierOf(state.inverse.avg, T.seasons.normal.bounds);
      lines.push(`평균 ${state.inverse.avg}kWh · 지금 1kWh = 약 ${fmt(marginalRate(t, contract, T))}원`);
    }
    if (state.delta && state.delta.add > 0) {
      lines.push(`추가 가전: ${state.appliances.map((it) => `${it.row["제품"]} ${it.kwh}kWh`).join(", ")}`);
      lines.push(`→ 기타계절 월 +${fmt(state.delta.n.delta)}원${state.delta.n.crossed ? "(경계 넘음)" : ""}, 하계 월 +${fmt(state.delta.s.delta)}원${state.delta.s.crossed ? "(경계 넘음)" : ""}, 연간 약 +${fmt(state.delta.annual)}원`);
    }
    lines.push(`근사값 · 요금표 ${T.effective_from} 기준`);
    $("cardText").textContent = lines.join("\n");
  }
  async function copyText(text, msg) {
    try { await navigator.clipboard.writeText(text); $("copyMsg").textContent = msg; } catch (e) { $("copyMsg").textContent = "복사 실패: 직접 선택해 복사하세요."; }
    setTimeout(() => { $("copyMsg").textContent = ""; }, 2500);
  }
  function encodeState() {
    const s = { c: $("contract").value, tv: $("tv").checked ? 1 : 0, rows: state.rows.filter((r) => r.amount !== "").map((r) => [Number(r.amount), r.season]),
      base: $("baseKwh").value ? Number($("baseKwh").value) : null, ap: state.appliances.map((it) => [it.id, it.hours, it.times, it.override]) };
    return btoa(unescape(encodeURIComponent(JSON.stringify(s)))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }
  function decodeState() {
    const m = location.hash.match(/#s=([A-Za-z0-9_-]+)/); if (!m) return;
    try {
      const b = m[1].replace(/-/g, "+").replace(/_/g, "/");
      const s = JSON.parse(decodeURIComponent(escape(atob(b + "=".repeat((4 - b.length % 4) % 4)))));
      $("contract").value = s.c || "low"; $("tv").checked = !!s.tv;
      state.rows = [0, 1, 2].map((i) => (s.rows && s.rows[i] ? { amount: s.rows[i][0], season: s.rows[i][1] } : { amount: "", season: "normal" }));
      renderBillRows();
      if (s.base != null) $("baseKwh").value = s.base;
      (s.ap || []).forEach(([id, hours, times, override]) => { const row = DB.items.find((r) => r.id === id); if (!row) return; const it = { id, row, hours, times, override: override ?? null, kwh: 0 }; it.kwh = computeKwh(it); state.appliances.push(it); });
      renderApplList();
      if (state.rows.some((r) => r.amount !== "")) runInverse(); else { runDelta(); renderCard(); }
    } catch (e) { /* 무시 */ }
  }

  // ---------- 초기화 ----------
  async function init() {
    const [t, db] = await Promise.all([fetch("data/tariff.json").then((r) => r.json()), fetch("data/appliances.json").then((r) => r.json())]);
    T = t; DB = db;
    $("tariffDate").textContent = T.effective_from; $("tariffDate2").textContent = T.effective_from;
    renderBillRows(); renderCats();
    $("cat").addEventListener("change", renderAppl);
    $("appl").addEventListener("change", showHint);
    $("btnInverse").addEventListener("click", runInverse);
    $("btnAddRow").addEventListener("click", () => { if (state.rows.length < 6) { state.rows.push({ amount: "", season: "normal" }); renderBillRows(); } });
    $("btnAddAppl").addEventListener("click", addAppl);
    $("baseKwh").addEventListener("input", () => { runDelta(); renderCard(); });
    $("contract").addEventListener("change", () => { if (state.inverse) runInverse(); else { runDelta(); renderCard(); } });
    $("tv").addEventListener("change", () => { if (state.inverse) runInverse(); });
    $("btnCopy").addEventListener("click", () => copyText($("cardText").textContent, "복사했습니다."));
    $("btnShare").addEventListener("click", () => { const url = location.origin + location.pathname + "#s=" + encodeState(); history.replaceState(null, "", "#s=" + encodeState()); copyText(url, "링크를 복사했습니다."); });
    renderCard();
    decodeState();
  }
  window.ElecCalc = { bill, inverse, increment, marginalRate, boundaryJump, applianceKwh, tierOf };
  document.addEventListener("DOMContentLoaded", init);
})();
